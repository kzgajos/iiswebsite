package edu.harvard.seas.iis.abilities.analysis;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Vector;

import edu.harvard.seas.iis.util.Logger;
import edu.harvard.seas.iis.util.TokenizedStringVector;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * @author kgajos
 * 
 */
public class IISMouseLogParser implements Parser {
	// constants for event types
	private static int MOVEMENT = 1;
	private static int CLICK = 2;

	// turn this to true to see details on how the parser decides which
	// movements to accept and which to discard
	protected boolean debug = false;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.harvard.seas.iis.abilities.analysis.Parser#readFiles(java.io.File[])
	 */
	public Vector<Movement> parseMovementLog(File[] files) throws IOException {
		return parseMovementLog(new LogSource(files));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.harvard.seas.iis.abilities.analysis.Parser#parseMovementLog(java.
	 * lang.String)
	 */
	public Vector<Movement> parseMovementLog(String log) throws IOException {
		return parseMovementLog(new LogSource(log));
	}

	public Vector<Movement> parseMovementLog(LogSource source)
			throws IOException {

		Vector<Movement> res = new Vector<Movement>();

		TokenizedStringVector record;
		Vector<TokenizedStringVector> currentMovement = new Vector<TokenizedStringVector>();
		long lastEventTimeStamp = 0;
		long curTimeStamp;
		// used to filter out events with the same time stamp (accounts for a
		// bug in one of the loggers that erroneously recorded some events
		// multiple times)
		HashSet<Long> recordedTimeStamp = new HashSet<Long>();

		// we keep track of this because we do not want to capture any movements
		// that might have originated outside of the browser window
		boolean firstMovementAfterBreak = true;

		// we ignore break events right after clicks and keyboard events --- we
		// know that the mouse is stationary then so no need to disqualify the
		// following movement
		boolean ignoreBreak = true;

		// used to count the number of clicks that did not result in recorded
		// movements
		int rejectedCount = 0;

		String nextLine = source.getNextLine();
		try {
			while (nextLine != null) {
				try {
					record = new TokenizedStringVector(nextLine, ", ");
					curTimeStamp = record.getNthFromLastAsLong(0);

					// mouse movement events, or mouse button up/down events
					// (not yet interpreted as a click)
					if (recordedTimeStamp.contains(curTimeStamp)) {
						// pass
					} else if ("m".equalsIgnoreCase(record.get(0))) {
						// check if it is safe to start tracking a movement
						// after the mouse went out of bounds
						if (curTimeStamp - lastEventTimeStamp > Constants.SUBMOVEMENT_SEPARATOR_DURATION) {
							if (firstMovementAfterBreak && debug)
								System.err.println("Submovement boundary of "
										+ (curTimeStamp - lastEventTimeStamp)
										+ " ms--resuming movement recording: "
										+ nextLine);
							firstMovementAfterBreak = false;
						}

						// check if the pause between successive events was
						// so
						// long
						// that we have a new movement starting
						if (currentMovement.size() > 0
								&& curTimeStamp - lastEventTimeStamp > Constants.MOVEMENT_SEPARATOR_DURATION) {
							// reset the movement
							currentMovement.clear();
							ignoreBreak = true;
							if (debug)
								System.err.println("Pause of "
										+ (curTimeStamp - lastEventTimeStamp)
										+ "ms: " + nextLine);
						} else {
							currentMovement.add(record);
							ignoreBreak = false;
						}
					} else if ("s-d".equalsIgnoreCase(record.get(0))
							|| "s-u".equalsIgnoreCase(record.get(0))
							|| "e-d".equalsIgnoreCase(record.get(0))
							|| "e-u".equalsIgnoreCase(record.get(0))) {
						// record mouse button up and down events (clicks
						// are processed separately)
						currentMovement.add(record);
						ignoreBreak = true;
					} else if ("break".equalsIgnoreCase(record.get(0))) {
						if (!ignoreBreak) {
							// if we capture a break event, we discard any
							// information
							// about the current movement; however, we
							// ignore
							// break
							// events that happen immediately after a mouse
							// button
							// press event
							currentMovement.clear();
							firstMovementAfterBreak = true;
							ignoreBreak = true;
							if (debug)
								System.err.println("Break: " + nextLine);
						}
					} else if ("s".equalsIgnoreCase(record.get(0))
							|| "s-c".equalsIgnoreCase(record.get(0))
							|| "e".equalsIgnoreCase(record.get(0))
							|| "e-c".equalsIgnoreCase(record.get(0))) {
						// button click events

						// check the duration from the start to the end of
						// this
						// movement
						long duration = (currentMovement.size() > 1 ? curTimeStamp
								- currentMovement.firstElement()
										.getNthFromLastAsLong(0)
								: 0);

						if (!firstMovementAfterBreak
								&& !(duration > Constants.LONGEST_ACCEPTABLE_MOVEMENT)
								// && !record.get(1).startsWith("other")
								&& currentMovement.size() >= 4) {
							currentMovement.add(record);
							try {
								res.add(parseMovement(currentMovement));
								if (debug)
									System.err.println("Accepted: " + nextLine);
							} catch (NumberFormatException ex) {
								System.err
										.println("Trouble parsing movement ending with: "
												+ nextLine
												+ " from "
												+ source.getCurrentSource());
								ex.printStackTrace();
							}
						} else {
							rejectedCount++;
							if (duration > Constants.LONGEST_ACCEPTABLE_MOVEMENT)
								System.err
										.println("Rejected (movement too long: "
												+ duration
												+ "ms): "
												+ nextLine
												+ " in "
												+ source.getCurrentSource());
							if (debug && firstMovementAfterBreak)
								System.err
										.println("Rejected (first movement after break): "
												+ nextLine);
							if (debug && !firstMovementAfterBreak
									&& currentMovement.size() < 4)
								System.err
										.println("Rejected (too few points): "
												+ nextLine);

						}
						// reset the movement
						currentMovement.clear();
						firstMovementAfterBreak = false;
						ignoreBreak = true;
					} else { // everything else is a keyboard event --- we
						// reset
						// any
						// mouse movement because we assume that people
						// cannot
						// move the mouse pointer while typing

						// reset the movement
						currentMovement.clear();
						firstMovementAfterBreak = false;
						ignoreBreak = true;
					}

					lastEventTimeStamp = curTimeStamp;
					recordedTimeStamp.add(curTimeStamp);
				} catch (Exception ex) {
					System.err.println("Could not parse " + nextLine + " in "
							+ source.getCurrentSource());
					ex.printStackTrace();
				}
				nextLine = source.getNextLine();
			}
		} catch (Exception ex) {
			Logger.log(Logger.ERROR, "Trouble at line:\n" + nextLine
					+ "\nfrom " + source.getCurrentSource());
			ex.printStackTrace();
			System.exit(1);
		}

		if (debug)
			System.err.println("Accepted " + res.size() + "; Rejected "
					+ rejectedCount);
		return res;
	}

	// Assumes the user chooses one contiguous group of files.
	public void summarizeFilesToFile(File[] dataFiles, File outputFile)
			throws IOException {
		FileManipulation.saveStringToFile(Movement.getSummaryHeadingsNew()
				+ "\n", outputFile, true);
		Arrays.sort(dataFiles, new ParserFileComparator());

		System.out.print("We are on");
		for (File file : dataFiles)
			System.out.print(" " + file.getName());
		FileManipulation.saveStringToFile(Movement.summaryReport(
				parseMovementLog(dataFiles), false), outputFile, true);
	}

	/**
	 * Turns a sequence of log entries into a movement
	 * 
	 * @param mouseEvents
	 *            a set of raw log entries comprising a single movement
	 * @return
	 */
	protected Movement parseMovement(Vector<TokenizedStringVector> mouseEvents) {
		TokenizedStringVector firstEvent = mouseEvents.firstElement();
		TokenizedStringVector lastEvent = mouseEvents.lastElement();

		Point home = new Point(firstEvent.getNthFromLastAsInt(2), firstEvent
				.getNthFromLastAsInt(1));

		double startTime = firstEvent.getNthFromLastAsLong(0);
		double movementTime = lastEvent.getNthFromLastAsLong(0) - startTime;

		Movement res = new Movement(home, startTime, movementTime);

		int eventType, x, y;
		long time;
		for (TokenizedStringVector event : mouseEvents) {
			// capture coordinates of the event
			x = event.getNthFromLastAsInt(2);
			y = event.getNthFromLastAsInt(1);
			time = event.getNthFromLastAsLong(0);

			// determine event type
			eventType = MOVEMENT;
			if ("s".equalsIgnoreCase(event.firstElement())
					|| "s-c".equalsIgnoreCase(event.firstElement())
					|| "e".equalsIgnoreCase(event.firstElement())
					|| "e-c".equalsIgnoreCase(event.firstElement()))
				eventType = CLICK;

			// process regular move nodes
			if (eventType == MOVEMENT) {
				res.addMovementPoint(new MovementPoint(home, 0, x, y, time,
						false));
			}
			// process click events
			else if (eventType == CLICK) {
				boolean hit = true; // for now only successful clicks are
				// recorded so all clicks are hits
				res.targetType = event.get(1);
				if (!"undefined".equals(event.get(3))
						&& !"undefined".equals(event.get(4))) {
					res.targetWidth = (int) event.getAsDouble(3);
					res.targetHeight = (int) event.getAsDouble(4);
					res.targetSize = Math
							.min(res.targetWidth, res.targetHeight);
				}

				// for older logs, we use the final click as the location of
				// the target
				res.targetCenterX = event.getNthFromLastAsInt(2);
				res.targetCenterY = event.getNthFromLastAsInt(1);

				// for newer logs, we can get the location more exactly
				if (event.size() == 10) {
					// position of the upper left corner of the target
					res.targetX = (int) event.getAsDouble(5);
					res.targetY = (int) event.getAsDouble(6);
					// commented out because the exact shapes of some
					// targets (such as links) are hard to estimate and
					// those targets can also have width>>height, which
					// makes target center computation not particularly
					// helpful for estimating movement ID
					// targetCenterX = targetX + (int) (targetWidth / 2);
					// targetCenterY = targetY + (int) (targetHeight / 2);
				}

				res.addClickEvent(x, eventType, time, hit, res.targetType,
						res.targetX, res.targetY, res.targetCenterX,
						res.targetCenterY, res.targetWidth, res.targetHeight);
			}
		}

		res.computeCompleteStatistics();
		return res;
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		/*
		 * summarizeFilesToFile(
		 * FileManipulation.getUserSpecifiedFilesForReading(),
		 * FileManipulation.getUserSpecifiedFileForSaving());
		 */
	}
}
