package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.StringTokenizer;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import edu.harvard.seas.iis.util.collections.ArrayUtils;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * Tools for running the feature selection process
 * 
 * @author kgajos
 * 
 */
public class FeatureSelection {

	protected ClassifierEvaluator evaluator = new ClassifierEvaluator();
	protected String report = "";
	protected Hashtable<FeatureSet, FeatureSelectionRecord> cache = new Hashtable<FeatureSet, FeatureSelectionRecord>();
	protected HashSet<FeatureSet> featureSetsCurrentlyBeingEvaluated = new HashSet<FeatureSet>();
	protected File recordFile;

	protected void populateCacheFromFile(File file) throws IOException {
		if (!file.exists()) {
			System.err
					.println("Can't read cache file --- assuming it's ok. File I was looking for: "
							+ file);
			return;
		}
		String record = FileManipulation.readStringFromFile(file);
		StringTokenizer lines = new StringTokenizer(record, "\n");
		while (lines.hasMoreElements()) {
			FeatureSelectionRecord r = new FeatureSelectionRecord(lines
					.nextToken());
			storeInCache(r);
		}
		System.out
				.println("Got " + cache.size() + " unique records from cache");
	}

	protected void storeInCache(FeatureSelectionRecord r) {
		synchronized (cache) {
			cache.put(new FeatureSet(r.getFeatures()), r);
		}
		featureSetsCurrentlyBeingEvaluated.remove(new FeatureSet(r
				.getFeatures()));
	}

	protected FeatureSelectionRecord getValueFromCache(List<String> attrs) {
		synchronized (cache) {
			return cache.get(new FeatureSet(attrs));
		}
	}

	protected boolean isInCache(List<String> attrs) {
		synchronized (cache) {
			return getValueFromCache(attrs) != null;
		}
	}

	protected synchronized boolean isCurrentlyBeingEvaluated(
			List<String> featureSet) {
		return featureSetsCurrentlyBeingEvaluated.contains(new FeatureSet(
				featureSet));
	}

	protected void addToListOfFeatureSetsCurrentlyBeingEvaluated(
			List<String> featureSet) {
		featureSetsCurrentlyBeingEvaluated.add(new FeatureSet(featureSet));
		System.out.println("**Currently being evaluated:\n--"
				+ PrettyPrint.toPrettyLine(featureSetsCurrentlyBeingEvaluated,
						"\n--"));
	}

	protected FeatureSelectionRecord findBestInCache() {
		FeatureSelectionRecord best = null;
		double bestOEC = Double.MAX_VALUE;

		synchronized (cache) {
			for (FeatureSelectionRecord r : cache.values()) {
				double oec = overalEvaluationCriterion(r.results);
				if (!Double.isNaN(oec) && (best == null || oec < bestOEC)) {
					best = r;
					bestOEC = oec;
				}
			}
		}
		return best;
	}

	protected FeatureSelectionRecord getRandomGoodRecordFromCache(double p) {
		ArrayList<FeatureSelectionRecord> records = null;
		synchronized (cache) {
			if (cache.isEmpty())
				return null;
			records = new ArrayList<FeatureSelectionRecord>(cache.values());
		}
		Collections.sort(records);
		for (FeatureSelectionRecord r : records)
			if (Math.random() < p)
				return r;
		return records.get((int) Math.random() * records.size());
	}

	/**
	 * Computes the score for determining which feature set is best; depending
	 * on your priorities, different things can go into this score
	 * 
	 * @param results
	 * @return
	 */
	public double overalEvaluationCriterion(ClassifierEvalStats results) {

		return results.motivatedError + results.motivatedAbsoluteIPError
				+ results.worstAbsoluteMotivatedError
				+ results.worstAbsoluteMotivatedIPError
				+ results.meanAbsoluteMTbyIDerror
				+ results.worstAbsoluteMTbyIDerror;
	}

	/**
	 * Performs a per-user crossvalidation; evaluation is performed on users
	 * listed in usersToEvaluateOn; the dataSet may have data from more users --
	 * that's ok, the data from those users are used for training but not for
	 * evaluation
	 * 
	 * @param c
	 * @param dataSet
	 * @param usersToEvaluateOn
	 * @param annotateDataSet
	 * @return
	 * @throws Exception
	 */
	public ClassifierEvalStats crossvalidateOverUsers(Classifier c,
			DataSet dataSet, String[] usersToEvaluateOn, boolean annotateDataSet)
			throws Exception {

		ClassifierEvalStats stats = new ClassifierEvalStats();
		final Attribute attrUser = dataSet.attribute("User");

		for (int i = 0; i < usersToEvaluateOn.length; i++) {
			final String testUser = usersToEvaluateOn[i];
			DataSet trainingSet = dataSet
					.getInstancesWithAttributeValueNotEqual(dataSet
							.attribute("User"), testUser);
			DataSet testSet = dataSet.getInstancesForUser(testUser);

			c.buildClassifier(trainingSet);
			System.out.print(testUser + ": ");
			double[] res = evaluator.evaluate(c, testSet);

			// if asked to put classifier predictions back into the data set,
			// add the classifier's predictions for the current test user
			if (annotateDataSet) {
				evaluator.annotateDataSet(dataSet, c, new InstanceFilter() {
					public boolean evaluateInstance(Instance instance,
							Instances theCompleteDataSet) {
						String instanceUser = instance.stringValue(attrUser);
						return testUser.equals(instanceUser);
					}
				});
			}

			stats.implicitError += res[4];
			if (res[4] < stats.minImplicitError)
				stats.minImplicitError = res[4];
			if (res[4] > stats.maxImplicitError)
				stats.maxImplicitError = res[4];
			stats.motivatedError += res[7];
			if (res[7] < stats.minMotivatedError)
				stats.minMotivatedError = res[7];
			if (res[7] > stats.maxMotivatedError)
				stats.maxMotivatedError = res[7];
			stats.fractionOfMotivatedMovements += res[8];
			if (res[8] < stats.minFractionOfMotivatedMovements)
				stats.minFractionOfMotivatedMovements = res[8];
			if (res[8] > stats.maxFractionOfMotivatedMovements)
				stats.maxFractionOfMotivatedMovements = res[8];
			stats.implicitIPError += res[9];
			stats.minImplicitIPError = Math.min(stats.minImplicitIPError,
					res[9]);
			stats.maxImplicitIPError = Math.max(stats.maxImplicitIPError,
					res[9]);
			stats.motivatedIPError += res[10];
			stats.motivatedAbsoluteIPError += Math.abs(res[10]);
			if (res[10] < stats.minMotivatedIPError)
				stats.minMotivatedIPError = res[10];
			if (res[10] > stats.maxMotivatedIPError)
				stats.maxMotivatedIPError = res[10];
			stats.recall += res[14];
			if (res[14] < stats.minRecall)
				stats.minRecall = res[14];
			if (res[14] > stats.maxRecall)
				stats.maxRecall = res[14];
			stats.implicitAbsoluteMTbyIDerror += Math.abs(res[18]);
			stats.minImplicitAbsoluteMTbyIDerror = Math.min(
					stats.minImplicitAbsoluteMTbyIDerror, res[18]);
			stats.maxImplicitAbsoluteMTbyIDerror = Math.max(
					stats.maxImplicitAbsoluteMTbyIDerror, res[18]);

			stats.meanAbsoluteMTbyIDerror += Math.abs(res[19]);
			stats.minMTbyIDerror = Math.min(stats.minMTbyIDerror, res[19]);
			stats.maxMTbyIDerror = Math.max(stats.maxMTbyIDerror, res[19]);

			stats.implicitMTbyIDstdev += res[20];
			stats.explicitMTbyIDstdev += res[21];
			stats.motivatedMTbyIDstdev += res[22];
		}

		stats.implicitError /= usersToEvaluateOn.length;
		stats.motivatedError /= usersToEvaluateOn.length;
		stats.fractionOfMotivatedMovements /= usersToEvaluateOn.length;
		stats.motivatedIPError /= usersToEvaluateOn.length;
		stats.motivatedAbsoluteIPError /= usersToEvaluateOn.length;
		stats.implicitIPError /= usersToEvaluateOn.length;
		stats.recall /= usersToEvaluateOn.length;
		stats.meanAbsoluteMTbyIDerror /= usersToEvaluateOn.length;
		stats.implicitAbsoluteMTbyIDerror /= usersToEvaluateOn.length;
		stats.implicitMTbyIDstdev /= usersToEvaluateOn.length;
		stats.explicitMTbyIDstdev /= usersToEvaluateOn.length;
		stats.motivatedMTbyIDstdev /= usersToEvaluateOn.length;

		stats.worstAbsoluteMotivatedError = Math.max(Math
				.abs(stats.minMotivatedError), stats.maxMotivatedError);

		stats.worstAbsoluteMotivatedIPError = Math.max(Math
				.abs(stats.minMotivatedIPError), stats.maxMotivatedIPError);

		stats.worstAbsoluteMTbyIDerror = Math.max(Math
				.abs(stats.minMTbyIDerror), stats.maxMTbyIDerror);

		return stats;
	}

	/**
	 * Uses crossvalidation to evaluate a particular classifier on a particular
	 * set of features on a particular data set
	 * 
	 * @param features
	 * @param c
	 * @param dataSet
	 * @param annotateDataSet
	 * @return
	 * @throws Exception
	 */
	public ClassifierEvalStats evaluateFeatureSet(String[] features,
			PositiveAndUnlabeledClassifier c, DataSet dataSet,
			boolean annotateDataSet) throws Exception {

		System.out.println("Training instances: " + dataSet.numInstances());

		c.setAllowedFeatures(features);

		return crossvalidateOverUsers(c, dataSet,
				Settings.USERS_TO_INCLUDE_IN_EVALUATION, annotateDataSet);
	}

	/**
	 * Given a starting set of features, searches for the best set of features
	 * to use with a particular classifier
	 * 
	 * @param startingFeatures
	 * @param allowedFeatures
	 * @param c
	 * @param dataSet
	 * @throws Exception
	 */
	public double search(List<String> startingFeatures,
			String[] allowedFeatures, PositiveAndUnlabeledClassifier c,
			DataSet dataSet, String prefix, double bestOEC) throws Exception {

		int numNewFeatureSetsExplored = 0;
		boolean improvedOEC = false;
		List<String> bestFeatureSet = new ArrayList<String>();

		System.out.println(prefix + "Evaluating features " + startingFeatures);
		if (!isInCache(startingFeatures)
				&& !isCurrentlyBeingEvaluated(startingFeatures)) {
			addToListOfFeatureSetsCurrentlyBeingEvaluated(startingFeatures);
			ClassifierEvalStats tempRes = evaluateFeatureSet(startingFeatures
					.toArray(new String[] {}), c, dataSet, false);
			numNewFeatureSetsExplored++;
			FeatureSelectionRecord r = new FeatureSelectionRecord(
					startingFeatures, tempRes);
			storeInCache(r);
			FileManipulation.saveStringToFile(r + "\n", recordFile, true);

			double oec = overalEvaluationCriterion(tempRes);
			System.out.println(prefix + "OEC for current features: " + oec
					+ " (" + startingFeatures + ")");
			if (oec < bestOEC) {
				bestOEC = oec;
				bestFeatureSet = startingFeatures;
			}
		}

		if (startingFeatures.size() >= 4)
			for (String feature : startingFeatures) {
				if ("Class".contains(feature))
					continue;
				ArrayList<String> features = new ArrayList<String>(
						startingFeatures);
				features.remove(feature);
				Collections.sort(features);
				System.out.println(prefix + "Evaluating features " + features);
				ClassifierEvalStats tempRes = null;
				if (isInCache(features)) {
					tempRes = getValueFromCache(features).results;
					System.out.println(prefix + "Got results from cache");
				} else if (isCurrentlyBeingEvaluated(features)) {
					System.out.println(prefix
							+ "Somebody else is working on this set");
				} else {
					addToListOfFeatureSetsCurrentlyBeingEvaluated(features);
					tempRes = evaluateFeatureSet(features
							.toArray(new String[] {}), c, dataSet, false);
					numNewFeatureSetsExplored++;
					FeatureSelectionRecord r = new FeatureSelectionRecord(
							features, tempRes);
					storeInCache(r);
					synchronized (recordFile) {
						FileManipulation.saveStringToFile(r + "\n", recordFile,
								true);
					}
				}
				if (tempRes != null) {
					double oec = overalEvaluationCriterion(tempRes);
					System.out.println(prefix + "OEC for current features: "
							+ oec + " (" + features + ")");
					if (oec < bestOEC) {
						bestOEC = oec;
						bestFeatureSet = features;
						improvedOEC = true;
					}
					System.out.println(prefix + "Current best OEC: " + bestOEC
							+ " for "
							+ PrettyPrint.toPrettyLine(bestFeatureSet, ", "));
				}
			}

		if (improvedOEC) {
			System.out.println(prefix + "Going to dig deeper on "
					+ PrettyPrint.toPrettyLine(bestFeatureSet, ", "));
			bestOEC = search(bestFeatureSet, allowedFeatures, c, dataSet,
					prefix, bestOEC);
		}
		improvedOEC = false;

		for (String feature : allowedFeatures) {
			if (startingFeatures.contains(feature))
				continue;
			ArrayList<String> features = new ArrayList<String>(startingFeatures);
			features.add(feature);
			Collections.sort(features);
			System.out.println(prefix + "Evaluating features " + features);
			ClassifierEvalStats tempRes = null;
			if (isInCache(features)) {
				tempRes = getValueFromCache(features).results;
				System.out.println(prefix + "Got results from cache");
			} else if (isCurrentlyBeingEvaluated(features)) {
				System.out.println(prefix
						+ "Somebody else is working on this set");
			} else {
				addToListOfFeatureSetsCurrentlyBeingEvaluated(features);
				tempRes = evaluateFeatureSet(features.toArray(new String[] {}),
						c, dataSet, false);
				numNewFeatureSetsExplored++;
				FeatureSelectionRecord r = new FeatureSelectionRecord(features,
						tempRes);
				storeInCache(r);
				synchronized (recordFile) {
					FileManipulation.saveStringToFile(r + "\n", recordFile,
							true);
				}
			}
			if (tempRes != null) {
				double oec = overalEvaluationCriterion(tempRes);
				System.out.println(prefix + "OEC for current features: " + oec
						+ " (" + features + ")");
				if (oec < bestOEC) {
					bestOEC = oec;
					bestFeatureSet = features;
					improvedOEC = true;
				}
				System.out.println(prefix + "Current best OEC: " + bestOEC
						+ " for "
						+ PrettyPrint.toPrettyLine(bestFeatureSet, ", "));
			}
		}

		System.out.println(prefix + "Evaluated " + numNewFeatureSetsExplored
				+ " new feaature sets");
		if (improvedOEC) {
			System.out.println(prefix + "Going to dig deeper on "
					+ PrettyPrint.toPrettyLine(bestFeatureSet, ", "));
			bestOEC = search(bestFeatureSet, allowedFeatures, c, dataSet,
					prefix, bestOEC);
		} else
			System.err
					.println(prefix + "Stopped making progress --- quitting!");
		return bestOEC;
	}

	protected void reportBestResults(File[] reportFiles) throws IOException {
		System.out
				.println("Settings\tOEC\tfeatures\tMT pred error\tworst\tIP error\tworst\t% motiv\tworst\trecall\tworst\tMD/ID error\tworst\t");
		for (File f : reportFiles) {
			if (f.exists()) {
				cache.clear();
				populateCacheFromFile(f);
				FeatureSelectionRecord r = findBestInCache();
				System.out.println(f.getName() + "\t"
						+ overalEvaluationCriterion(r.results) + "\t" + r);
			}
		}
		cache.clear();
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		final FeatureSelection selection = new FeatureSelection();

		File trainFileMixed = new File(
				Settings.MIXED_NORMALIZED_COMBINED_DATA_FILE + ".arff");
		File trainFileGlobal = new File(
				Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE + ".arff");

		File recordFileLogisticMixed = new File(
				Settings.TEMPORARY_FILE_DIRECTORY
						+ "featureSelection-Logistic-c2-mixed.txt");
		File recordFileLogisticGlobal = new File(
				Settings.TEMPORARY_FILE_DIRECTORY
						+ "featureSelection-Logistic-c2-global.txt");
		File recordFileLogisticGlobalTargetAgnostic = new File(
				Settings.TEMPORARY_FILE_DIRECTORY
						+ "featureSelection-Logistic-c2-global-targetAgnostic.txt");
		File recordFileLogisticMixedTargetAgnostic = new File(
				Settings.TEMPORARY_FILE_DIRECTORY
						+ "featureSelection-Logistic-c2-mixed-targetAgnostic.txt");

		// quickly report on the status of the feature selection process so far
		File[] reportFiles = new File[] { recordFileLogisticGlobal,
				recordFileLogisticMixed,
				recordFileLogisticGlobalTargetAgnostic,
				recordFileLogisticMixedTargetAgnostic, };
		selection.reportBestResults(reportFiles);

		// GLOBAL LOGISTIC
		File trainFile = trainFileGlobal;
		File recordFile = recordFileLogisticGlobal;

		selection.recordFile = recordFile;
		selection.populateCacheFromFile(recordFile);

		final DataSet trainDataSet = DataSet.fromArffFile(trainFile);

		// start a few threads from the current best set
		selection.startParallelFeatureSelection(
				Settings.BEST_FEATURES_LOGISTIC_GLOBAL,
				Settings.ALLOWED_FEATURES, trainDataSet, 2, "Cur");

		// start some from scratch
		selection.startParallelFeatureSelection(new String[] { "Class" },
				Settings.ALLOWED_FEATURES, trainDataSet, 2, "Null");

		// start a few from some promising things we have encountered already
		String[] tempStartingFeatures = selection
				.getRandomGoodRecordFromCache(.05).features
				.toArray(new String[] {});
		selection.startParallelFeatureSelection(tempStartingFeatures,
				Settings.ALLOWED_FEATURES, trainDataSet, 1, "RandA");
		tempStartingFeatures = selection.getRandomGoodRecordFromCache(.05).features
				.toArray(new String[] {});
		selection.startParallelFeatureSelection(tempStartingFeatures,
				Settings.ALLOWED_FEATURES, trainDataSet, 1, "RandB");
	}

	/**
	 * Starts several instances of feature selection search given the starting
	 * conditions
	 * 
	 * @param startingFeatureSet
	 *            the starting feature set (has to include "Class")
	 * @param allowedFeatures
	 *            the set of features that may be considered (has to include
	 *            "Class")
	 * @param dataSet
	 *            the data set to be used in evaluation
	 * @param numberOfParallelSearches
	 *            how many parallel threads to start
	 * @param pref
	 *            a prefix that will be prepended to major log messages (so that
	 *            you can tell which thread is doing what)
	 */
	protected void startParallelFeatureSelection(
			final String[] startingFeatureSet, final String[] allowedFeatures,
			final DataSet dataSet, int numberOfParallelSearches, String pref) {

		for (int i = 0; i < numberOfParallelSearches; i++) {
			final String prefix = pref + i + ": ";
			Thread t = new Thread() {
				public void run() {
					try {
						PositiveAndUnlabeledClassifier cLogistic = new PositiveAndUnlabeledClassifier(
								Classifier.forName(
										"weka.classifiers.functions.Logistic",
										new String[] { "-R", "1.0E-8", "-M",
												"-1" }));
						cLogistic.setMethodForEvaluatingC(2);
						String[] tempStartingFeatures = startingFeatureSet;
						while (true) {
							try {
								search(ArrayUtils
										.asArrayList(tempStartingFeatures),
										allowedFeatures, cLogistic, dataSet,
										prefix, Double.MAX_VALUE);
							} catch (Exception e) {
								e.printStackTrace();
							}
							tempStartingFeatures = getRandomGoodRecordFromCache(.05).features
									.toArray(new String[] {});
							System.err.println("Random restart starting with "
									+ PrettyPrint.toPrettyLine(
											tempStartingFeatures, ", "));
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			System.out.println("** Starting a search thread");
			t.start();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			}
		}

	}

	/**
	 * @author kgajos
	 * 
	 *         A small class for storing the intermediate results of feature
	 *         selection
	 */
	protected class FeatureSelectionRecord implements
			Comparable<FeatureSelectionRecord> {
		protected ArrayList<String> features;
		protected ClassifierEvalStats results;

		public FeatureSelectionRecord(List<String> features,
				ClassifierEvalStats results) {
			super();
			setFeatures(features);
			this.results = results;
		}

		/**
		 * Initialized a record from a string representation
		 * 
		 * @param line
		 */
		public FeatureSelectionRecord(String line) {
			StringTokenizer t1 = new StringTokenizer(line, "\t");
			String featuresString = t1.nextToken();
			StringTokenizer featureTokenizer = new StringTokenizer(
					featuresString, ",");
			features = new ArrayList<String>();
			while (featureTokenizer.hasMoreElements())
				features.add(featureTokenizer.nextToken());
			Collections.sort(features);

			results = ClassifierEvalStats.fromReport1(t1);
		}

		public void setResults(ClassifierEvalStats r) {
			results = r;
		}

		public void setFeatures(List<String> f) {
			features = new ArrayList<String>(f);
			Collections.sort(features);
		}

		public ArrayList<String> getFeatures() {
			return features;
		}

		public ClassifierEvalStats getResults() {
			return results;
		}

		public String toString() {
			// the output of this method should be parseable by the
			// FeatureSelectionRecord(String line) constructor
			return PrettyPrint.toPrettyLine(features, ",") + "\t"
					+ results.getReport1();
		}

		@Override
		public int compareTo(FeatureSelectionRecord other) {
			Double thisOEC = overalEvaluationCriterion(results);
			Double otherOEC = overalEvaluationCriterion(other.results);
			return thisOEC.compareTo(otherOEC);
		}
	}

	protected class FeatureSet {
		protected ArrayList<String> features;
		protected int hashCode;

		public FeatureSet(List<String> features) {
			this.features = new ArrayList<String>(features);
			Collections.sort(this.features);
			for (String f : this.features)
				hashCode += f.hashCode();
		}

		@Override
		public boolean equals(Object arg0) {
			if (arg0 instanceof FeatureSet) {
				FeatureSet other = (FeatureSet) arg0;
				if (features == null && other.features == null)
					return true;
				if (features == null || other.features == null)
					return false;
				if (features.size() != other.features.size())
					return false;
				for (int i = 0; i < features.size(); i++)
					if (!features.get(i).equals(other.features.get(i)))
						return false;
				return true;
			}
			return false;
		}

		@Override
		public int hashCode() {
			return hashCode;
		}

		public String toString() {
			return PrettyPrint.toPrettyLine(features, ",");
		}

	}
}
