package edu.harvard.seas.iis.abilities.analysis;

import java.awt.Point;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import edu.harvard.seas.iis.util.collections.ArrayUtils;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.geom2D.Geom2DUtils;

public class Movement implements Serializable {

	private static final long serialVersionUID = 1L;

	// movement info
	protected double targetSize, distanceToTarget, indexOfDifficulty;

	// uniformly sampled movement points
	protected Vector<MovementPoint> resampledAndFilteredMovementPoints;

	// original points (not resampled)
	protected Vector<MovementPoint> rawMovementPoints = new Vector<MovementPoint>();;

	// targetX and targetY capture the location of the upper left corner of the
	// target;
	protected int targetCenterX, targetCenterY, targetX, targetY, targetWidth,
			targetHeight;
	protected String targetType;

	// normalized target is the target position after translation and rotation
	// so that it should lie on x-axis precisely at (distance,0);

	// firstAcquisitionAttempt is the first click or the first goal line
	// crossing (whether or not it was correct) -- used for computing We
	protected Point home, normalizedTarget, firstAcquisitionAttempt;

	// angle of the movement (from home to target) in degrees
	protected double angle;

	protected double startTime = -1, movementTime,
			timeToFirstAcquisitionAttempt;

	protected double movementPointsToFirstAcquisitionAttempt = 0;

	protected double movementDistance = 0.0,
			distanceToFirstAcquisitionAttempt = 0.0, lentghToDistanceRatio;
	protected double fractionOfDistanceCoveredInFirstSubmovement = 0;

	protected boolean insideTarget = false, targetAcquired = false;

	protected int numEntries = 0, numClicks = 0, numMisses = 0, numHits = 0,
			missesPresent = 0, taskAxisCrossings = 0,
			movementDirectionChanges = 0, orthogonalDirectionChanges = 0,
			taskAxisCrossingsTillFirstAttempt = 0,
			movementDirectionChangesTillFirstAttempt = 0,
			orthogonalDirectionChangesTillFirstAttempt = 0, numSubmovements4,
			numSubmovements5;

	protected double lastAxisSide = 0, lastYdir = 0, lastXdir = 0;

	protected double lastNormalizedX = 0, lastNormalizedY = 0;

	protected double integralSquareJerk = 0, averageAbsoluteJerk = 0;

	protected MovementPoint lastMovementPoint;

	// detailed stats (peaks, crossings, etc) for the different movement
	// characteristics
	protected TimeSeriesStats speedStats, rawSpeedStats, accelStats, jerkStats;

	// these stats are calculated over the entire movement
	protected double movementVariability = 0, movementError = 0,
			movementOffset = 0;

	protected double movementVariabilityTillFirstAttempt = 0,
			movementErrorTillFirstAttempt = 0,
			movementOffsetTillFirstAttempt = 0;

	// used by other parts of the system to store additional meta data about a
	// movement
	protected Hashtable<String, Object> additionalMetaData = new Hashtable<String, Object>();

	public Movement(Point home, double startTime, double movementTime) {
		this.home = home;
		this.startTime = startTime;
		this.movementTime = movementTime;
	}

	/**
	 * Record a click event that occurred outside the target
	 * 
	 * @param x
	 * @param y
	 * @param timeStamp
	 */
	public void addMissedClickEvent(int x, int y, double timeStamp) {
		addClickEvent(x, y, timeStamp, false, "", 0, 0, 0, 0, 0, 0);
	}

	/**
	 * Record a click event. Information about the target is only relevant if
	 * the click was a hit (i.e., if it occurred inside the target)
	 * 
	 * @param x
	 *            x-coordinate of the click event
	 * @param y
	 *            y-coordinate of the click event
	 * @param timeStamp
	 * @param hit
	 *            true if click occurred on the target; false otherwise
	 * @param targetType
	 *            arbitrary annotation
	 * @param targetX
	 *            x-coordinate of the upper-left corner of the target
	 * @param targetY
	 *            y-coordinate of the upper-left corner of the target
	 * @param targetCenterX
	 * @param targetCenterY
	 * @param targetWidth
	 * @param targetHeight
	 */
	public void addClickEvent(int x, int y, double timeStamp, boolean hit,
			String targetType, int targetX, int targetY, int targetCenterX,
			int targetCenterY, int targetWidth, int targetHeight) {

		numClicks++;
		// check if this is the first target acquisition
		if (firstAcquisitionAttempt == null)
			markFirstAcquisitionAttempt(x, y, timeStamp);

		if (hit) {
			numHits++;
			if (!targetAcquired)
				movementTime = timeStamp - startTime;
			targetAcquired = true;

			this.targetX = targetX;
			this.targetY = targetY;
			this.targetWidth = targetWidth;
			this.targetHeight = targetHeight;
			this.targetCenterX = targetCenterX;
			this.targetCenterY = targetCenterY;

			targetSize = Math.min(targetWidth, targetHeight);

			distanceToTarget = Geom2DUtils.getDistance(home.x, home.y,
					targetCenterX, targetCenterY);
			indexOfDifficulty = Math.log(distanceToTarget / targetSize)
					/ Math.log(2);

			angle = Math.toDegrees(Geom2DUtils.getAngle(home, new Point(
					targetCenterX, targetCenterY)));
			normalizedTarget = new Point(targetCenterX - home.x, targetCenterY
					- home.y);
			normalizedTarget = Geom2DUtils.rotate(normalizedTarget, -Math
					.toRadians(angle));
		} else {
			numMisses++;
			if (firstAcquisitionAttempt == null)
				markFirstAcquisitionAttempt(x, y, timeStamp);
		}
	}

	protected void computeCompleteStatistics() {
		if (numMisses > 0)
			missesPresent = 1;

		// resample at uniform intervals
		Vector<MovementPoint> resampledMovementPoints = MovementPoint.resample(
				rawMovementPoints, home, angle, Constants.SAMPLING_INTERVAL);

		// initial 30Hz low pass filter (performed on Normalized XY)
		MovementPoint.initialSmoothing(resampledMovementPoints);
		// differentiating filter to compute velocity
		MovementPoint.computeVelocity(resampledMovementPoints);
		// differentiating filter to compute acceleration
		MovementPoint.computeAcceleration(resampledMovementPoints);
		// differentiating filter to compute jerk
		MovementPoint.computeJerk(resampledMovementPoints);
		// final 7Hz low pass filter on Normalized XY, acceleration and jerk
		MovementPoint.finalSmoothing(resampledMovementPoints);

		// aggregate stats
		computeStats(resampledMovementPoints);
		computeAggregateStats(resampledMovementPoints);

		// final 7Hz low pass filter on distance to target
		MovementPoint.smoothDistanceToTarget(resampledMovementPoints);
		// signed velocity for Jake
		computeSignedVelocity(resampledMovementPoints);

		resampledAndFilteredMovementPoints = resampledMovementPoints;

		numSubmovements4 = countSubmovements(.4, .04, resampledMovementPoints);
		if (lastPointOfFirstSubmovement != null)
			fractionOfDistanceCoveredInFirstSubmovement = Math
					.abs(lastPointOfFirstSubmovement.normalizedX
							/ distanceToTarget);
		else
			fractionOfDistanceCoveredInFirstSubmovement = 1;

		numSubmovements5 = countSubmovements(.5, .05, resampledMovementPoints);
	}

	/**
	 * record information about the first acquisition attempt
	 * 
	 * @param curNode
	 */
	protected void markFirstAcquisitionAttempt(int x, int y, double time) {
		firstAcquisitionAttempt = new Point(x, y);
		timeToFirstAcquisitionAttempt = time - startTime;
	}

	/**
	 * Add new intermediate movement to the trajectory
	 * 
	 * @param x
	 * @param y
	 * @param timeStamp
	 * @param insideTarget
	 *            set true if this point is known to be inside the target
	 */
	public void addMovementPoint(double x, double y, double timeStamp,
			boolean insideTarget) {
		addMovementPoint(new MovementPoint(home, angle, x, y, timeStamp,
				insideTarget));
	}

	protected void addMovementPoint(MovementPoint movementPoint) {
		rawMovementPoints.addElement(movementPoint);
		if (!insideTarget && movementPoint.insideTarget)
			numEntries++;
		insideTarget = movementPoint.insideTarget;

		movementPoint.setRelativeT(movementPoint.getT() - startTime);
	}

	private boolean hasChanged(double reference, double cur) {
		// initial 0 means that the value hadn't been set yet
		if (reference == 0)
			return false;
		return ((reference > 0 && cur < 0) || (reference < 0 && cur > 0));
	}

	private double getNewIndicator(double oldRef, double cur) {
		if (cur == 0)
			return oldRef;
		return cur;
	}

	/**
	 * Filters out consecutive points with identical time stamps (the last event
	 * with a given time stamp is retained); this is just in case the log
	 * contains such duplicates; wiht our current implementation of the parser,
	 * such duplicates are removed at read time
	 */
	// protected void cleanupMovementPoints() {
	// rawMovementPoints = movementPoints;
	// movementPoints = new Vector<MovementPoint>();
	// MovementPoint lastPoint = null;
	// for (MovementPoint m : rawMovementPoints) {
	// if (lastPoint != null && lastPoint.getT() == m.getT())
	// movementPoints.remove(lastPoint);
	// movementPoints.addElement(m);
	// lastPoint = m;
	// }
	// }

	/**
	 * computes stats for this trial
	 */
	protected void computeStats(Vector<MovementPoint> mP) {
		boolean pastFirstAcquisitionAttempt = false;
		double posDiff;
		for (int i = 0; i < mP.size(); i++) {
			MovementPoint movementPoint = mP.get(i);
			double curAxisSide = movementPoint.getNormalizedY();
			double curYdir = movementPoint.getNormalizedY() - lastNormalizedY;
			double curXdir = movementPoint.getNormalizedX() - lastNormalizedX;

			pastFirstAcquisitionAttempt = movementPoint.getRelativeT() > timeToFirstAcquisitionAttempt;

			if (hasChanged(lastAxisSide, curAxisSide)) {
				taskAxisCrossings++;
				if (!pastFirstAcquisitionAttempt)
					taskAxisCrossingsTillFirstAttempt++;
			}
			if (hasChanged(lastYdir, curYdir)) {
				movementDirectionChanges++;
				if (!pastFirstAcquisitionAttempt)
					movementDirectionChangesTillFirstAttempt++;
			}
			if (hasChanged(lastXdir, curXdir)) {
				orthogonalDirectionChanges++;
				if (!pastFirstAcquisitionAttempt)
					orthogonalDirectionChangesTillFirstAttempt++;
			}

			if (lastMovementPoint != null) {
				posDiff = Geom2DUtils.getDistance(movementPoint.x,
						movementPoint.y, lastMovementPoint.x,
						lastMovementPoint.y);
				movementDistance += posDiff;
				movementPoint.rawVelocity = posDiff
						/ Constants.SAMPLING_INTERVAL;
				if (!pastFirstAcquisitionAttempt)
					distanceToFirstAcquisitionAttempt += Geom2DUtils
							.getDistance(movementPoint.x, movementPoint.y,
									lastMovementPoint.x, lastMovementPoint.y);
			}

			lastAxisSide = getNewIndicator(lastAxisSide, curAxisSide);
			lastYdir = getNewIndicator(lastYdir, curYdir);
			lastXdir = getNewIndicator(lastXdir, curXdir);

			lastNormalizedX = movementPoint.getNormalizedX();
			lastNormalizedY = movementPoint.getNormalizedY();
			lastMovementPoint = movementPoint;
		}
	}

	/**
	 * Computing stats for the entire movement
	 */
	protected void computeAggregateStats(Vector<MovementPoint> mP) {

		MovementPoint lastPoint = null;
		for (MovementPoint m : mP) {
			// normalized time
			m.setNormalizedT((double) (m.getT() - startTime)
					/ (double) movementTime);
			// distance from target
			m.setDistanceFromTarget(Geom2DUtils.getDistance(m.getX(), m.getY(),
					targetCenterX, targetCenterY));

			// compute displacement from smoothed trajectory
			if (lastPoint == null)
				m.displacement = 0;
			else
				m.displacement = lastPoint.displacement
						+ Geom2DUtils.getDistance(lastPoint.normalizedX,
								lastPoint.normalizedY, m.normalizedX,
								m.normalizedY);

			movementOffset += m.getNormalizedY();
			movementError += Math.abs(m.getNormalizedY());

			if (m.getRelativeT() <= timeToFirstAcquisitionAttempt) {
				movementOffsetTillFirstAttempt += m.getNormalizedY();
				movementErrorTillFirstAttempt += Math.abs(m.getNormalizedY());
				movementPointsToFirstAcquisitionAttempt++;
				integralSquareJerk += Math.pow(m.jerk, 2)
						* Constants.SAMPLING_INTERVAL;
				averageAbsoluteJerk += Math.abs(m.jerk);
			}

			lastPoint = m;
		}
		movementOffset = movementOffset / (double) mP.size();
		movementError = movementError / (double) mP.size();

		movementOffsetTillFirstAttempt = movementOffsetTillFirstAttempt
				/ movementPointsToFirstAcquisitionAttempt;
		movementErrorTillFirstAttempt = movementErrorTillFirstAttempt
				/ movementPointsToFirstAcquisitionAttempt;

		lentghToDistanceRatio = distanceToFirstAcquisitionAttempt
				/ distanceToTarget;

		for (MovementPoint m : mP) {
			movementVariability += Math.pow(
					m.getNormalizedY() - movementOffset, 2);
			if (m.getRelativeT() <= timeToFirstAcquisitionAttempt)
				movementVariabilityTillFirstAttempt += Math.pow(m
						.getNormalizedY()
						- movementOffset, 2);
		}
		movementVariability = movementVariability / (double) (mP.size() - 1);
		movementVariability = Math.sqrt(movementVariability);

		movementVariabilityTillFirstAttempt = movementVariabilityTillFirstAttempt
				/ (movementPointsToFirstAcquisitionAttempt - 1);
		movementVariabilityTillFirstAttempt = Math
				.sqrt(movementVariabilityTillFirstAttempt);

		// compute stats for speed, accel and jerk

		// computing stats only till the first click/miss/crossing
		// but relative time is computed with respect to the first PROPER target
		// acquisition
		int numSamplesTillFirstAcquisitionAttempt = (int) (timeToFirstAcquisitionAttempt
				/ Constants.SAMPLING_INTERVAL + 1);
		speedStats = new TimeSeriesStats(MovementPoint.getVelocityAsArray(mP),
				numSamplesTillFirstAcquisitionAttempt,
				Constants.SAMPLING_INTERVAL, movementTime);
		// request stats on how many times speed went over 0.5px/ms
		speedStats.setRaisngThreshhold(0.5);

		// raw speed stats (for getting the real max)
		rawSpeedStats = new TimeSeriesStats(MovementPoint
				.getRawVelocityAsArray(mP),
				numSamplesTillFirstAcquisitionAttempt,
				Constants.SAMPLING_INTERVAL, movementTime);
		// have to manually invoke stat calculation
		rawSpeedStats.calculateStats();

		accelStats = new TimeSeriesStats(MovementPoint
				.getAccelerationAsArray(mP),
				numSamplesTillFirstAcquisitionAttempt,
				Constants.SAMPLING_INTERVAL, movementTime);
		jerkStats = new TimeSeriesStats(MovementPoint.getJerkAsArray(mP),
				numSamplesTillFirstAcquisitionAttempt,
				Constants.SAMPLING_INTERVAL, movementTime);
	}

	/**
	 * sets signedVelocity for each movement point (velocity is given negative
	 * sign if the movement is occurring in the negative x-axis direction)
	 */
	protected void computeSignedVelocity(Vector<MovementPoint> mP) {
		if (mP.size() > 0)
			mP.elementAt(0).signedVelocity = mP.elementAt(0).velocity;
		for (int i = 1; i < mP.size(); i++) {
			if (mP.elementAt(i).rawNormalizedX
					- mP.elementAt(i - 1).rawNormalizedX >= 0)
				mP.elementAt(i).signedVelocity = mP.elementAt(i).velocity;
			else
				mP.elementAt(i).signedVelocity = -mP.elementAt(i).velocity;
		}
	}

	protected MovementPoint lastPointOfFirstSubmovement;

	/**
	 * Counts submovements: a new submovement occurs if speed first drops below
	 * lower threshhold and then goes over the upper one
	 * 
	 * @param upperThreshhold
	 * @param lowerThreshhold
	 * @return
	 */
	protected int countSubmovements(double upperThreshhold,
			double lowerThreshhold, Vector<MovementPoint> movementPoints) {
		int res = 0;
		boolean underLowerThreshold = true;

		double curSpeed;

		for (int i = 1; i < movementPoints.size(); i++) {
			curSpeed = movementPoints.elementAt(i).rawVelocity;
			if (underLowerThreshold && curSpeed >= upperThreshhold) {
				res++;
				underLowerThreshold = false;
			}
			if (curSpeed < lowerThreshhold) {
				if (!underLowerThreshold && res == 1)
					lastPointOfFirstSubmovement = movementPoints.elementAt(i);
				underLowerThreshold = true;
			}
		}
		return Math.max(1, res);
	}

	public double getDistanceOfFirstAcquisitionAttemptFromTarget() {
		return Geom2DUtils.getDistance(targetCenterX, targetCenterY,
				firstAcquisitionAttempt.x, firstAcquisitionAttempt.y);
	}

	protected MovementPoint[] getFilteredMovementPointsNearTime(double time) {
		MovementPoint[] res = new MovementPoint[2];
		if (time <= resampledAndFilteredMovementPoints.firstElement().getT()) {
			res[0] = null;
			res[1] = resampledAndFilteredMovementPoints.firstElement();
		} else if (time >= resampledAndFilteredMovementPoints.lastElement()
				.getT()) {
			res[0] = resampledAndFilteredMovementPoints.lastElement();
			res[1] = null;
		} else {
			int cnt = 0;
			while (resampledAndFilteredMovementPoints.elementAt(cnt + 1).getT() < time)
				cnt++;
			res[0] = resampledAndFilteredMovementPoints.elementAt(cnt);
			res[1] = resampledAndFilteredMovementPoints.elementAt(cnt + 1);
		}
		return res;
	}

	public double[] getRawPositionAtTime(double time) {
		MovementPoint[] neighbors = getFilteredMovementPointsNearTime(time);
		if (neighbors[1] == null)
			return new double[] { lastMovementPoint.rawNormalizedX,
					lastMovementPoint.rawNormalizedY };
		if (neighbors[0] == null)
			return new double[] { 0, 0 };

		double interpolatedX = (time - neighbors[0].getT())
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[0].rawNormalizedX;
		interpolatedX += (neighbors[1].getT() - time)
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[1].rawNormalizedX;

		double interpolatedY = (time - neighbors[0].getT())
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[0].rawNormalizedY;
		interpolatedY += (neighbors[1].getT() - time)
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[1].rawNormalizedY;

		return new double[] { interpolatedX, interpolatedY };
	}

	public double getSpeedAtTime(double time) {
		MovementPoint[] neighbors = getFilteredMovementPointsNearTime(time);
		if (neighbors[0] == null || neighbors[1] == null)
			return 0;

		double interpolated = (time - neighbors[0].getT())
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[0].getVelocity();
		interpolated += (neighbors[1].getT() - time)
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[1].getVelocity();
		return interpolated;
	}

	public double getAccelerationAtTime(double time) {
		MovementPoint[] neighbors = getFilteredMovementPointsNearTime(time);
		if (neighbors[0] == null || neighbors[1] == null)
			return 0;

		double interpolated = (time - neighbors[0].getT())
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[0].getAcceleration();
		interpolated += (neighbors[1].getT() - time)
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[1].getAcceleration();
		return interpolated;
	}

	public double getJerkAtTime(double time) {
		MovementPoint[] neighbors = getFilteredMovementPointsNearTime(time);
		if (neighbors[0] == null || neighbors[1] == null)
			return 0;

		double interpolated = (time - neighbors[0].getT())
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[0].getJerk();
		interpolated += (neighbors[1].getT() - time)
				/ (neighbors[1].getT() - neighbors[0].getT())
				* neighbors[1].getJerk();
		return interpolated;
	}

	public String getTargetType() {
		return targetType;
	}

	public double getStartTime() {
		return startTime;
	}

	public double getEndTime() {
		return lastMovementPoint.getT();
	}

	public MovementPoint getLastMovementPoint() {
		return lastMovementPoint;
	}

	public double getMovementDuration() {
		return movementTime;
	}

	/**
	 * Returns the actual distance traveled (not necessary in a straight line)
	 * 
	 * @return
	 */
	public double getMovementDistance() {
		return movementDistance;
	}

	public double getMovementAmplitude() {
		return distanceToTarget;
	}

	/**
	 * Allows additional meta data to be stored with this movement
	 * 
	 * @param key
	 * @param value
	 * @return old value for the key (or null, if nothing was stored under that
	 *         key before)
	 */
	public Object setAdditionalMetaData(String key, Object value) {
		Object oldValue = additionalMetaData.get(key);
		additionalMetaData.put(key, value);
		return oldValue;
	}

	/**
	 * Retrieves additional meta data
	 * 
	 * @param key
	 * @return
	 */
	public Object getAdditionalMetaData(String key) {
		return additionalMetaData.get(key);
	}

	private static String[] HEADINGS = new String[] { "#Start time",
			"Target type", "Target width", "Target height", "A", "W", "ID",
			"Angle", "Clicks", "Hits", "Misses", "AnyMisses?", "Entries",
			"Movement Time", "Time to first acquisition attempt",
			"Movement distance", "Distance to first acquisition attempt",
			"LDI", "Task axis crossings", "Movement direction changes",
			"Orthogonal direction changes", "Movement error",
			"Movement offset", "Movement variability", "fTAC", "fMDC", "fODC",
			"fME", "fMO", "fMV",
			"Distance of first acquisition attempt from target center",
			"Submovements (.4px/ms)", "Submovements (.5px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-RawMaxVal", "S-RawMinVal", "fIntegralSquareJerk",
			"fAverageAbsoluteJerk" };

	public static String[] getSummaryHeadingsNew() {
		String[] Sheadings = TimeSeriesStats.generateReportHeaders("S");
		String[] Aheadings = TimeSeriesStats.generateReportHeaders("A");
		String[] Jheadings = TimeSeriesStats.generateReportHeaders("J");
		String[] res = ArrayUtils.appendArrays(HEADINGS, Sheadings);
		res = ArrayUtils.appendArrays(res, Aheadings);
		res = ArrayUtils.appendArrays(res, Jheadings);
		return res;
	}

	public Hashtable<String, Object> getMovementFeatures() {
		Hashtable<String, Object> res = new Hashtable<String, Object>();
		res.put("#Start time", startTime);
		res.put("Target type", targetType);
		res.put("Target width", targetWidth);
		res.put("Target height", targetHeight);
		res.put("A", distanceToTarget);
		res.put("W", targetSize);
		res.put("ID", indexOfDifficulty);
		res.put("Angle", angle);
		res.put("Clicks", numClicks);
		res.put("Hits", numHits);
		res.put("Misses", numMisses);
		res.put("AnyMisses?", missesPresent);
		res.put("Entries", numEntries);
		res.put("Movement Time", movementTime);
		res.put("Mean Speed", (movementDistance / movementTime));
		res.put("Time to first acquisition attempt",
				timeToFirstAcquisitionAttempt);
		res.put("Movement distance", movementDistance);
		res.put("Distance to first acquisition attempt",
				distanceToFirstAcquisitionAttempt);
		res.put("LDI", lentghToDistanceRatio);
		res.put("Task axis crossings", taskAxisCrossings);
		res.put("Movement direction changes", movementDirectionChanges);
		res.put("Orthogonal direction changes", orthogonalDirectionChanges);
		res.put("Movement error", movementError);
		res.put("Movement offset", movementOffset);
		res.put("Movement variability", movementVariability);
		res.put("fTAC", taskAxisCrossingsTillFirstAttempt);
		res.put("fMDC", movementDirectionChangesTillFirstAttempt);
		res.put("fODC", orthogonalDirectionChangesTillFirstAttempt);
		res.put("fME", movementErrorTillFirstAttempt);
		res.put("fMO", movementOffsetTillFirstAttempt);
		res.put("fMV", movementVariabilityTillFirstAttempt);
		res.put("Distance of first acquisition attempt from target center",
				getDistanceOfFirstAcquisitionAttemptFromTarget());
		res.put("Submovements (.4px/ms)", numSubmovements4);
		res.put("Submovements (.5px/ms)", numSubmovements5);
		res
				.put(
						"Fraction of distance to target covered in the first submovement",
						fractionOfDistanceCoveredInFirstSubmovement);
		res.put("S-RawMaxVal", rawSpeedStats.maxVal);
		res.put("S-RawMinVal", rawSpeedStats.minVal);
		res.put("fIntegralSquareJerk", integralSquareJerk);
		res.put("fAverageAbsoluteJerk", averageAbsoluteJerk);
		speedStats.setTimeSeriesFeatures(res, "S");
		accelStats.setTimeSeriesFeatures(res, "A");
		jerkStats.setTimeSeriesFeatures(res, "J");
		return res;
	}

	public static String getSummaryHeadings() {
		String res = "#Start time" + Constants.SEPARATOR;
		res += "Target type" + Constants.SEPARATOR;
		res += "Target width" + Constants.SEPARATOR;
		res += "Target height" + Constants.SEPARATOR;
		res += "A" + Constants.SEPARATOR;
		res += "W" + Constants.SEPARATOR;
		res += "ID" + Constants.SEPARATOR;
		res += "Angle" + Constants.SEPARATOR;
		res += "Clicks" + Constants.SEPARATOR;
		res += "Hits" + Constants.SEPARATOR;
		res += "Misses" + Constants.SEPARATOR;
		res += "AnyMisses?" + Constants.SEPARATOR;
		res += "Entries" + Constants.SEPARATOR;
		res += "Movement Time" + Constants.SEPARATOR;
		res += "Time to first acquisition attempt" + Constants.SEPARATOR;
		res += "Movement distance" + Constants.SEPARATOR;
		res += "Distance to first acquisition attempt" + Constants.SEPARATOR;
		res += "LDI" + Constants.SEPARATOR;
		res += "Task axis crossings" + Constants.SEPARATOR;
		res += "Movement direction changes" + Constants.SEPARATOR;
		res += "Orthogonal direction changes" + Constants.SEPARATOR;
		res += "Movement error" + Constants.SEPARATOR;
		res += "Movement offset" + Constants.SEPARATOR;
		res += "Movement variability" + Constants.SEPARATOR;
		res += "fTAC" + Constants.SEPARATOR;
		res += "fMDC" + Constants.SEPARATOR;
		res += "fODC" + Constants.SEPARATOR;
		res += "fME" + Constants.SEPARATOR;
		res += "fMO" + Constants.SEPARATOR;
		res += "fMV" + Constants.SEPARATOR;
		res += "Distance of first acquisition attempt from target center"
				+ Constants.SEPARATOR;

		res += "Submovements (.4px/ms)" + Constants.SEPARATOR;
		res += "Submovements (.5px/ms)" + Constants.SEPARATOR;
		res += "Fraction of distance to target covered in the first submovement"
				+ Constants.SEPARATOR;
		res += PrettyPrint.toPrettyLine(TimeSeriesStats
				.generateReportHeaders("S"), Constants.SEPARATOR);
		res += "S-RawMaxVal" + Constants.SEPARATOR;
		res += "S-RawMinVal" + Constants.SEPARATOR;
		res += PrettyPrint.toPrettyLine(TimeSeriesStats
				.generateReportHeaders("A"), Constants.SEPARATOR);
		res += PrettyPrint.toPrettyLine(TimeSeriesStats
				.generateReportHeaders("J"), Constants.SEPARATOR);

		res += "fIntegralSquareJerk" + Constants.SEPARATOR;
		res += "fAverageAbsoluteJerk";

		return res;
	}

	public String toSummaryString() {
		String res = startTime + Constants.SEPARATOR;
		res += targetType + Constants.SEPARATOR;
		res += targetWidth + Constants.SEPARATOR;
		res += targetHeight + Constants.SEPARATOR;
		res += distanceToTarget + Constants.SEPARATOR;
		res += targetSize + Constants.SEPARATOR;
		res += indexOfDifficulty + Constants.SEPARATOR;
		res += angle + Constants.SEPARATOR;
		res += numClicks + Constants.SEPARATOR;
		res += numHits + Constants.SEPARATOR;
		res += numMisses + Constants.SEPARATOR;
		res += missesPresent + Constants.SEPARATOR;
		res += numEntries + Constants.SEPARATOR;
		res += movementTime + Constants.SEPARATOR;
		res += timeToFirstAcquisitionAttempt + Constants.SEPARATOR;
		res += movementDistance + Constants.SEPARATOR;
		res += distanceToFirstAcquisitionAttempt + Constants.SEPARATOR;
		res += lentghToDistanceRatio + Constants.SEPARATOR;
		res += taskAxisCrossings + Constants.SEPARATOR;
		res += movementDirectionChanges + Constants.SEPARATOR;
		res += orthogonalDirectionChanges + Constants.SEPARATOR;
		res += movementError + Constants.SEPARATOR;
		res += movementOffset + Constants.SEPARATOR;
		res += movementVariability + Constants.SEPARATOR;
		res += taskAxisCrossingsTillFirstAttempt + Constants.SEPARATOR;
		res += movementDirectionChangesTillFirstAttempt + Constants.SEPARATOR;
		res += orthogonalDirectionChangesTillFirstAttempt + Constants.SEPARATOR;
		res += movementErrorTillFirstAttempt + Constants.SEPARATOR;
		res += movementOffsetTillFirstAttempt + Constants.SEPARATOR;
		res += movementVariabilityTillFirstAttempt + Constants.SEPARATOR;
		res += getDistanceOfFirstAcquisitionAttemptFromTarget()
				+ Constants.SEPARATOR;

		res += numSubmovements4 + Constants.SEPARATOR;
		res += numSubmovements5 + Constants.SEPARATOR;
		res += fractionOfDistanceCoveredInFirstSubmovement
				+ Constants.SEPARATOR;
		res += speedStats.generateReport(Constants.SEPARATOR);
		res += rawSpeedStats.maxVal + Constants.SEPARATOR;
		res += rawSpeedStats.minVal + Constants.SEPARATOR;
		res += accelStats.generateReport(Constants.SEPARATOR);
		res += jerkStats.generateReport(Constants.SEPARATOR);

		res += integralSquareJerk + Constants.SEPARATOR;
		res += averageAbsoluteJerk;

		return res;
	}

	public String toDetailedString(boolean includeHeader) {
		String res = "";
		if (includeHeader)
			res = MovementPoint.getDetailedHeadings() + "\n";
		for (MovementPoint p : resampledAndFilteredMovementPoints)
			res += p.toDetailedString() + "\n";
		return res;
	}

	public static String detailedReport(List<Movement> movements) {
		String res = "";
		for (Movement m : movements)
			res += m.toDetailedString(true) + "\n";
		return res;
	}

	public static void detailedReportToFile(List<Movement> movements,
			File file, boolean append) throws IOException {
		FileWriter writer = new FileWriter(file, append);
		for (Movement m : movements)
			writer.write(m.toDetailedString(true) + "\n");
		writer.close();
	}

	public static String summaryReport(List<Movement> movements,
			boolean includeHeader) {
		String res = "";
		if (includeHeader)
			res += getSummaryHeadings() + "\n";
		for (Movement m : movements)
			res += m.toSummaryString() + "\n";
		return res;
	}

	public String toString() {
		return "Movment with ID " + indexOfDifficulty + " with duration "
				+ movementTime + " toward " + targetType;
	}
}
