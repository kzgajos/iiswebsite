/*
 * Created on Oct 25, 2007
 */
package edu.harvard.seas.iis.abilities.analysis;

import java.util.Hashtable;

/**
 * Used to compute basic stats (peaks, 0-crossings, max, min, etc) of a time
 * series
 * 
 * @author kgajos
 */
public class TimeSeriesStats {

	protected double[] data;

	protected int numSamplesToConsider;

	protected double samplingInterval, timeNormalizingConstant;

	protected double raisingThreshhold = 0;

	protected boolean computedStats = false;

	public TimeSeriesStats(double[] data, int numSamplesToConsider,
			double samplingInterval, double timeNormalizingConstant) {
		super();
		this.data = data;
		this.numSamplesToConsider = Math.min(numSamplesToConsider, data.length);
		this.samplingInterval = samplingInterval;
		this.timeNormalizingConstant = timeNormalizingConstant;
	}

	/**
	 * This class can count how many times the value of a time series rose above
	 * a certain threshhold; to obtain such results, specify a threshhold here
	 * 
	 * @param t
	 */
	public void setRaisngThreshhold(double t) {
		raisingThreshhold = t;
		if (!computedStats)
			calculateStats();
	}

	public int getNumRaisingThreshholdCrossings() {
		return numRaisingThreshholdCrossings;
	}

	protected int numPeaks, num0crossings, numRaisingThreshholdCrossings;

	protected double maxVal = Double.MIN_VALUE, minVal = Double.MAX_VALUE;

	protected double firstPeakTime, firstPeakNormalizedTime;

	protected double lastPeakTime, lastPeakNormalizedTime;

	protected double maxPeakTime, maxPeakNormalizedTime;

	// captures whether the max peak is the first peak, the second, or later
	protected int maxPeakPosition;

	protected void calculateStats() {
		boolean pastFirstPeak = false;
		boolean rising = true;
		boolean falling = false;
		boolean max = false;

		for (int i = 0; i < numSamplesToConsider; i++) {
			max = false;
			if (data[i] < minVal)
				minVal = data[i];
			if (data[i] > maxVal) {
				max = true;
				maxVal = data[i];
				if (!pastFirstPeak) {
					firstPeakTime = (double) i * samplingInterval;
					firstPeakNormalizedTime = firstPeakTime
							/ timeNormalizingConstant;
				}
				maxPeakTime = (double) i * samplingInterval;
				maxPeakNormalizedTime = maxPeakTime / timeNormalizingConstant;
			}
			// detect if it is a peak
			// if it was rising and now it is falling, it is a peak
			// it is also a peak if there is negative slope at the start of the
			// series or a positive slope at the end of it
			if ((i > 0 && rising && data[i] < data[i - 1])
					|| (i > 0 && i == numSamplesToConsider - 1 && rising && data[i] >= data[i - 1])) {
				numPeaks++;
				pastFirstPeak = true;
				lastPeakTime = (double) i * samplingInterval;
				lastPeakNormalizedTime = lastPeakTime / timeNormalizingConstant;
				if (max)
					maxPeakPosition = numPeaks;
			}
			// detect 0 crossing
			// if rising and just got above 0, then a positive crossing
			if (i > 0 && rising && data[i] > 0 && data[i - 1] <= 0)
				num0crossings++;
			// if falling and just got below 0, then a negative crossing
			if (falling && data[i] < 0 && data[i - 1] >= 0)
				num0crossings++;

			// detect threshhold crossings (only going up)
			if (i > 0 && rising && data[i] > raisingThreshhold
					&& data[i - 1] <= raisingThreshhold)
				numRaisingThreshholdCrossings++;

			// set rising/falling
			if (i > 0 && data[i] > data[i - 1]) {
				rising = true;
				falling = false;
			}
			if (i > 0 && data[i] < data[i - 1]) {
				rising = false;
				falling = true;
			}
		}

		computedStats = true;
	}

	public static String[] generateReportHeaders(String timeSeriesShortName) {
		String[] res = new String[10];
		int i = 0;
		res[i++] = timeSeriesShortName + "-numPeaks";
		res[i++] = timeSeriesShortName + "-num0cross";
		res[i++] = timeSeriesShortName + "-T1stPeak";
		res[i++] = timeSeriesShortName + "-NormT1stPeak";
		res[i++] = timeSeriesShortName + "-TLastPeak";
		res[i++] = timeSeriesShortName + "-NormTLastPeak";
		res[i++] = timeSeriesShortName + "-TMaxPeak";
		res[i++] = timeSeriesShortName + "-NormTMaxPeak";
		res[i++] = timeSeriesShortName + "-MaxVal";
		res[i++] = timeSeriesShortName + "-MinVal";
		return res;
	}

	public void setTimeSeriesFeatures(Hashtable<String, Object> values,
			String timeSeriesShortName) {
		if (!computedStats)
			calculateStats();
		values.put(timeSeriesShortName + "-numPeaks", numPeaks);
		values.put(timeSeriesShortName + "-num0cross", num0crossings);
		values.put(timeSeriesShortName + "-T1stPeak", firstPeakTime);
		values.put(timeSeriesShortName + "-NormT1stPeak",
				firstPeakNormalizedTime);
		values.put(timeSeriesShortName + "-TLastPeak", lastPeakTime);
		values.put(timeSeriesShortName + "-NormTLastPeak",
				lastPeakNormalizedTime);
		values.put(timeSeriesShortName + "-TMaxPeak", maxPeakTime);
		values
				.put(timeSeriesShortName + "-NormTMaxPeak",
						maxPeakNormalizedTime);
		values.put(timeSeriesShortName + "-MaxVal", maxVal);
		values.put(timeSeriesShortName + "-MinVal", minVal);
	}

	public String generateReport(String separator) {
		if (!computedStats)
			calculateStats();
		String res = "";
		res += numPeaks + separator;
		res += num0crossings + separator;
		res += firstPeakTime + separator;
		res += firstPeakNormalizedTime + separator;
		res += lastPeakTime + separator;
		res += lastPeakNormalizedTime + separator;
		res += maxPeakTime + separator;
		res += maxPeakNormalizedTime + separator;
		res += maxVal + separator;
		res += minVal + separator;
		return res;
	}

}
