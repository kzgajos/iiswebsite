package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;

import weka.core.Attribute;
import weka.core.Instance;

/**
 * @author kgajos
 * 
 *         Tools for cleaning the data
 * 
 */
public class Clean {

	public final static int CLEAN1 = 1;
	public final static int CLEAN2 = 2;

	/**
	 * Method from removing obviously problematic instances (very low IDs,
	 * missed clicks, clicks on unknown targets)
	 * 
	 * @param fullDdataSet
	 * @return the original data set with bad instances removed
	 * @throws Exception
	 */
	public static DataSet cleanOnRawValues(DataSet fullDdataSet)
			throws Exception {
		DataSet cleanDataSet = new UserDataSet(fullDdataSet);

		Attribute attrMTbyID = cleanDataSet
				.attribute("Movement Time divided by ID");
		Attribute attrID = cleanDataSet.attribute("ID");
		Attribute attrTargetType = cleanDataSet.attribute("Target type");

		int initialSize = cleanDataSet.numInstances();

		int cnt = 0;
		for (int i = cleanDataSet.numInstances() - 1; i >= 0; i--) {
			Instance inst = cleanDataSet.instance(i);
			boolean toClean = false;
			String report = "";
			// remove movements where the target type start with "miss" or with
			// "other-"
			String targetType = inst.stringValue(attrTargetType).toLowerCase();
			if (targetType.startsWith("explicit-miss")
					|| (targetType.startsWith("other-") && !targetType
							.startsWith("other-button"))) {
				report += "a miss or a click on an unknown target type: "
						+ inst.stringValue(attrTargetType) + "; ";
				toClean = true;
			}

			// remove movements with Fitts' index of difficulty below a
			// threshold
			if (inst.value(attrID) < Settings.MINIMUM_ID_ALLOWED) {
				report += (toClean ? " and " : "");
				report += "ID < " + Settings.MINIMUM_ID_ALLOWED;
				toClean = true;
			}

			// other criteria for removing instances can go here

			if (toClean) {
				cnt++;
				cleanDataSet.delete(i);
			}
		}

		System.out.println("removed:\t" + cnt + "\tout of:\t" + initialSize);
		return cleanDataSet;
	}

	/**
	 * Method from removing outliers from the data. Right now, we throw away
	 * explicit movements where MT/ID is more than 2 stdevs away from the mean
	 * for the particular person
	 * 
	 * @param fullDdataSet
	 * @return the original data set with bad instances removed
	 * @throws Exception
	 */
	public static DataSet cleanOnTransformedData(DataSet fullDdataSet)
			throws Exception {
		DataSet cleanDataSet = new UserDataSet(fullDdataSet);
		DataSet explicitDataSet = fullDdataSet.getExplicitInstances();

		Attribute attrMTbyID = cleanDataSet
				.attribute("Movement Time divided by ID");
		Attribute attrClass = cleanDataSet.attribute("Class");

		int initialSize = cleanDataSet.numInstances();

		int cnt = 0;
		double MTbyIDmean = explicitDataSet.meanOrMode(attrMTbyID);
		double MTbyIDstdev = Math.sqrt(explicitDataSet.variance(attrMTbyID));

		boolean toClean = false;
		Instance inst = null;
		for (int i = cleanDataSet.numInstances() - 1; i >= 0; i--) {
			inst = cleanDataSet.instance(i);
			String report = "";
			toClean = false;

			// remove explicit movements where MT/ID is more than 2 stdevs from
			// the mean
			if ("explicit".equals(inst.stringValue(attrClass))) {
				double val = inst.value(attrMTbyID);
				if (val > MTbyIDmean + 2 * MTbyIDstdev) {
					report += "MT/ID more than 2 stdevs from the mean: "
							+ inst.value(attrMTbyID) + "; ";
					toClean = true;
				}
			}

			// other criteria for removing instances can go here

			if (toClean) {
				cnt++;
				cleanDataSet.delete(i);
			}
		}

		System.out.println("removed:\t" + cnt + "\tout of:\t" + initialSize);
		return cleanDataSet;
	}

	/**
	 * A convenience method for cleaning an entire directory of data files
	 * 
	 * @param inputDirectory
	 *            a directory containing parsed movement data from one or more
	 *            users
	 * @param outputDirectory
	 *            a directory where the cleaned data should be written
	 * @throws Exception
	 */
	public static void clean(File inputDirectory, File outputDirectory,
			int cleanLevel) throws Exception {

		for (String user : Settings.ALL_USER_NAMES) {
			System.out.println("Processing data for user " + user);
			try {
				File f = new File(inputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				if (cleanLevel == CLEAN1)
					dataSet = cleanOnRawValues(dataSet);
				if (cleanLevel == CLEAN2)
					dataSet = cleanOnTransformedData(dataSet);

				dataSet.saveAsCSV(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".csv");
				dataSet.saveAsARFF(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");

			} catch (IOException e) {
				System.err.println("Trouble processing file for " + user);
				e.printStackTrace();
			}
		}
	}

}
