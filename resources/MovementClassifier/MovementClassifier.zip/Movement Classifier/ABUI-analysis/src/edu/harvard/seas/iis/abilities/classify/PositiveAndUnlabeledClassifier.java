package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import weka.classifiers.Classifier;
import weka.classifiers.functions.Logistic;
import weka.classifiers.meta.FilteredClassifier;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.unsupervised.attribute.Remove;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * @author Charles Herrmann
 * @author kgajos
 * 
 *         This classifier learns from positive and unlabeled examples. It is an
 *         implementation of the methods described in
 * 
 *         Elkan, C., & Noto, K. (2008). Learning classifiers from only positive
 *         and unlabeled data. KDD '08: Proceeding of the 14th ACM SIGKDD
 *         international conference on Knowledge discovery and data mining.
 */
public class PositiveAndUnlabeledClassifier extends Classifier {

	private static final long serialVersionUID = 1L;

	protected Classifier filteredClassifier, baseClassifier;
	protected double c = 0;
	protected static final int FOLDS = 10;
	protected int methodForEvaluatingC = 2;
	protected String[] allowedFeatures;

	public PositiveAndUnlabeledClassifier() throws Exception {
		this(new Logistic());
	}

	public PositiveAndUnlabeledClassifier(Classifier baseClassifier) {
		this(baseClassifier, Settings.ALLOWED_FEATURES);
	}

	/**
	 * @param baseClassifier
	 *            the underlying probabilistic classifier (See the paper for
	 *            more details);
	 * @param features
	 *            names of features that should be used by the classifier (this
	 *            allows for some features to be ignored); this list has to
	 *            include the "Class" feature
	 */
	public PositiveAndUnlabeledClassifier(Classifier baseClassifier,
			String[] features) {
		this.baseClassifier = baseClassifier;
		allowedFeatures = features;
	}

	protected void setUnderlyingClassifier(Instances dataSet) {
		FilteredClassifier fc = new FilteredClassifier();
		Remove rm = new Remove();
		int[] allowedFeaturesIndices = new int[allowedFeatures.length];
		for (int i = 0; i < allowedFeatures.length; i++) {
			if (dataSet.attribute(allowedFeatures[i]) == null)
				System.err.println("Can't find attribute for "
						+ allowedFeatures[i]);
			allowedFeaturesIndices[i] = dataSet.attribute(allowedFeatures[i])
					.index();
		}
		rm.setAttributeIndicesArray(allowedFeaturesIndices);
		rm.setInvertSelection(true);
		fc.setFilter(rm);
		fc.setClassifier(baseClassifier);
		filteredClassifier = fc;
	}

	public int getMethodForEvaluatingC() {
		return methodForEvaluatingC;
	}

	public void setMethodForEvaluatingC(int methodForEvaluatingC) {
		this.methodForEvaluatingC = methodForEvaluatingC;
	}

	public String[] getAllowedFeatures() {
		return allowedFeatures;
	}

	public void setAllowedFeatures(String[] allowedFeatures) {
		this.allowedFeatures = allowedFeatures;
	}

	public double classifyInstance(Instance point) throws Exception {
		return filteredClassifier.distributionForInstance(point)[1] / c > .5 ? 1
				: 0;
	}

	/**
	 * Returns the probability that a particular movement (represented by the
	 * Instance) was deliberate
	 * 
	 * @param point
	 * @return
	 * @throws Exception
	 */
	public double getDeliberateProbability(Instance point) throws Exception {
		return filteredClassifier.distributionForInstance(point)[1] / c;
	}

	// not quite correct, but good enough for now. generalizable to 3+?
	public double[] distributionForInstance(Instance inst) throws Exception {

		double[] dist = filteredClassifier.distributionForInstance(inst);
		for (int i = 0; i < dist.length; i++)
			dist[i] /= c;
		dist[0] = 1 - dist[1];
		return dist;
	}

	@Override
	public void buildClassifier(Instances trainSet) throws Exception {
		// set up filtering of features
		setUnderlyingClassifier(trainSet);

		// choose the right method for computing the c constant
		switch (methodForEvaluatingC) {
		case 1:
			buildClassifier1(trainSet);
			break;
		case 2:
			buildClassifier2(trainSet);
			break;
		case 3:
			buildClassifier3(trainSet);
			break;
		default:
			throw new IllegalArgumentException(
					"Illegal method for evaluaating C: " + methodForEvaluatingC);
		}
	}

	public void buildClassifier1(Instances trainSet) throws Exception {
		int n = 0;
		for (int i = 0; i < FOLDS; i++) {
			Instances train = trainSet.trainCV(FOLDS, i);
			Instances crossVal = trainSet.testCV(FOLDS, i);
			filteredClassifier.setDebug(true);
			filteredClassifier.buildClassifier(train);
			for (Enumeration<Instance> e = crossVal.enumerateInstances(); e
					.hasMoreElements();) {
				Instance inst = e.nextElement();
				if (inst.classValue() == 1) {
					c += filteredClassifier.distributionForInstance(inst)[1];
					n += 1;
				}
			}
		}
		c /= n;

		// train the classifier on the full set of examples
		filteredClassifier.buildClassifier(trainSet);
	}

	public void buildClassifier2(Instances trainSet) throws Exception {
		filteredClassifier.setDebug(true);
		double c1 = 0, c2 = 0;

		for (int i = 0; i < FOLDS; i++) {
			Instances train = trainSet.trainCV(FOLDS, i);
			Instances crossVal = trainSet.testCV(FOLDS, i);
			filteredClassifier.buildClassifier(train);
			for (Enumeration<Instance> e = crossVal.enumerateInstances(); e
					.hasMoreElements();) {
				Instance inst = e.nextElement();
				if (inst.classValue() == 1) {
					c1 += filteredClassifier.distributionForInstance(inst)[1];
				} else {
					c2 += filteredClassifier.distributionForInstance(inst)[1];
				}
			}
		}
		c = c1 / (c1 + c2);

		// train the classifier on the full set of examples
		filteredClassifier.buildClassifier(trainSet);
	}

	public void buildClassifier3(Instances trainSet) throws Exception {
		filteredClassifier.setDebug(true);
		for (int i = 0; i < FOLDS; i++) {
			Instances train = trainSet.trainCV(FOLDS, i);
			Instances test = trainSet.testCV(FOLDS, i);
			filteredClassifier.buildClassifier(train);
			for (Enumeration<Instance> e = test.enumerateInstances(); e
					.hasMoreElements();) {
				Instance inst = e.nextElement();
				double val = filteredClassifier.distributionForInstance(inst)[1];
				if (inst.classValue() != 1 && c < val)
					c = val;
			}
		}
	}

	public static PositiveAndUnlabeledClassifier deserializeFromFile(File f)
			throws IOException, ClassNotFoundException {
		return (PositiveAndUnlabeledClassifier) FileManipulation
				.readObjectFromFile(f);
	}

	public String toString() {
		return baseClassifier.getClass() + "\t" + methodForEvaluatingC + "\t"
				+ PrettyPrint.toPrettyLine(allowedFeatures, ",");
	}

}
