package edu.harvard.seas.iis.abilities.classify;

import java.io.File;

import weka.classifiers.Classifier;
import weka.classifiers.functions.Logistic;
import weka.core.Instance;
import weka.filters.unsupervised.attribute.Add;
import edu.harvard.seas.iis.util.collections.PrettyPrint;

/**
 * @author kgajos
 * 
 *         Space for trying out random things
 */
public class Playground {

	public static void understandingClassifierOutput(File arffDataFile)
			throws Exception {
		DataSet dataSet = UserDataSet.fromArffFile(arffDataFile);
		dataSet.setClass(dataSet.attribute("Class"));
		System.out.println("Class attribute: " + dataSet.classAttribute());
		Classifier classifier = new Logistic();
		classifier.buildClassifier(dataSet);
		for (int i = 0; i < 20; i++) {
			int n = (int) (Math.random() * (double) dataSet.numInstances());
			Instance curInstance = dataSet.instance(n);
			double classification = classifier.classifyInstance(curInstance);
			double[] distr = classifier.distributionForInstance(curInstance);
			System.out
					.println("Classification: " + classification
							+ " Distribution: "
							+ PrettyPrint.toPrettyLine(distr, ", "));

		}
	}

	public static void checkFittsLawEvaluator() {
		System.out.println("Equal: "
				+ ClassifierEvaluator.compareFittsLawModels(new double[] { 10,
						1 }, new double[] { 10, 1 }));
		System.out.println("Unequal intercept: "
				+ ClassifierEvaluator.compareFittsLawModels(new double[] { 10,
						1 }, new double[] { 20, 1 }));
		System.out.println("Unequal slope: "
				+ ClassifierEvaluator.compareFittsLawModels(new double[] { 10,
						1 }, new double[] { 10, 2 }));
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		System.out.println(PrettyPrint.toPrettyLine(Add.TAGS_TYPE, ", "));
		System.exit(0);
		checkFittsLawEvaluator();
		understandingClassifierOutput(new File(
				"/Users/kgajos/Documents/projects/abilities/normalized data/allUsersWithGoodImplicitAndExplicitData-bad features removed.arff"));

		// example code snippets for initializing different classifiers
		Classifier classifier;
		classifier = Classifier
				.forName(
						"weka.classifiers.functions.SMO",
						new String[] { "-C", "1.0", "-L", "0.0010", "-P",
								"1.0E-12", "-N", "0", "-V", "-1", "-W", "1",
								"-K",
								"weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 1.0" });

		classifier = Classifier.forName("weka.classifiers.functions.Logistic",
				new String[] { "-R", "1.0E-8", "-M", "-1" });

	}

}
