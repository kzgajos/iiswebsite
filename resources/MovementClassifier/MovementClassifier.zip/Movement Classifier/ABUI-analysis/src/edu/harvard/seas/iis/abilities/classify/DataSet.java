package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.CSVSaver;

public class DataSet extends Instances {

	public DataSet(String name, FastVector baseAttrNames, int suspectedCapacity) {
		super(name, baseAttrNames, suspectedCapacity);
		setClass(attribute("Class"));
	}

	public DataSet(Instances insts) {
		super(insts);
		setClass(attribute("Class"));
	}

	public void addInstances(Instances insts) {
		if (insts == null)
			return;
		for (int i = 0; i < insts.numInstances(); i++) {
			add(insts.instance(i));
			// add does not copy string or relational attributes so will need to
			// do it by hand
			for (int a = 0; a < numAttributes(); a++) {
				if (attribute(a).isString())
					lastInstance()
							.setValue(a, insts.instance(i).stringValue(a));
			}
		}
	}

	public DataSet getInstancesWithAttributeValueEqual(Attribute att,
			String attVal) {
		DataSet res = new DataSet(this);
		for (int i = res.numInstances() - 1; i >= 0; i--)
			if (!attVal.equals(res.instance(i).stringValue(att)))
				res.delete(i);
		return res;
	}

	public DataSet getInstancesWithAttributeValueNotEqual(Attribute att,
			String attVal) {
		DataSet res = new DataSet(this);
		for (int i = res.numInstances() - 1; i >= 0; i--)
			if (attVal.equals(res.instance(i).stringValue(att)))
				res.delete(i);
		return res;
	}

	public DataSet getInstancesWithAttributeValues(Attribute att,
			Collection<String> values) {
		DataSet res = new DataSet(this);
		for (int i = res.numInstances() - 1; i >= 0; i--)
			if (!values.contains(res.instance(i).stringValue(att)))
				res.delete(i);
		return res;
	}

	public DataSet getInstancesWithAttributeValueGreaterThan(Attribute att,
			double attVal) {
		DataSet res = new DataSet(this);
		for (int i = res.numInstances() - 1; i >= 0; i--)
			if (attVal >= res.instance(i).value(att))
				res.delete(i);
		return res;
	}

	/**
	 * Convenience method which returns a subset of the data containing only
	 * explicit examples
	 * 
	 * @return
	 */
	public DataSet getExplicitInstances() {
		return getInstancesWithAttributeValueEqual(attribute("Class"),
				"explicit");
	}

	/**
	 * Convenience method which returns a subset of the data containing only
	 * implicit examples
	 * 
	 * @return
	 */
	public DataSet getImplicitInstances() {
		return getInstancesWithAttributeValueEqual(attribute("Class"),
				"implicit");
	}

	public DataSet getInstancesForUser(String user) {
		return getInstancesWithAttributeValueEqual(attribute("User"), user);
	}

	public int getNumImplicitInstances() {
		return attributeStats(attribute("Class").index()).nominalCounts[attribute(
				"Class").indexOfValue("implicit")];
	}

	public int getNumExplicitInstances() {
		return attributeStats(attribute("Class").index()).nominalCounts[attribute(
				"Class").indexOfValue("explicit")];
	}

	public Vector<String> getValuesOfStringOrNominalAttribute(Attribute attr) {
		Enumeration vals = attr.enumerateValues();
		Vector<String> res = new Vector<String>();
		while (vals.hasMoreElements())
			res.add(vals.nextElement().toString());
		return res;
	}

	/**
	 * Sets the value of an attribute to a particular value for all instances
	 * that match the condition
	 * 
	 * @param attr
	 * @param value
	 * @param condition
	 *            if null, then all instances are set to the given value
	 */
	public void setValue(Attribute attr, String value, InstanceFilter condition) {
		for (int i = 0; i < numInstances(); i++) {
			if (condition == null
					|| condition.evaluateInstance(instance(i), this))
				instance(i).setValue(attr, value);
		}
	}

	public double[] attributeToDoubleArray(String name) {
		Attribute att = attribute(name);
		return attributeToDoubleArray(att.index());
	}

	public void saveAsBothARFFandCSV(String outFile) throws IOException {
		saveAsARFF(outFile + ".arff");
		saveAsCSV(outFile + ".csv");
	}

	/**
	 * 
	 * 
	 * @param outfile
	 * @throws IOException
	 */
	public void saveAsARFF(String outfile) throws IOException {
		PrintWriter pw = new PrintWriter(outfile);
		pw.write(this.toString());
		pw.close();
	}

	/**
	 * Saves the data set in the CSV format
	 * 
	 * @param outfile
	 * @throws IOException
	 */
	public void saveAsCSV(String outfile) throws IOException {
		CSVSaver saver = new CSVSaver();
		saver.setInstances(this);
		saver.setFile(new File(outfile));
		saver.writeBatch();
	}

	/**
	 * A convenience method that creates an instance of a UserDataSet from an
	 * ARFF file
	 * 
	 * @param f
	 * @return
	 * @throws IOException
	 */
	public static DataSet fromArffFile(File f) throws IOException {
		ArffLoader al = new ArffLoader();
		al.setSource(f);
		return new DataSet(al.getDataSet());
	}

	/**
	 * Creates a single UserDataSet object from multiple ARFF files
	 * 
	 * @param files
	 * @return
	 * @throws IOException
	 */
	public static DataSet fromArffFiles(File[] files) throws IOException {
		if (files.length == 0)
			return null;
		DataSet res = fromArffFile(files[0]);

		for (int i = 1; i < files.length; i++) {
			res.addInstances(fromArffFile(files[i]));
		}
		Instance trouble = null;
		for (int i = 0; i < res.numInstances(); i++) {
			try {
				trouble = res.instance(i);
				trouble.toString();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}
		return res;
	}

}
