package edu.harvard.seas.iis.abilities.classify;

import java.io.File;

import edu.harvard.seas.iis.util.collections.ArrayUtils;

/**
 * @author kgajos
 * 
 */
public class Settings {

	// minimum value of Fitts' ID allowed
	public static double MINIMUM_ID_ALLOWED = 1;

	// the location of the directory containing all data
	public static String DATA_DIRECTORY = "/Users/kgajos/Documents/projects/abilities/dataDir/";
	// the directory containing raw logs from natural observations
	public static String NATURAL_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "raw data - natural";
	// the directory containing raw logs from the formal experiments
	public static String EXPLICIT_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "raw data - explicit";
	// locations of additional data
	public static String OTHER_STUDIES_RELIABLE_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "raw data - ephemeral - reliable";
	public static String OTHER_STUDIES_UNRELIABLE_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "raw data - adaptive menus - unreliable";
	// the directory for storing intermediate results (parsed raw data) --- data
	// will be put there during the process of training the classifier
	public static String PARSED_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "parsed data";
	// the directory for storing intermediate results --- parsed data with
	// outliers removed
	public static String CLEAN_DATA_DIRECTORY = DATA_DIRECTORY + File.separator
			+ "clean data";
	public static String COMBINED_CLEAN_DATA_FILE = CLEAN_DATA_DIRECTORY
			+ File.separator + "allUsersWithGoodImplicitAndExplicitData";
	// another directory for intermediate results --- this time for files where
	// additional features have been computed
	public static String TRANSFORMED_DATA_DIRECTORY = DATA_DIRECTORY
			+ "transformed data";
	public static String COMBINED_TRANSFORMED_DATA_FILE = TRANSFORMED_DATA_DIRECTORY
			+ File.separator + "allUsersWithGoodImplicitAndExplicitData";
	// now the directory for storing normalized data
	public static String NORMALIZED_DATA_DIRECTORY = DATA_DIRECTORY
			+ "normalized data";
	public static String INDIVIDUALLY_NORMALIZED_COMBINED_DATA_FILE = NORMALIZED_DATA_DIRECTORY
			+ File.separator
			+ "allUsersWithGoodImplicitAndExplicitData-individuallyNormalized";
	public static String GLOBALLY_NORMALIZED_COMBINED_DATA_FILE = NORMALIZED_DATA_DIRECTORY
			+ File.separator
			+ "allUsersWithGoodImplicitAndExplicitData-globallyNormalized";
	// file that contains both individually and globally normalized features
	public static String MIXED_NORMALIZED_COMBINED_DATA_FILE = NORMALIZED_DATA_DIRECTORY
			+ File.separator + "allUsersWithGoodImplicitAndExplicitData-mixed";

	// directory where we store data together with classification labels
	// produced by our classifiers
	public static String CLASSIFIED_DATA_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "classified data";

	// directory for storing temporary files
	public static String TEMPORARY_FILE_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "temporary files" + File.separator;

	// this is where trained classifiers are serialized to at the end of the
	// training process; but the MovementClassifier typically reads serialized
	// classifiers from a different location
	public static String TRAINED_CLASSIFIER_DIRECTORY = DATA_DIRECTORY
			+ File.separator + "classifiers";

	// user (participant) names
	public static String[] ALL_USER_NAMES = { "Sundaymorning", "Jay", "Jenny",
			"Joey", "anaconda", "anaconda-clean-pen", "ankole", "anteater",
			"antelope-touchpad", "bear", "beet", "boa", "buffalo", "bullfrog",
			"butterfly", "cabbage", "camel", "cat", "cattle", "chimpanzee",
			"cockatoo", "crane", "crocodile", "dog", "dolphin", "eagle",
			"egret", "elephant", "flamingo", "fred", "gecko", "gibbon",
			"giraffe", "goat", "gorilla", "gull", "hansefuchs", "hedgehog",
			"hippopotamus", "hyena", "iguana", "jaguar", "kaddy", "kangaroo",
			"koala", "ktest", "kudu", "lark", "lemur", "leopard", "llama",
			"locust", "loris", "lyrebird", "manatee", "meerkat", "mushroom",
			"none", "pea", "pepper", "pumpkin", "radish", "spinach", "squash",
			"strawberry", "test", "eph-lab1", "eph-lab2", "eph-lab3",
			"eph-lab4", "eph-lab5", "126f134ee9185ba", "49e5134ee98b3a7",
			"78f5134ee91f1bf", "9a78134f178223c", "e5a5134ee910fb2",
			"32d4134ee91cc4e", "4ac1134eeaeacf1", "7c4e134ee91aa54",
			"a1dd134ee91f745", "ebb0134ee92fe04", "35da134eeadf0be",
			"5d1b134ee910bb6", "7e2c134eeae60b8", "ace7134eeb3ec80",
			"f5f4134ee93542e", "3a7f134ef36f93b", "63d9134ee939a81",
			"8690134ee9295be", "b5b8134ee91c8c1", "3e97134ee910641",
			"72a3134ee93307a", "8b8d134ee903084", "c634134ee90d18c",
			"a78dc705", "46ddca5d", "46ddc7a7", "2dfdc463", "880dbfce",
			"f39dc204", "fd6dbf77", "e44dbc84" };

	// users with at least 75 natural movements captured
	public static String[] USERS_WITH_SUFFICIENT_IMPLICIT_DATA = new String[] {
			"elephant", "lemur", "gecko", "pumpkin", "cat", "kangaroo",
			"strawberry", "Sundaymorning", "hippopotamus", "koala", "hedgehog",
			"gibbon", "Jenny", "eagle", "lyrebird", "goat", "leopard",
			"jaguar", "gorilla", "crocodile", "cattle", "beet", "Joey",
			"dolphin", "iguana", "flamingo", "squash", "loris", "Jay" };

	// users with at least 75 experimental movements captured
	public static String[] USERS_WITH_SUFFICIENT_EXPLICIT_DATA = new String[] {
			"pumpkin", "camel", "anaconda", "anaconda-clean-pen", "squash",
			"eagle", "crane", "gibbon", "cockatoo", "Jenny", "iguana", "Joey",
			"antelope-touchpad", "cat", "cattle", "gecko", "none", "crocodile",
			"manatee", "dolphin", "jaguar", "locust", "leopard", "Jay", "gull",
			"dog", "lemur", "kangaroo", "goat", "koala", "bear", "giraffe",
			"eph-lab1", "eph-lab2", "eph-lab3", "eph-lab4", "eph-lab5" };

	// users whose performance we are really unsure of (in our case, they are
	// Turkers performing Ephemeral Menus experiment)
	public static String[] UNRELIABLE_USERS = new String[] { "126f134ee9185ba",
			"49e5134ee98b3a7", "78f5134ee91f1bf", "9a78134f178223c",
			"e5a5134ee910fb2", "32d4134ee91cc4e", "4ac1134eeaeacf1",
			"7c4e134ee91aa54", "a1dd134ee91f745", "ebb0134ee92fe04",
			"35da134eeadf0be", "5d1b134ee910bb6", "7e2c134eeae60b8",
			"ace7134eeb3ec80", "f5f4134ee93542e", "3a7f134ef36f93b",
			"63d9134ee939a81", "8690134ee9295be", "b5b8134ee91c8c1",
			"3e97134ee910641", "72a3134ee93307a", "8b8d134ee903084",
			"c634134ee90d18c", "a78dc705", "46ddca5d", "46ddc7a7", "2dfdc463",
			"880dbfce", "f39dc204", "fd6dbf77", "e44dbc84" };

	public static String[] USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA = ArrayUtils
			.intersection(USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
					USERS_WITH_SUFFICIENT_EXPLICIT_DATA);

	public static String[] USERS_WITH_SOME_USEFUL_DATA = ArrayUtils.union(
			ArrayUtils.union(USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
					USERS_WITH_SUFFICIENT_EXPLICIT_DATA), UNRELIABLE_USERS);

	public static String[] USERS_TO_INCLUDE_IN_EVALUATION = new String[] {
			"cat", "pumpkin", "squash", "eagle", "gibbon", "Jenny", "iguana",
			"Joey", "cattle", "gecko", "crocodile", "dolphin", "jaguar",
			"leopard", "lemur", "kangaroo", "goat", "koala" };

	public static String[] FEATURES_TO_NORMALIZE = new String[] { "LDI",
			"Task axis crossings", "Movement direction changes",
			"Orthogonal direction changes", "Movement error",
			"Movement offset", "Movement variability",
			"Submovements (.4px/ms)", "Submovements (.5px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-numPeaks", "S-num0cross", "S-T1stPeak", "S-NormT1stPeak",
			"S-TLastPeak", "S-NormTLastPeak", "S-TMaxPeak", "S-NormTMaxPeak",
			"S-MaxVal", "S-MinVal", "A-numPeaks", "A-num0cross", "A-T1stPeak",
			"A-NormT1stPeak", "A-TLastPeak", "A-NormTLastPeak", "A-TMaxPeak",
			"A-NormTMaxPeak", "A-MaxVal", "A-MinVal", "J-numPeaks",
			"J-num0cross", "J-T1stPeak", "J-NormT1stPeak", "J-TLastPeak",
			"J-NormTLastPeak", "J-TMaxPeak", "J-NormTMaxPeak", "J-MaxVal",
			"J-MinVal", "fIntegralSquareJerk", "fAverageAbsoluteJerk",
			"Movement Time divided by ID", "Movement Time divided by A",
			"S-TLastPeak divided by ID", "A-TLastPeak divided by ID",
			"J-TLastPeak divided by ID", "S-MaxVal divided by A",
			"A-MaxVal divided by A", "A-MinVal divided by A",
			"J-MaxVal divided by A", "J-MinVal divided by A",
			"fAverageAbsoluteJerk divided by A",
			"Movement Time divided by log A", "S-MaxVal divided by log A",
			"A-MaxVal divided by log A", "A-MinVal divided by log A",
			"J-MaxVal divided by log A", "J-MinVal divided by log A",
			"fAverageAbsoluteJerk divided by log A" };

	public static String[] ALLOWED_FEATURES = new String[] { "Class", "LDI",
			"Task axis crossings", "Movement direction changes",
			"Orthogonal direction changes", "Movement variability",
			"Submovements (.4px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-numPeaks", "S-num0cross", "S-NormT1stPeak", "S-TMaxPeak",
			"A-numPeaks", "A-num0cross", "A-TMaxPeak", "J-numPeaks",
			"J-num0cross", "J-NormTLastPeak", "J-TMaxPeak",
			"Movement Time divided by ID", "S-TLastPeak divided by ID",
			"A-TLastPeak divided by ID", "J-TLastPeak divided by ID",
			"Movement error", "S-NormTLastPeak", "A-NormT1stPeak",
			"A-NormTLastPeak", "A-NormTMaxPeak", "J-NormTMaxPeak",
			"S-TLastPeak", "A-TLastPeak", "J-TLastPeak",
			"Movement Time divided by log A", "Movement Time divided by A" };

	public static String[] ALLOWED_FEATURES_MIXED = new String[] { "Class",
			"LDI", "Task axis crossings", "Movement direction changes",
			"Orthogonal direction changes", "Movement variability",
			"Submovements (.4px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-numPeaks", "S-num0cross", "S-NormT1stPeak", "S-TMaxPeak",
			"A-numPeaks", "A-num0cross", "A-TMaxPeak", "J-numPeaks",
			"J-num0cross", "J-NormTLastPeak", "J-TMaxPeak",
			"Movement Time divided by ID", "S-TLastPeak divided by ID",
			"A-TLastPeak divided by ID", "J-TLastPeak divided by ID",
			"Movement error", "S-NormTLastPeak", "A-NormT1stPeak",
			"A-NormTLastPeak", "A-NormTMaxPeak", "J-NormTMaxPeak",
			"S-TLastPeak", "A-TLastPeak", "J-TLastPeak",
			"Movement Time divided by log A", "Movement Time divided by A",
			"LDI-individual", "Task axis crossings-individual",
			"Movement direction changes-individual",
			"Orthogonal direction changes-individual",
			"Movement variability-individual",
			"Submovements (.4px/ms)-individual", "S-numPeaks-individual",
			"S-num0cross-individual", "S-NormT1stPeak-individual",
			"S-TMaxPeak-individual", "A-numPeaks-individual",
			"A-num0cross-individual", "A-TMaxPeak-individual",
			"J-numPeaks-individual", "J-num0cross-individual",
			"J-NormTLastPeak-individual", "J-TMaxPeak-individual",
			"Movement Time divided by ID-individual",
			"S-TLastPeak divided by ID-individual",
			"A-TLastPeak divided by ID-individual",
			"J-TLastPeak divided by ID-individual",
			"Movement error-individual", "S-NormTLastPeak-individual",
			"A-NormT1stPeak-individual", "A-NormTLastPeak-individual",
			"A-NormTMaxPeak-individual", "J-NormTMaxPeak-individual",
			"S-TLastPeak-individual", "A-TLastPeak-individual",
			"J-TLastPeak-individual",
			"Movement Time divided by log A-individual",
			"Movement Time divided by A-individual" };

	public static String[] TARGET_AGNOSTIC_FEATURES = new String[] { "Class",
			"LDI", "Task axis crossings", "Movement direction changes",
			"Orthogonal direction changes", "Movement variability",
			"Submovements (.4px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-numPeaks", "S-num0cross", "S-NormT1stPeak", "S-TMaxPeak",
			"A-numPeaks", "A-num0cross", "A-TMaxPeak", "J-numPeaks",
			"J-num0cross", "J-NormTLastPeak", "J-TMaxPeak", "Movement error",
			"S-NormTLastPeak", "A-NormT1stPeak", "A-NormTLastPeak",
			"A-NormTMaxPeak", "J-NormTMaxPeak", "S-TLastPeak", "A-TLastPeak",
			"J-TLastPeak", "Movement Time", "Movement Time divided by A",
			"Movement Time divided by log A" };

	public static String[] TARGET_AGNOSTIC_FEATURES_MIXED = new String[] {
			"Class", "LDI", "Task axis crossings",
			"Movement direction changes", "Orthogonal direction changes",
			"Movement variability", "Submovements (.4px/ms)",
			"Fraction of distance to target covered in the first submovement",
			"S-numPeaks", "S-num0cross", "S-NormT1stPeak", "S-TMaxPeak",
			"A-numPeaks", "A-num0cross", "A-TMaxPeak", "J-numPeaks",
			"J-num0cross", "J-NormTLastPeak", "J-TMaxPeak", "Movement error",
			"S-NormTLastPeak", "A-NormT1stPeak", "A-NormTLastPeak",
			"A-NormTMaxPeak", "J-NormTMaxPeak", "S-TLastPeak", "A-TLastPeak",
			"J-TLastPeak", "Movement Time divided by A",
			"Movement Time divided by log A", "LDI-individual",
			"Task axis crossings-individual",
			"Movement direction changes-individual",
			"Orthogonal direction changes-individual",
			"Movement variability-individual",
			"Submovements (.4px/ms)-individual", "S-numPeaks-individual",
			"S-num0cross-individual", "S-NormT1stPeak-individual",
			"S-TMaxPeak-individual", "A-numPeaks-individual",
			"A-num0cross-individual", "A-TMaxPeak-individual",
			"J-numPeaks-individual", "J-num0cross-individual",
			"J-NormTLastPeak-individual", "J-TMaxPeak-individual",
			"Movement error-individual", "S-NormTLastPeak-individual",
			"A-NormT1stPeak-individual", "A-NormTLastPeak-individual",
			"A-NormTMaxPeak-individual", "J-NormTMaxPeak-individual",
			"S-TLastPeak-individual", "A-TLastPeak-individual",
			"J-TLastPeak-individual", "Movement Time divided by A-individual",
			"Movement Time divided by log A-individual" };

	/*** BEST FEATURES ***/

	public static String[] BEST_FEATURES_LOGISTIC_GLOBAL_OLD = new String[] {
			"A-NormT1stPeak", "Class", "J-NormTMaxPeak",
			"Movement Time divided by ID", "Movement Time divided by log A",
			"Movement error", "Movement variability", "S-NormT1stPeak",
			"S-TMaxPeak" };

	public static String[] BEST_FEATURES_LOGISTIC_GLOBAL_1 = new String[] {
			"A-NormT1stPeak", "Class",
			"Fraction of distance to target covered in the first submovement",
			"Movement Time divided by ID", "Movement error",
			"Movement variability" };

	public static String[] BEST_FEATURES_LOGISTIC_GLOBAL = new String[] {
			"A-NormT1stPeak", "Class", "J-NormTMaxPeak",
			"Movement Time divided by ID", "Movement error",
			"Movement variability", "Submovements (.4px/ms)" };

	public static String[] BEST_FEATURES_LOGISTIC_MIXED = new String[] {
			"A-NormT1stPeak", "Class",
			"Movement Time divided by ID-individual",
			"Movement Time divided by log A-individual", "Movement error",
			"Movement variability", "Submovements (.4px/ms)",
			"Submovements (.4px/ms)-individual" };

	public static String[] BEST_FEATURES_LOGISTIC_GLOBAL_TARGET_AGNOSTIC = new String[] {
			"A-NormT1stPeak", "A-NormTMaxPeak", "Class", "J-NormTMaxPeak",
			"Movement Time divided by A", "Movement error", "S-NormT1stPeak" };

	public static String[] BEST_FEATURES_LOGISTIC_MIXED_TARGET_AGNOSTIC = new String[] {
			"A-NormT1stPeak", "A-TMaxPeak", "Class", "J-TMaxPeak",
			"Movement Time divided by A-individual",
			"Movement Time divided by log A-individual", "Movement error",
			"Movement variability", "S-NormT1stPeak",
			"Submovements (.4px/ms)-individual" };
}
