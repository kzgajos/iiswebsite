package edu.harvard.seas.iis.abilities.classify.webservice;

import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.Vector;

import edu.harvard.seas.iis.abilities.analysis.IISMouseLogParser;
import edu.harvard.seas.iis.abilities.analysis.Movement;
import edu.harvard.seas.iis.abilities.analysis.Parser;
import edu.harvard.seas.iis.abilities.classify.MovementClassifier;
import edu.harvard.seas.iis.util.Logger;

public class MovementClassifierWebService extends NanoHTTPD {

	protected MovementClassifier movementClassifier = new MovementClassifier();
	protected Parser logParser = new IISMouseLogParser();

	public MovementClassifierWebService(int port, File wwwroot)
			throws IOException {
		super(port, wwwroot);
	}

	public Response serve(String uri, String method, Properties header,
			Properties parms, Properties files) {
		System.out.println(method + " '" + uri + "' ");
		String msg = "";
		if (parms.getProperty("log") == null) {
			msg += "<html><body><h1>Punch in some test data</h1>";
			msg += "<form action='' method='post'>";
			msg += "Filter (e.g.'btn-next' would cause classification to be performed only on movements where target type = btn-next): <input name='filter' type='text'>";
			msg += "<br/>Log: <textarea name='log' width='80' height='20'></textarea>";
			msg += "<br/><input type='submit'>";
			msg += "</form></body></html>\n";
			return new NanoHTTPD.Response(HTTP_OK, MIME_HTML, msg);
		} else {
			Logger.log("received logs to parse");
			try {
				Vector<Movement> movements = logParser.parseMovementLog(parms
						.getProperty("log"));
				String targetTypeFilter = parms.getProperty("filter");
				double numMovements = 0, numDeliberate = 0, numDistracted = 0;
				for (int i = 0; i < movements.size(); i++) {
					if (targetTypeFilter == null
							|| targetTypeFilter.equals("")
							|| targetTypeFilter.toLowerCase().equals(
									movements.elementAt(i).getTargetType()
											.toLowerCase())) {
						double p = movementClassifier.getDeliberateProbability(
								movements.elementAt(i), true);
						if (p >= .5)
							numDeliberate++;
						else
							numDistracted++;
						numMovements++;
					}
				}
				if (numMovements > 0)
					msg += "" + (numDeliberate / numMovements);
				else
					msg += "0";
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return new NanoHTTPD.Response(HTTP_OK, MIME_PLAINTEXT, msg);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			new MovementClassifierWebService(8080, null);
		} catch (IOException ioe) {
			System.err.println("Couldn't start server:\n" + ioe);
			System.exit(-1);
		}
		System.out.println("Listening on port 8080. Hit Enter to stop.\n");
		try {
			System.in.read();
		} catch (Throwable t) {
		}
		;
	}

}
