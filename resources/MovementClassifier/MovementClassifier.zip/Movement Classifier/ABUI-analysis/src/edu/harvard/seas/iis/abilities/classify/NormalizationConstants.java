package edu.harvard.seas.iis.abilities.classify;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Storage for normalization constants
 * 
 * @author kgajos
 * 
 */
public class NormalizationConstants implements Serializable {

	private static final long serialVersionUID = 1L;
	protected Hashtable<String, Double> means = new Hashtable<String, Double>();
	protected Hashtable<String, Double> variances = new Hashtable<String, Double>();

	public void setConstantsForAttribute(String attr, double mean,
			double variance) {
		means.put(attr, mean);
		variances.put(attr, variance);
	}

	public Double getMean(String attribute) {
		return means.get(attribute);
	}

	public Double getVariance(String attribute) {
		return variances.get(attribute);
	}

	/**
	 * Returns attributes for which there are normalization constants stored
	 * 
	 * @return
	 */
	public Vector<String> getAttributes() {
		return new Vector<String>(means.keySet());
	}
}
