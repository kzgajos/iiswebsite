package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.util.Vector;

import org.apache.commons.math.MathException;
import org.apache.commons.math.stat.inference.TTestImpl;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import edu.harvard.seas.iis.util.collections.ArrayUtils;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;
import edu.harvard.seas.iis.util.stats.BasicStats;
import edu.harvard.seas.iis.util.stats.LinearRegressionCalculator;

public class ClassifierEvaluator {

	protected Classifier baseClassifier;
	protected DataSet annotatedDataSet;

	/**
	 * @param dataSet
	 * @return [intercept, slope]
	 */
	public static double[] computeFittsLawCoefficients(DataSet dataSet) {
		double[] mt = dataSet.attributeToDoubleArray("Movement Time");
		double[] id = dataSet.attributeToDoubleArray("ID");
		return LinearRegressionCalculator.computeLinearRegressionParameters(id,
				mt);
	}

	/**
	 * @param baseline
	 *            params of the baseline model [intercept, slope]
	 * @param comparison
	 *            params of the comparison model [intercept, slope]
	 * @return mean fraction by which prediction of comparison differ from
	 *         baseline
	 */
	public static double[] compareFittsLawModels(double[] baseline,
			double[] comparison) {
		double meanDifference = 0, meanAbsoluteDifference = 0;
		double cnt = 0;
		for (double id = 1.5; id <= 7; id += .2) {
			double baselinePrediction = baseline[0] + id * baseline[1];
			double comparisonPrediction = comparison[0] + id * comparison[1];
			meanDifference += (comparisonPrediction - baselinePrediction)
					/ baselinePrediction;
			meanAbsoluteDifference += Math
					.abs((comparisonPrediction - baselinePrediction)
							/ baselinePrediction);
			cnt++;
		}
		return new double[] { meanDifference / (double) cnt,
				meanAbsoluteDifference / (double) cnt };
	}

	/**
	 * Returns a copy of the data set that only contains instances positively
	 * classified by c
	 * 
	 * @param c
	 * @param d
	 * @return
	 * @throws Exception
	 */
	public DataSet getDeliberateInstances(Classifier c, DataSet d)
			throws Exception {
		DataSet ret = new DataSet(d);
		for (int i = d.numInstances() - 1; i >= 0; i--) {
			if (c.classifyInstance(d.instance(i)) < .05)
				ret.delete(i);
		}
		return ret;
	}

	/**
	 * Evaluate a trained classifier c on a particular test data set
	 * 
	 * @param c
	 * @param testData
	 * @return
	 * @throws Exception
	 */
	public double[] evaluate(Classifier c, DataSet testData) throws Exception {
		double[] res = new double[23];
		// compute fitts law coefficients for the explicit data points in the
		// test data
		DataSet explicit = testData.getExplicitInstances();
		double[] explicitFitts = computeFittsLawCoefficients(explicit);

		// compute fitts law coefficients for the positively classified implicit
		// data in the test data
		DataSet implicit = testData.getImplicitInstances();
		System.out.println("Implicit instances: " + implicit.numInstances());
		DataSet motivated = getDeliberateInstances(c, implicit);
		System.out.println("Motivated instances: " + motivated.numInstances());
		double[] implicitFitts = computeFittsLawCoefficients(implicit);
		double[] motivatedFitts = computeFittsLawCoefficients(motivated);

		double explicitIndexOfPerformance = 1000.0 / explicitFitts[1];
		double implicitIndexOfPerformance = 1000.0 / implicitFitts[1];
		double motivatedIndexOfPerformance = 1000.0 / motivatedFitts[1];

		Attribute attrMTbyID = explicit
				.attribute("Movement Time divided by ID-original");
		double explicitMTbyID = explicit.meanOrMode(attrMTbyID);
		double implicitMTbyID = implicit.meanOrMode(attrMTbyID);
		double motivatedMTbyID = motivated.meanOrMode(attrMTbyID);

		double implicitMTbyIDstdev = Math.sqrt(implicit.variance(attrMTbyID));
		double motivatedMTbyIDstdev = Math.sqrt(motivated.variance(attrMTbyID));
		double explicitMTbyIDstdev = Math.sqrt(explicit.variance(attrMTbyID));

		res[0] = explicitFitts[0];
		res[1] = explicitFitts[1];
		res[2] = implicitFitts[0];
		res[3] = implicitFitts[1];
		double[] implicitComparison = compareFittsLawModels(explicitFitts,
				implicitFitts);
		res[4] = implicitComparison[1];
		res[5] = motivatedFitts[0];
		res[6] = motivatedFitts[1];
		double[] motivatedComparison = compareFittsLawModels(explicitFitts,
				motivatedFitts);
		res[7] = motivatedComparison[1];
		res[8] = (double) motivated.numInstances()
				/ (double) implicit.numInstances();
		res[9] = (implicitIndexOfPerformance - explicitIndexOfPerformance)
				/ explicitIndexOfPerformance;
		res[10] = (motivatedIndexOfPerformance - explicitIndexOfPerformance)
				/ explicitIndexOfPerformance;
		res[11] = explicitIndexOfPerformance;
		res[12] = implicitIndexOfPerformance;
		res[13] = motivatedIndexOfPerformance;

		// calculating recall on the explicit data
		DataSet motivatedExplicit = getDeliberateInstances(c, explicit);
		res[14] = (double) motivatedExplicit.numInstances()
				/ (double) explicit.numInstances();

		res[15] = explicitMTbyID;
		res[16] = implicitMTbyID;
		res[17] = motivatedMTbyID;
		res[18] = (implicitMTbyID - explicitMTbyID) / explicitMTbyID;
		res[19] = (motivatedMTbyID - explicitMTbyID) / explicitMTbyID;

		res[20] = implicitMTbyIDstdev;
		res[21] = explicitMTbyIDstdev;
		res[22] = motivatedMTbyIDstdev;

		return res;
	}

	/**
	 * Fills in the "Prediction probability" and "Predicted class" values in the
	 * dataSet using classifier c. If filter is not null, then annotation is
	 * only done for instances that pass the filter (if filter is null, then all
	 * instances get annotated)
	 * 
	 * @param dataSet
	 * @param c
	 * @param filter
	 * @return
	 * @throws Exception
	 */
	public DataSet annotateDataSet(DataSet dataSet, Classifier c,
			InstanceFilter filter) throws Exception {
		Attribute probAttr = dataSet.attribute("Prediction probability");
		Attribute predictedClassAttr = dataSet.attribute("Predicted class");
		for (int i = 0; i < dataSet.numInstances(); i++) {
			if (filter == null
					|| filter.evaluateInstance(dataSet.instance(i), dataSet)) {
				double p = c.distributionForInstance(dataSet.instance(i))[1];
				dataSet.instance(i).setValue(probAttr, p);
				dataSet.instance(i).setValue(predictedClassAttr,
						(p >= .5) ? 1.0 : 0);
			}
		}
		return dataSet;
	}

	public String crossvalidateOverUsers(Classifier c, DataSet dataSet,
			String[] users, boolean generateAnnotatedDataSet) throws Exception {

		double implicitError = 0, motivatedError = 0, fractionOfMotivatedMovements = 0;
		double minImplicitError = Double.MAX_VALUE, maxImplicitError = Double.MIN_VALUE;
		double minMotivatedError = Double.MAX_VALUE, maxMotivatedError = Double.MIN_VALUE;
		double minFractionOfMotivatedMovements = Double.MAX_VALUE, maxFractionOfMotivatedMovements = Double.MIN_VALUE;
		double motivatedIPError = 0, motivatedAbsoluteIPError = 0, minMotivatedIPError = Double.MAX_VALUE, maxMotivatedIPError = Double.MIN_VALUE;
		double implicitIPError = 0;
		double recall = 0, minRecall = Double.MAX_VALUE, maxRecall = Double.MIN_VALUE;
		double meanAbsoluteMTbyIDerror = 0, maxAbsoluteMTbyIDerror = Double.MIN_VALUE;

		if (generateAnnotatedDataSet)
			annotatedDataSet = null;

		String report = "";

		for (int i = 0; i < users.length; i++) {
			Vector<String> trainingUsers = new Vector<String>();
			for (String u : users)
				trainingUsers.add(u);
			String testUser = trainingUsers.remove(i);
			DataSet trainingSet = dataSet.getInstancesWithAttributeValues(
					dataSet.attribute("User"), trainingUsers);
			DataSet testSet = dataSet.getInstancesForUser(testUser);

			c.buildClassifier(trainingSet);
			System.out.print(testUser + ": ");
			double[] res = evaluate(c, testSet);
			if (generateAnnotatedDataSet) {
				testSet = annotateDataSet(testSet, c, null);
				if (annotatedDataSet == null)
					annotatedDataSet = testSet;
				else
					annotatedDataSet.addInstances(testSet);
			}

			implicitError += res[4];
			if (res[4] < minImplicitError)
				minImplicitError = res[4];
			if (res[4] > maxImplicitError)
				maxImplicitError = res[4];
			motivatedError += res[7];
			if (res[7] < minMotivatedError)
				minMotivatedError = res[7];
			if (res[7] > maxMotivatedError)
				maxMotivatedError = res[7];
			fractionOfMotivatedMovements += res[8];
			if (res[8] < minFractionOfMotivatedMovements)
				minFractionOfMotivatedMovements = res[8];
			if (res[8] > maxFractionOfMotivatedMovements)
				maxFractionOfMotivatedMovements = res[8];
			implicitIPError += res[9];
			motivatedIPError += res[10];
			motivatedAbsoluteIPError += Math.abs(res[10]);
			if (res[10] < minMotivatedIPError)
				minMotivatedIPError = res[10];
			if (res[10] > maxMotivatedIPError)
				maxMotivatedIPError = res[10];
			recall += res[14];
			if (res[14] < minRecall)
				minRecall = res[14];
			if (res[14] > maxRecall)
				maxRecall = res[14];

			meanAbsoluteMTbyIDerror += Math.abs(res[19]);
			if (res[19] > maxAbsoluteMTbyIDerror)
				maxAbsoluteMTbyIDerror = res[19];

			report += "\n" + testUser + "\t"
					+ Transform.getParticipantCode(testUser) + "\t" + res[4]
					+ "\t" + res[7] + "\t" + res[8] + "\t" + res[9] + "\t"
					+ res[10] + "\t" + res[11] + "\t" + res[12] + "\t"
					+ res[13] + "\t" + res[14] + "\t" + res[15] + "\t"
					+ res[16] + "\t" + res[17] + "\t" + res[18] + "\t"
					+ res[19] + "\t";
		}

		implicitError /= users.length;
		motivatedError /= users.length;
		fractionOfMotivatedMovements /= users.length;
		motivatedIPError /= users.length;
		motivatedAbsoluteIPError /= users.length;
		recall /= users.length;
		meanAbsoluteMTbyIDerror /= users.length;

		double worstAbsoluteMotivatedError = Math.max(Math
				.abs(minMotivatedError), maxMotivatedError);

		double worstAbsoluteMotivatedIPError = Math.max(Math
				.abs(minMotivatedIPError), maxMotivatedIPError);

		return implicitError + "\t" + minImplicitError + "\t"
				+ maxImplicitError + "\t" + motivatedError + "\t"
				+ worstAbsoluteMotivatedError + "\t" + minMotivatedError + "\t"
				+ maxMotivatedError + "\t" + motivatedIPError + "\t"
				+ motivatedAbsoluteIPError + "\t"
				+ +worstAbsoluteMotivatedIPError + "\t" + minMotivatedIPError
				+ "\t" + maxMotivatedIPError + "\t"
				+ fractionOfMotivatedMovements + "\t"
				+ minFractionOfMotivatedMovements + "\t"
				+ maxFractionOfMotivatedMovements + "\t" + recall + "\t"
				+ minRecall + "\t" + maxRecall + "\t" + meanAbsoluteMTbyIDerror
				+ "\t" + maxAbsoluteMTbyIDerror + "\t" + report;
	}

	protected String headers = "Base Classifier\tmethod for calculating c\tfeatures\timplicit error\tmin implicit error\tmax implicit error\tmotivated error\tworst motivated error\tmin motivated error\tmax motivated error\tmotivated IP error\tmotivated absolute IP error\tworst motivated IP error\tmin motivated IP error\tmax motivated IP error\tfraction of motivated movements\tmin fraction of motivated movements\tmax fraction of motivated movements\trecall\tmin recall\tmax recall\nuser1\tParticipant\tuser 1 implicit error\tuser 1 motivated error\tfraction of motivated movements\timplicit IP error\tmotivated IP error\texplicit index of performance\timplicit index of performance\tmotivated index of performance\trecall\texplicit MT/ID\timplicit MT/ID\tmotivated MT/ID\timplicit MT/ID error\tmotivated MT/ID error";

	/**
	 * Creates a positive and unlabeled classifier based on the globally set
	 * baseClassifier; evaluates it using crossvalidation; only specified
	 * features are used for classification
	 * 
	 * @param features
	 * @param dataFile
	 *            file containing the data to use for training and validation in
	 *            the crossvalidation procedure
	 * @param generateAnnotatedDataSet
	 *            if set to true, this method will produce a copy of the data
	 *            set read from dataFile that has the classifier prediction
	 *            fields filled in for each instance; the annotated data set is
	 *            stored in the global variable annotatedDataSet
	 * @return
	 * @throws Exception
	 */
	public String evaluate(String[] features, File dataFile,
			boolean generateAnnotatedDataSet) throws Exception {
		DataSet train = UserDataSet.fromArffFile(dataFile);
		System.out.println("Training instances: " + train.numInstances());
		Classifier c;

		c = new PositiveAndUnlabeledClassifier(baseClassifier, features);

		String res = crossvalidateOverUsers(c, train,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
				generateAnnotatedDataSet);

		return c + "\t" + res;
	}

	/**
	 * A draft of a method for testing how the classifier's accuracy changes
	 * depending on the amount of training data available
	 * 
	 * @param users
	 * @param features
	 * @param cleanDataDirectory
	 * @throws Exception
	 */
	public void evaluateDataRequirements(String[] users, String[] features,
			File cleanDataDirectory) throws Exception {
		File trainFile = new File(
				Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE);
		DataSet dataSet = UserDataSet.fromArffFile(trainFile);

		Classifier c = new PositiveAndUnlabeledClassifier(
				Classifier
						.forName(
								"weka.classifiers.functions.SMO",
								new String[] { "-C", "1.0", "-L", "0.0010",
										"-P", "1.0E-12", "-N", "0", "-V", "-1",
										"-W", "1", "-K",
										"weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 1.0" }),
				features);

		double[][] errorRes = new double[users.length][20];
		double[][] IPerrorRes = new double[users.length][20];

		for (int i = 0; i < users.length; i++) {
			Vector<String> trainingUsers = new Vector<String>();
			for (String u : users)
				trainingUsers.add(u);
			String testUser = trainingUsers.remove(i);
			DataSet trainingSet = dataSet.getInstancesWithAttributeValues(
					dataSet.attribute("User"), trainingUsers);
			DataSet testSet = UserDataSet.fromArffFile(new File(
					cleanDataDirectory.getAbsolutePath() + File.separator
							+ testUser + ".arff"));
			DataSet explicitTestSet = testSet.getExplicitInstances();
			DataSet impDataSet = testSet.getImplicitInstances();

			c.buildClassifier(trainingSet);

			for (int n = 1; n <= 20; n++) {
				// get a subset of the data
				DataSet curSet = new DataSet(explicitTestSet);
				for (int k = 0; k < n * 10 && k < impDataSet.numInstances(); k++) {
					curSet.add(impDataSet.instance(k));
				}
				curSet = Transform.normalize(curSet,
						Settings.FEATURES_TO_NORMALIZE, null, null);
				double[] tempRes = evaluate(c, curSet);
				errorRes[i][n - 1] = tempRes[7];
				IPerrorRes[i][n - 1] = tempRes[10];
			}
		}

		System.out.println("Fitts' prediction error");
		for (int i = 0; i < users.length; i++) {
			System.out.println(users[i] + "\t"
					+ PrettyPrint.toPrettyLine(errorRes[i], "\t"));
		}
		System.out.println("Fitts' IP error");
		for (int i = 0; i < users.length; i++) {
			System.out.println(users[i] + "\t"
					+ PrettyPrint.toPrettyLine(IPerrorRes[i], "\t"));
		}
	}

	/**
	 * Runs pairwise statistical tests to look for statistically significant
	 * differences across users on several metrics.
	 * 
	 * @param baseLine
	 * @param testSet
	 * @param users
	 * @param attributeForTesting
	 * @param minNumberRequiredForTesting
	 * @return
	 * @throws IllegalArgumentException
	 * @throws MathException
	 */
	public double[] runStatisticalTests(DataSet baseLine, DataSet testSet,
			String[] users, String attributeForTesting,
			int minNumberRequiredForTesting) throws IllegalArgumentException,
			MathException {
		double[] res = new double[5];
		double[][] baseLineOutcomes = new double[users.length][users.length];
		double[][] testSetOutcomes = new double[users.length][users.length];
		TTestImpl ttest = new TTestImpl();
		int iterations = 100;
		String report = "user 1\tuser2\tbase line diff\ttest set diff\t";
		report += "base line sig .05\tbase line sig .01\ttest set sig .05\ttest set sig .01\t";
		report += "TP .05\tTN .05\tFP .05\tFN .05\twrong dir .05\t";
		report += "TP .01\tTN .01\tFP .01\tFN .01\twrong dir .01\tnum data points\n";
		double TP01rate = 0, TN01rate = 0, FP01rate = 0, FN01rate = 0, wrongDir01rate = 0;
		int testCount = 0;

		for (int u1 = 0; u1 < users.length; u1++) {
			String user1 = users[u1];
			double[] user1BaseLine = baseLine.getInstancesForUser(user1)
					.attributeToDoubleArray(attributeForTesting);
			double[] user1TestSet = testSet.getInstancesForUser(user1)
					.attributeToDoubleArray(attributeForTesting);

			// equalize the numbers
			if (user1BaseLine.length > user1TestSet.length)
				user1BaseLine = ArrayUtils.getRandomSubset(user1BaseLine,
						user1TestSet.length);
			else if (user1BaseLine.length < user1TestSet.length)
				user1TestSet = ArrayUtils.getRandomSubset(user1TestSet,
						user1BaseLine.length);

			for (int u2 = u1; u2 < users.length; u2++) {
				String user2 = users[u2];
				double baseLineDiff = 0, testSetDiff = 0, baseLineSig05 = 0, testSetSig05 = 0, baseLineSig01 = 0, testSetSig01 = 0;
				boolean testable = true;
				int numDataPointsU1 = 0, numDataPointsU2 = 0;

				for (int iter = 0; iter < iterations; iter++) {
					double[] user2BaseLine = baseLine
							.getInstancesForUser(user2).attributeToDoubleArray(
									attributeForTesting);
					double[] user2TestSet = testSet.getInstancesForUser(user2)
							.attributeToDoubleArray(attributeForTesting);

					// equalize the numbers
					if (user2BaseLine.length > user2TestSet.length)
						user2BaseLine = ArrayUtils.getRandomSubset(
								user2BaseLine, user2TestSet.length);
					else if (user2BaseLine.length < user2TestSet.length)
						user2TestSet = ArrayUtils.getRandomSubset(user2TestSet,
								user2BaseLine.length);
					testable = user2BaseLine.length >= minNumberRequiredForTesting
							&& user1BaseLine.length >= minNumberRequiredForTesting;
					numDataPointsU1 = user1BaseLine.length;
					numDataPointsU2 = user2BaseLine.length;

					// require certain minimum number of samples before even
					// attempting testing
					if (testable) {
						double tempRes = ttest.tTest(user1BaseLine,
								user2BaseLine);
						baseLineOutcomes[u1][u2] += tempRes;
						baseLineDiff += BasicStats.getMean(user1BaseLine)
								- BasicStats.getMean(user2BaseLine);
						baseLineSig05 += (tempRes < .05) ? 1 : 0;
						baseLineSig01 += (tempRes < .01) ? 1 : 0;

						tempRes = ttest.tTest(user1TestSet, user2TestSet);
						testSetOutcomes[u1][u2] += tempRes;
						testSetDiff += BasicStats.getMean(user1TestSet)
								- BasicStats.getMean(user2TestSet);
						testSetSig05 += (tempRes < .05) ? 1 : 0;
						testSetSig01 += (tempRes < .01) ? 1 : 0;
					} else {
						baseLineOutcomes[u1][u2] += -1;
						testSetOutcomes[u1][u2] += -1;
					}
				}
				baseLineDiff /= iterations;
				testSetDiff /= iterations;
				baseLineSig05 /= iterations;
				baseLineSig01 /= iterations;
				testSetSig05 /= iterations;
				testSetSig01 /= iterations;

				double TP05 = (Math.signum(baseLineDiff) == Math
						.signum(testSetDiff)
						&& baseLineSig05 >= .5 && testSetSig05 >= .5) ? 1 : 0;
				double TP01 = (Math.signum(baseLineDiff) == Math
						.signum(testSetDiff)
						&& baseLineSig01 >= .5 && testSetSig01 >= .5) ? 1 : 0;
				double TN05 = (baseLineSig05 < .5 && testSetSig05 < .5) ? 1 : 0;
				double TN01 = (baseLineSig01 < .5 && testSetSig01 < .5) ? 1 : 0;

				double FP05 = (baseLineSig05 < .5 && testSetSig05 >= .5) ? 1
						: 0;
				double FP01 = (baseLineSig01 < .5 && testSetSig01 >= .5) ? 1
						: 0;
				double FN05 = (baseLineSig05 >= .5 && testSetSig05 < .5) ? 1
						: 0;
				double FN01 = (baseLineSig01 >= .5 && testSetSig01 < .5) ? 1
						: 0;

				double wrongDir05 = (Math.signum(baseLineDiff) != Math
						.signum(testSetDiff)
						&& baseLineSig05 >= .5 && testSetSig05 >= .5) ? 1 : 0;
				double wrongDir01 = (Math.signum(baseLineDiff) != Math
						.signum(testSetDiff)
						&& baseLineSig01 >= .5 && testSetSig01 >= .5) ? 1 : 0;
				if (u1 != u2 && testable) {
					testCount++;
					TP01rate += TP01;
					FP01rate += FP01;
					TN01rate += TN01;
					FN01rate += FN01;
					wrongDir01rate += wrongDir01;

					report += user1 + "\t" + user2 + "\t" + baseLineDiff + "\t"
							+ testSetDiff + "\t";
					report += baseLineSig05 + "\t" + baseLineSig01 + "\t"
							+ testSetSig05 + "\t" + testSetSig01 + "\t";
					report += TP05 + "\t" + TN05 + "\t" + FP05 + "\t" + FN05
							+ "\t" + wrongDir05 + "\t";
					report += TP01 + "\t" + TN01 + "\t" + FP01 + "\t" + FN01
							+ "\t" + wrongDir01 + "\t";
					report += numDataPointsU1 + "\t" + numDataPointsU2 + "\t";
					report += "\n";
				}
			}
		}

		for (int u1 = 0; u1 < users.length; u1++)
			for (int u2 = u1; u2 < users.length; u2++) {
				baseLineOutcomes[u1][u2] /= iterations;
				testSetOutcomes[u1][u2] /= iterations;
			}

		TP01rate /= testCount;
		FP01rate /= testCount;
		TN01rate /= testCount;
		FN01rate /= testCount;
		wrongDir01rate /= testCount;

		System.out.println("Base line results\n\n"
				+ PrettyPrint.toPrettyLine(users, "\t"));
		System.out.println(PrettyPrint.toPrettyString(baseLineOutcomes, "\t"));

		System.out.println("\nTest results\n\n"
				+ PrettyPrint.toPrettyLine(users, "\t"));
		System.out.println(PrettyPrint.toPrettyString(testSetOutcomes, "\t"));

		System.out.println("\n\n" + report);

		System.out
				.println("Number of comparisons where sufficient data were available: "
						+ testCount);

		System.out
				.println("\n\nTP .01 rate\tTN .01 rate\tFP .01 rate\tFN .01 rate\twrong dir .01 rate");
		System.out.println(TP01rate + "\t" + TN01rate + "\t" + FP01rate + "\t"
				+ FN01rate + "\t" + wrongDir01rate);

		return res;
	}

	public void runStatisticalTests(File dataFile, Classifier baseClassifier,
			String[] featureList, String[] users) throws Exception {
		this.baseClassifier = baseClassifier;
		// calling evaluate() generates the annotatedDataSet
		evaluate(featureList, dataFile, true);
		DataSet explicit = annotatedDataSet.getExplicitInstances();
		DataSet motivated = annotatedDataSet.getImplicitInstances()
				.getInstancesWithAttributeValueGreaterThan(
						annotatedDataSet.attribute("Predicted class"), .9);
		runStatisticalTests(explicit, motivated, users,
				"log Movement Time divided by ID", 25);
	}

	/**
	 * For a given feature, computes the per-user stdevs on experimental,
	 * natural, and filtered natural data sets
	 * 
	 * @param dataFile
	 * @param baseClassifier
	 * @param featureToComputeStdevsFor
	 * @param featureList
	 * @param users
	 * @throws Exception
	 */
	public void getPerUserStDevs(File dataFile, Classifier baseClassifier,
			String featureToComputeStdevsFor, String[] featureList,
			String[] users) throws Exception {
		this.baseClassifier = baseClassifier;
		// side effect of running evaluate() is that it creates the
		// annotatedDataSet
		evaluate(featureList, dataFile, true);
		DataSet explicit = annotatedDataSet.getExplicitInstances();
		DataSet implicit = annotatedDataSet.getImplicitInstances();
		DataSet motivated = annotatedDataSet.getImplicitInstances()
				.getInstancesWithAttributeValueGreaterThan(
						annotatedDataSet.attribute("Predicted class"), .9);
		System.out.println("Stdevs for " + featureToComputeStdevsFor);
		System.out.println("\t" + PrettyPrint.toPrettyLine(users, "\t"));
		System.out.println("natural:\t"
				+ PrettyPrint.toPrettyLine(getPerUserStDevs(implicit, users,
						featureToComputeStdevsFor), "\t"));
		System.out.println("explicit:\t"
				+ PrettyPrint.toPrettyLine(getPerUserStDevs(explicit, users,
						featureToComputeStdevsFor), "\t"));
		System.out.println("filtered:\t"
				+ PrettyPrint.toPrettyLine(getPerUserStDevs(motivated, users,
						featureToComputeStdevsFor), "\t"));

	}

	protected double[] getPerUserStDevs(DataSet dataSet, String[] users,
			String featureToComputeStdevsFor) {
		// how many samples are we computing stdev for
		int numSamples = 25;
		double[] res = new double[users.length];
		for (int u = 0; u < users.length; u++) {
			double[] rawData = dataSet.getInstancesForUser(users[u])
					.attributeToDoubleArray(featureToComputeStdevsFor);
			// only do it for participant for whom at least 50 data points are
			// available
			if (rawData.length >= numSamples) {
				// repeat the measurement a bunch of times to make sure that it
				// is reliable
				for (int i = 0; i < 50; i++) {
					res[u] += Math.sqrt(BasicStats.getVariance(ArrayUtils
							.getRandomSubset(rawData, numSamples)));
				}
				res[u] /= 50;
			} else
				res[u] = -1;
		}

		return res;
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		ClassifierEvaluator evaluator = new ClassifierEvaluator();
		Classifier SMO = Classifier
				.forName(
						"weka.classifiers.functions.SMO",
						new String[] { "-C", "1.0", "-L", "0.0010", "-P",
								"1.0E-12", "-N", "0", "-V", "-1", "-W", "1",
								"-K",
								"weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 1.0" });
		Classifier logistic = Classifier.forName(
				"weka.classifiers.functions.Logistic", new String[] { "-R",
						"1.0E-8", "-M", "-1" });

		File trainFileIndividual = new File(
				"/Users/kgajos/Documents/projects/abilities/normalized data/allUsersWithGoodImplicitAndExplicitData.arff");
		File trainFileGlobal = new File(
				"/Users/kgajos/Documents/projects/abilities/normalized data/allUsersWithGoodImplicitAndExplicitData-globallyNormalized.arff");
		File trainFileMixed = new File(
				"/Users/kgajos/Documents/projects/abilities/normalized data/allUsersWithGoodImplicitAndExplicitData-mixed.arff");

		File cleanDataDir = new File(
				"/Users/kgajos/Documents/projects/abilities/clean data/");
		if (!cleanDataDir.exists()) {
			System.out.println("Select the directory for saving clean data");
			cleanDataDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		// SMO GLOBAL
		// File trainFile = trainFileGlobal;
		// evaluator.runStatisticalTests(trainFile, SMO, new String[] {
		// "A-NormTMaxPeak", "Class", "J-NormTMaxPeak",
		// "Movement Time divided by ID", "S-TLastPeak divided by ID" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// SMO INDIVIDUAL
		// File trainFile = trainFileIndividual;
		// evaluator.runStatisticalTests(trainFile, SMO, new String[] { "Class",
		// "Movement Time divided by A", "Movement Time divided by ID" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// SMO MIXED
		// evaluator.runStatisticalTests(trainFileMixed, SMO, new String[] {
		// "A-NormTMaxPeak-individual", "Class", "J-NormTMaxPeak",
		// "LDI-individual", "Movement Time divided by ID-individual",
		// "S-TLastPeak divided by ID" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// LOGISTIC MIXED
		// evaluator.runStatisticalTests(trainFileMixed, logistic, new String[]
		// {
		// "A-NormT1stPeak", "Class",
		// "Movement Time divided by ID-individual",
		// "Movement Time divided by log A-individual", "Movement error",
		// "Movement variability", "Submovements (.4px/ms)",
		// "Submovements (.4px/ms)-individual" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// LOGISTIC GLOBAL
		// File trainFile = trainFileGlobal;
		// evaluator.runStatisticalTests(trainFile, logistic, new String[] {
		// "A-NormT1stPeak", "Class", "J-NormTMaxPeak",
		// "Movement Time divided by ID",
		// "Movement Time divided by log A", "Movement error",
		// "Movement variability", "S-NormT1stPeak", "S-TMaxPeak" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// LOGISTIC INDIVIDUAL
		// File trainFile = trainFileIndividual;
		// evaluator.runStatisticalTests(trainFile, logistic, new String[] {
		// "A-TMaxPeak",
		// "Class", "Movement Time divided by ID", "S-NormT1stPeak",
		// "S-TMaxPeak" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// SMO INDIVIDUAL
		// File trainFile = trainFileIndividual;
		// // evaluator.evaluateFeatures(trainFile,SMO,
		// // "Class,Movement Time divided by ID,Movement Time divided by A");
		// evaluator
		// .deeplyEvaluateFeatureSet(
		// trainFile,
		// new String[] { "Class", "Movement Time divided by A",
		// "Movement Time divided by ID" },
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-SMO-individuallyNormalized");

		// Logistic GLOBAL
		// File trainFile = trainFileGlobal;
		// evaluator.baseClassifier = logistic;
		// evaluator
		// .evaluateFeatures(
		// trainFile,
		// "A-NormT1stPeak,Class,J-NormTMaxPeak,Movement Time divided by ID,Movement Time divided by log A,Movement error,Movement variability,S-NormT1stPeak,S-TMaxPeak",
		// false);
		// evaluator
		// .deeplyEvaluateFeatureSet(
		// trainFile,
		// logistic,
		// new String[] { "A-NormT1stPeak", "Class",
		// "J-NormTMaxPeak",
		// "Movement Time divided by ID",
		// "Movement Time divided by log A",
		// "Movement error", "Movement variability",
		// "S-NormT1stPeak", "S-TMaxPeak" },
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-Logistic-globallyNormalized");

		// Logistic MIXED
		File trainFile = trainFileMixed;
		evaluator.baseClassifier = logistic;
		// evaluator
		// .evaluateFeatures(
		// trainFile,
		// "A-NormT1stPeak,Class,Movement Time divided by ID-individual,Movement Time divided by log A-individual,Movement error,Movement variability,Submovements (.4px/ms),Submovements (.4px/ms)-individual",
		// false);
		// evaluator
		// .deeplyEvaluateFeatureSet(
		// trainFile,
		// logistic,
		// new String[] { "A-NormT1stPeak", "Class",
		// "Movement Time divided by ID-individual",
		// "Movement Time divided by log A-individual",
		// "Movement error", "Movement variability",
		// "Submovements (.4px/ms)",
		// "Submovements (.4px/ms)-individual" },
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-Logistic-mixed");
		evaluator.getPerUserStDevs(trainFile, logistic,
				"Movement Time divided by ID-original", new String[] {
						"A-NormT1stPeak", "Class",
						"Movement Time divided by ID-individual",
						"Movement Time divided by log A-individual",
						"Movement error", "Movement variability",
						"Submovements (.4px/ms)",
						"Submovements (.4px/ms)-individual" },
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// Logistic GLOBAL TARGET-AGNOSTIC
		// File trainFile = trainFileGlobal;
		// evaluator.baseClassifier = logistic;
		// // evaluator
		// .evaluateFeatures(
		// trainFile,
		// "A-NormT1stPeak,A-NormTMaxPeak,Class,J-NormTMaxPeak,Movement Time divided by A,Movement error,S-NormT1stPeak",
		// false);
		// evaluator
		// .deeplyEvaluateFeatureSet(
		// trainFile,
		// logistic,
		// new String[] { "A-NormT1stPeak", "A-NormTMaxPeak",
		// "Class", "J-NormTMaxPeak",
		// "Movement Time divided by A", "Movement error",
		// "S-NormT1stPeak" },
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-Logistic-globallyNormalized-targetAgnostic");
		// evaluator.runStatisticalTests(trainFile, logistic, new String[] {
		// "A-NormT1stPeak", "A-NormTMaxPeak", "Class", "J-NormTMaxPeak",
		// "Movement Time divided by A", "Movement error",
		// "S-NormT1stPeak" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// Logistic MIXED TARGET-AGNOSTIC
		// File trainFile = trainFileMixed;
		// evaluator.baseClassifier = logistic;
		// // evaluator
		// // .evaluateFeatures(
		// // trainFile,
		// //
		// "A-NormT1stPeak,A-TMaxPeak,Class,J-TMaxPeak,Movement Time divided by A-individual,Movement Time divided by log A-individual,Movement error,Movement variability,S-NormT1stPeak,Submovements (.4px/ms)-individual",
		// // false);
		// // evaluator
		// // .deeplyEvaluateFeatureSet(
		// // trainFile,
		// // logistic,
		// // new String[] { "A-NormT1stPeak", "A-TMaxPeak", "Class",
		// // "J-TMaxPeak",
		// // "Movement Time divided by A-individual",
		// // "Movement Time divided by log A-individual",
		// // "Movement error", "Movement variability",
		// // "S-NormT1stPeak",
		// // "Submovements (.4px/ms)-individual" },
		// //
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-Logistic-mixed-targetAgnostic");
		// evaluator.runStatisticalTests(trainFile, logistic, new String[] {
		// "A-NormT1stPeak", "A-TMaxPeak", "Class", "J-TMaxPeak",
		// "Movement Time divided by A-individual",
		// "Movement Time divided by log A-individual", "Movement error",
		// "Movement variability", "S-NormT1stPeak",
		// "Submovements (.4px/ms)-individual" },
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		// evaluator
		// .deeplyEvaluateFeatureSet(
		// trainFile,
		// new String[] { "A-NormTMaxPeak", "Class",
		// "Movement Time divided by ID", "Movement error" },
		// "/Users/kgajos/Documents/projects/abilities/normalized data/dataWithPredictions-globallyNormalized");

		// evaluator.evaluateDataRequirements(
		// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
		// new String[] { "Class", "Movement Time divided by ID",
		// "S-TMaxPeak", "Movement error", "LDI", "A-TMaxPeak" },
		// cleanDataDir);

	}
}
