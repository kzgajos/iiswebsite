package edu.harvard.seas.iis.abilities.analysis;

import java.util.Collection;
import java.util.Hashtable;

import edu.harvard.seas.iis.util.stats.BasicStats;
import edu.harvard.seas.iis.util.stats.LinearRegressionCalculator;

/**
 * @author kgajos
 * 
 *         Various tools for manipulating Movement objects
 */
public class MovementUtils {

	/**
	 * @param movements
	 * @return [intercept, slope]
	 */
	public static double[] computeFittsCoefficients(
			Collection<Movement> movements) {
		double[] ids = getPropertyAsArray(movements, "ID");
		double[] movementTimes = getPropertyAsArray(movements, "Movement Time");
		return LinearRegressionCalculator.computeLinearRegressionParameters(
				ids, movementTimes);
	}

	/**
	 * for a collection of movements, extracts a particular (numerical) property
	 * from each, and returns an array of the values
	 * 
	 * @param movements
	 * @param propertyName
	 * @return
	 */
	public static double[] getPropertyAsArray(Collection<Movement> movements,
			String propertyName) {
		double[] res = new double[movements.size()];
		int cnt = 0;
		for (Movement m : movements) {
			Hashtable<String, Object> features = m.getMovementFeatures();
			res[cnt++] = ((Number) (features.get(propertyName))).doubleValue();
		}
		return res;
	}

	/**
	 * Computes a mean and stdev for a given property over a collection of
	 * movements
	 * 
	 * @param movements
	 * @param propertyName
	 * @return
	 */
	public static double[] getMeanAndStdevForProperty(
			Collection<Movement> movements, String propertyName) {
		double[] vals = getPropertyAsArray(movements, propertyName);
		return new double[] { BasicStats.getMean(vals),
				Math.sqrt(BasicStats.getVariance(vals)) };
	}

	/**
	 * Computes root mean square difference between the actual movement time and
	 * the movement time predicted by the Fitts' model with parameters a and b.
	 * 
	 * @param movements
	 * @param a
	 * @param b
	 * @return
	 */
	public static double getRMSdeviationFromFitts(
			Collection<Movement> movements, double a, double b) {
		double res = 0;
		double diff;
		for (Movement m : movements) {
			diff = a + b * m.indexOfDifficulty - m.movementTime;
			res += diff * diff;
		}
		res /= movements.size();
		res = Math.sqrt(res);
		return res;
	}

}
