package edu.harvard.seas.iis.abilities.analysis;

import java.awt.Point;
import java.io.Serializable;
import java.util.Vector;

import edu.harvard.seas.iis.util.dsp.LowPassFilter;
import edu.harvard.seas.iis.util.geom2D.Geom2DUtils;

public class MovementPoint implements Serializable {

	private static final long serialVersionUID = 1L;

	protected double x, y;

	// raw velocity is calculated just by looking at diffs in raw position;
	// signedVelocity is smoothed but signed depending on whether motion is in
	// positive or negative direction along x-axis
	protected double distanceFromTarget = 0, displacement = 0, velocity = 0,
			rawVelocity = 0, signedVelocity = 0, acceleration = 0, jerk = 0;

	// normalized x,y have been rotated so that x-axis = task axis; normalizedX
	// and normalizedY also get smoothed whereas their raw versions do not
	protected double normalizedX, normalizedY, rawNormalizedX, rawNormalizedY;

	// t = actual time stamp; relativeT = time in ms from movement start
	protected double t, relativeT;

	// normalizedT = 1 for the first PROPER target acquisition
	protected double normalizedT;

	protected boolean insideTarget;

	public MovementPoint(Point origin, double movementAngle, double x,
			double y, double t, boolean insideTarget) {
		this.x = x;
		this.y = y;
		this.t = t;
		this.insideTarget = insideTarget;
		init(origin, movementAngle);
	}

	protected void init(Point origin, double movementAngle) {
		double[] normalizedXY = getNormalizedPoint(origin, movementAngle, x, y);
		normalizedX = normalizedXY[0];
		normalizedY = normalizedXY[1];
		rawNormalizedX = normalizedX;
		rawNormalizedY = normalizedY;
	}

	public static double[] getNormalizedPoint(Point origin,
			double movementAngle, double x, double y) {
		double res[] = new double[] { 0, 0 };
		if (origin != null) {
			res[0] = x - origin.x;
			res[1] = y - origin.y;
			res = Geom2DUtils.rotate(res[0], res[1], -Math
					.toRadians(movementAngle));
		}
		return res;
	}

	/**
	 * Call this if the movement angle or the starting point of the movement
	 * change
	 * 
	 * @param origin
	 * @param movementAngle
	 */
	public void updateMovementInformation(Point origin, double movementAngle) {
		init(origin, movementAngle);
	}

	public boolean isInsideTarget() {
		return insideTarget;
	}

	public double getT() {
		return t;
	}

	public double getNormalizedT() {
		return normalizedT;
	}

	public void setNormalizedT(double normalizedT) {
		this.normalizedT = normalizedT;
	}

	public double getRelativeT() {
		return relativeT;
	}

	public void setRelativeT(double relativeT) {
		this.relativeT = relativeT;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getNormalizedX() {
		return normalizedX;
	}

	public double getNormalizedY() {
		return normalizedY;
	}

	public double getRawNormalizedX() {
		return rawNormalizedX;
	}

	public double getRawNormalizedY() {
		return rawNormalizedY;
	}

	public double getAcceleration() {
		return acceleration;
	}

	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}

	public double getDistanceFromTarget() {
		return distanceFromTarget;
	}

	public void setDistanceFromTarget(double distanceFromTarget) {
		this.distanceFromTarget = distanceFromTarget;
	}

	public double getJerk() {
		return jerk;
	}

	public void setJerk(double jerk) {
		this.jerk = jerk;
	}

	public double getVelocity() {
		return velocity;
	}

	public void setVelocity(double velocity) {
		this.velocity = velocity;
	}

	public static String getDetailedHeadings() {
		String res = "Normalized T" + Constants.SEPARATOR;
		res += "Relative T" + Constants.SEPARATOR;
		res += "Actual X" + Constants.SEPARATOR;
		res += "Actual Y" + Constants.SEPARATOR;
		res += "Horiz X" + Constants.SEPARATOR;
		res += "Horiz Y" + Constants.SEPARATOR;
		res += "Horiz&smoothed X" + Constants.SEPARATOR;
		res += "Horiz&smoothed Y" + Constants.SEPARATOR;
		res += "Distance from target (2D)" + Constants.SEPARATOR;
		res += "Cumulative displacement (2D)" + Constants.SEPARATOR;
		res += "Raw Speed (2D)" + Constants.SEPARATOR;
		res += "Speed (2D)" + Constants.SEPARATOR;
		res += "Speed-signed (2D)" + Constants.SEPARATOR;
		res += "Acceleration (2D)" + Constants.SEPARATOR;
		res += "Jerk (2D)" + Constants.SEPARATOR;

		return res;
	}

	public String toDetailedString() {
		String res = normalizedT + Constants.SEPARATOR;
		res += relativeT + Constants.SEPARATOR;
		res += x + Constants.SEPARATOR;
		res += y + Constants.SEPARATOR;
		res += rawNormalizedX + Constants.SEPARATOR;
		res += rawNormalizedY + Constants.SEPARATOR;
		res += normalizedX + Constants.SEPARATOR;
		res += normalizedY + Constants.SEPARATOR;
		res += distanceFromTarget + Constants.SEPARATOR;
		res += displacement + Constants.SEPARATOR;
		res += rawVelocity + Constants.SEPARATOR;
		res += velocity + Constants.SEPARATOR;
		res += signedVelocity + Constants.SEPARATOR;
		res += acceleration + Constants.SEPARATOR;
		res += jerk + Constants.SEPARATOR;

		return res;
	}

	public String toString() {
		return "(" + x + "," + y + ")";
	}

	public static double[] getXsAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getX();
		return res;
	}

	public static double[] getYsAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getY();
		return res;
	}

	public static double[] getNormalizedXsAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getNormalizedX();
		return res;
	}

	public static double[] getNormalizedYsAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getNormalizedY();
		return res;
	}

	public static double[] getDistanceFromTargetAsArray(
			Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getDistanceFromTarget();
		return res;
	}

	public static double[] getVelocityAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getVelocity();
		return res;
	}

	public static double[] getRawVelocityAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).rawVelocity;
		return res;
	}

	public static double[] getAccelerationAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getAcceleration();
		return res;
	}

	public static double[] getJerkAsArray(Vector<MovementPoint> mpoints) {
		double[] res = new double[mpoints.size()];
		for (int i = 0; i < res.length; i++)
			res[i] = mpoints.elementAt(i).getJerk();
		return res;
	}

	/**
	 * Resamples points at equal intervals
	 * 
	 * @param mpoints
	 * @param origin
	 * @param angle
	 * @param newInterval
	 * @return
	 */
	public static Vector<MovementPoint> resample(Vector<MovementPoint> mpoints,
			Point origin, double angle, double newInterval) {
		Vector<MovementPoint> res = new Vector<MovementPoint>();
		MovementPoint prev = mpoints.elementAt(0);
		MovementPoint next = mpoints.elementAt(1);
		int nextIndex = 1;
		double startTime = prev.getT();
		double curT = prev.getT();
		double endT = mpoints.lastElement().getT();
		res.add(new MovementPoint(origin, angle, prev.x, prev.y, prev.t,
				prev.insideTarget));

		double coefN = (curT - prev.t) / (next.t - prev.t);
		double coefP = (next.t - curT) / (next.t - prev.t);
		curT += newInterval;
		for (; curT <= endT; curT += newInterval) {
			while (next.getT() < curT)
				next = mpoints.elementAt(++nextIndex);
			if (next.getT() == curT) {
				prev = next;
				coefN = 1.0;
				coefP = 0.0;
			} else {
				prev = mpoints.elementAt(nextIndex - 1);
				coefN = (curT - prev.t) / (next.t - prev.t);
				coefP = (next.t - curT) / (next.t - prev.t);
			}
			res.addElement(new MovementPoint(origin, angle, coefN * next.x
					+ coefP * prev.x, coefN * next.y + coefP * prev.y, curT,
					next.insideTarget));
			res.lastElement()
					.setRelativeT(res.lastElement().getT() - startTime);
		}

		return res;
	}

	public static void initialSmoothing(Vector<MovementPoint> mpoints) {
		xysmoothing(mpoints, initialSmoothingCoefficients);
	}

	/**
	 * Performs the final low pass smoothing of X, Y, Accel and Jerk
	 * 
	 * @param mpoints
	 */
	public static void finalSmoothing(Vector<MovementPoint> mpoints) {
		// smooth the path
		xysmoothing(mpoints, finalSmoothingCoefficients);
		// smooth velocity
		double smoothedVelocity[] = LowPassFilter.filter(
				getVelocityAsArray(mpoints), finalSmoothingCoefficients);
		// smooth acceleration
		double smoothedAccel[] = LowPassFilter.filter(
				getAccelerationAsArray(mpoints), finalSmoothingCoefficients);
		// smooth jerk
		double smoothedJerk[] = LowPassFilter.filter(getJerkAsArray(mpoints),
				finalSmoothingCoefficients);

		for (int i = 0; i < mpoints.size(); i++) {
			mpoints.elementAt(i).velocity = smoothedVelocity[i];
			mpoints.elementAt(i).acceleration = smoothedAccel[i];
			mpoints.elementAt(i).jerk = smoothedJerk[i];
		}
	}

	public static void smoothDistanceToTarget(Vector<MovementPoint> mpoints) {
		// smooth distance from target
		double smoothedDistanceToTarget[] = LowPassFilter.filter(
				getDistanceFromTargetAsArray(mpoints),
				finalSmoothingCoefficients);
		for (int i = 0; i < mpoints.size(); i++)
			mpoints.elementAt(i).distanceFromTarget = smoothedDistanceToTarget[i];
	}

	protected static void xysmoothing(Vector<MovementPoint> mpoints,
			double[] coefficients) {
		double smoothedX[] = LowPassFilter.filter(
				getNormalizedXsAsArray(mpoints), coefficients);
		double smoothedY[] = LowPassFilter.filter(
				getNormalizedYsAsArray(mpoints), coefficients);
		for (int i = 0; i < mpoints.size(); i++) {
			mpoints.elementAt(i).normalizedY = smoothedY[i];
			mpoints.elementAt(i).normalizedX = smoothedX[i];
		}
	}

	public static void computeVelocity(Vector<MovementPoint> mpoints) {
		for (int i = 1; i < mpoints.size(); i++) {
			for (int j = 0; j < differentiatingFilterCoefficients.length; j++) {
				MovementPoint prevPoint = getVectorElement(mpoints, i - j - 1), curPoint = getVectorElement(
						mpoints, i - j);
				double distance = Geom2DUtils.getDistance(
						prevPoint.normalizedX, prevPoint.normalizedY,
						curPoint.normalizedX, curPoint.normalizedY);
				mpoints.get(i).velocity += differentiatingFilterCoefficients[j]
						* distance;
			}
			// this will get us velocity in pixels per ms
			mpoints.get(i).velocity /= Constants.SAMPLING_INTERVAL;
		}
	}

	protected static <T> T getVectorElement(Vector<T> v, int index) {
		if (index < 0)
			return v.firstElement();
		else if (index >= v.size())
			return v.lastElement();
		else
			return v.get(index);
	}

	public static void computeAcceleration(Vector<MovementPoint> mpoints) {
		double[] accel = LowPassFilter.differentiatingFilter(
				getVelocityAsArray(mpoints), differentiatingFilterCoefficients,
				Constants.SAMPLING_INTERVAL);
		for (int i = 0; i < mpoints.size(); i++)
			mpoints.elementAt(i).acceleration = accel[i];
	}

	public static void computeJerk(Vector<MovementPoint> mpoints) {
		double[] jerk = LowPassFilter.differentiatingFilter(
				getAccelerationAsArray(mpoints),
				differentiatingFilterCoefficients, Constants.SAMPLING_INTERVAL);
		for (int i = 0; i < mpoints.size(); i++)
			mpoints.elementAt(i).jerk = jerk[i];
	}

	// low pass filter with 50db attenuation, 30Hz stop band assuming 100Hz
	// sampling rate
	protected static double[] initialSmoothingCoefficients = LowPassFilter.ner(
			50, .6, .05, 150);

	protected static double[] differentiatingFilterCoefficients = LowPassFilter
			.nerd(20, .6, .05, 150);

	// low pass filter with 50db attenuation, 7Hz stop band, assuming 100Hz
	// sampling rate
	protected static double[] finalSmoothingCoefficients = LowPassFilter.ner(
			50, .14, .01, 150);

}
