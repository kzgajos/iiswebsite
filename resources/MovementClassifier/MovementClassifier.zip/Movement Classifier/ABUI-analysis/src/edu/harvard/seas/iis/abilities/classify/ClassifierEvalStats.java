package edu.harvard.seas.iis.abilities.classify;

import java.util.StringTokenizer;

import edu.harvard.seas.iis.util.collections.PrettyPrint;

public class ClassifierEvalStats {

	double implicitError = 0, motivatedError = 0,
			fractionOfMotivatedMovements = 0;
	double minImplicitError = Double.MAX_VALUE,
			maxImplicitError = Double.MIN_VALUE;
	double minMotivatedError = Double.MAX_VALUE,
			maxMotivatedError = Double.MIN_VALUE;
	double minFractionOfMotivatedMovements = Double.MAX_VALUE,
			maxFractionOfMotivatedMovements = Double.MIN_VALUE;
	double motivatedIPError = 0, motivatedAbsoluteIPError = 0,
			minMotivatedIPError = Double.MAX_VALUE,
			maxMotivatedIPError = Double.MIN_VALUE;
	double implicitIPError = 0, minImplicitIPError = Double.MAX_VALUE,
			maxImplicitIPError = Double.MIN_VALUE;
	double recall = 0, minRecall = Double.MAX_VALUE,
			maxRecall = Double.MIN_VALUE;
	double meanAbsoluteMTbyIDerror = 0,
			worstAbsoluteMTbyIDerror = Double.MIN_VALUE,
			minMTbyIDerror = Double.MAX_VALUE,
			maxMTbyIDerror = Double.MIN_VALUE;
	// mean stdev per participant
	double implicitMTbyIDstdev = 0, motivatedMTbyIDstdev = 0,
			explicitMTbyIDstdev = 0;
	double implicitAbsoluteMTbyIDerror = 0,
			minImplicitAbsoluteMTbyIDerror = Double.MAX_VALUE,
			maxImplicitAbsoluteMTbyIDerror = Double.MIN_VALUE;

	double worstAbsoluteMotivatedError;
	double worstAbsoluteMotivatedIPError;

	protected String[] headers1 = { "MT/ID mean absolute error", "min", "max",
			"Stdev", "Mean absolute error in the movement time predictions",
			"min", "max", "Index of Performance mean absolute error", "min",
			"max", "Mean recall", "min", "max",
			"Fraction of natural movements classified as deliberate", "min",
			"max" };

	public String getHeader1() {
		return PrettyPrint.toPrettyLine(headers1, "\t");
	}

	public String getReport1() {
		String res = "";
		res += meanAbsoluteMTbyIDerror + "\t";
		res += minMTbyIDerror + "\t";
		res += maxMTbyIDerror + "\t";
		res += motivatedMTbyIDstdev + "\t";
		res += motivatedError + "\t";
		res += minMotivatedError + "\t";
		res += maxMotivatedError + "\t";
		res += motivatedAbsoluteIPError + "\t";
		res += minMotivatedIPError + "\t";
		res += maxMotivatedIPError + "\t";
		res += recall + "\t";
		res += minRecall + "\t";
		res += maxRecall + "\t";
		res += fractionOfMotivatedMovements + "\t";
		res += minFractionOfMotivatedMovements + "\t";
		res += maxFractionOfMotivatedMovements + "\t";

		return res;
	}

	public String getReport1ForNaturalData() {
		String res = "";
		res += implicitAbsoluteMTbyIDerror + "\t";
		res += minImplicitAbsoluteMTbyIDerror + "\t";
		res += maxImplicitAbsoluteMTbyIDerror + "\t";
		res += implicitMTbyIDstdev + "\t";
		res += implicitError + "\t";
		res += minImplicitError + "\t";
		res += maxImplicitError + "\t";

		res += implicitIPError + "\t";
		res += minImplicitIPError + "\t";
		res += maxImplicitIPError + "\t";

		return res;
	}

	public static ClassifierEvalStats fromReport1(StringTokenizer report) {
		double[] results = new double[report.countTokens()];
		for (int i = 0; i < results.length; i++) {
			results[i] = Double.parseDouble(report.nextToken());
		}

		ClassifierEvalStats stats = new ClassifierEvalStats();
		stats.meanAbsoluteMTbyIDerror = results[0];
		stats.minMTbyIDerror = results[1];
		stats.maxMTbyIDerror = results[2];
		stats.worstAbsoluteMTbyIDerror = Math.max(Math
				.abs(stats.minMTbyIDerror), stats.maxMTbyIDerror);
		stats.motivatedMTbyIDstdev = results[3];
		stats.motivatedError = results[4];
		stats.minMotivatedError = results[5];
		stats.maxMotivatedError = results[6];
		stats.worstAbsoluteMotivatedError = Math.max(Math
				.abs(stats.minMotivatedError), stats.maxMotivatedError);
		stats.motivatedAbsoluteIPError = results[7];
		stats.minMotivatedIPError = results[8];
		stats.maxMotivatedIPError = results[9];
		stats.worstAbsoluteMotivatedIPError = Math.max(Math
				.abs(stats.minMotivatedIPError), stats.maxMotivatedIPError);
		stats.recall = results[10];
		stats.minRecall = results[11];
		stats.maxRecall = results[12];
		stats.fractionOfMotivatedMovements = results[13];
		stats.minFractionOfMotivatedMovements = results[14];
		stats.maxFractionOfMotivatedMovements = results[15];

		return stats;
	}
}
