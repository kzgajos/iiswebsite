package edu.harvard.seas.iis.abilities.analysis;

import java.util.Collection;
import java.util.Vector;

public abstract class MovementFilter {

	/**
	 * The method for subclasses to implement
	 * 
	 * @return true if the movement should be kept, false otherwise
	 */
	public abstract boolean evaluateMovement(Movement m);

	public Vector<Movement> filter(Collection<Movement> movements) {
		Vector<Movement> res = new Vector<Movement>();
		for (Movement m : movements)
			if (evaluateMovement(m))
				res.add(m);
		return res;
	}

	/**
	 * Applies a collection of filters to a collection of movements
	 * 
	 * @param filters
	 * @param movements
	 * @return
	 */
	public static Vector<Movement> filter(Collection<MovementFilter> filters,
			Collection<Movement> movements) {
		Vector<Movement> res = new Vector<Movement>();
		res.addAll(movements);
		for (MovementFilter f : filters)
			res = f.filter(res);
		return res;
	}
}
