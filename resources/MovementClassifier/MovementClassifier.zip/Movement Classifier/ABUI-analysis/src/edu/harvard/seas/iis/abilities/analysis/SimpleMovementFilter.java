package edu.harvard.seas.iis.abilities.analysis;

import java.util.Collection;
import java.util.Vector;

public class SimpleMovementFilter extends MovementFilter {

	protected String propertyToFilterOn;
	// if true then we assume that the property is numerical and we filter by
	// lower/upper bound; otherwise, we assume the property is nominal
	protected boolean numerical;

	// min/max values if filtering on a numerical property
	protected double minValue, maxValue;

	// allowed values if filtering by a nominal property
	protected Vector<Object> allowedValues = new Vector<Object>();

	public SimpleMovementFilter(String propertyToFilterOn, boolean numerical) {
		super();
		this.propertyToFilterOn = propertyToFilterOn;
		this.numerical = numerical;
	}

	public String getPropertyToFilterOn() {
		return propertyToFilterOn;
	}

	public boolean isNumerical() {
		return numerical;
	}

	@Override
	public boolean evaluateMovement(Movement m) {
		Object val = m.getMovementFeatures().get(propertyToFilterOn);
		if (val == null)
			val = m.getAdditionalMetaData(propertyToFilterOn);
		if (numerical) {
			if (val == null || !(val instanceof Number))
				return false;
			double numVal = ((Number) val).doubleValue();
			return numVal >= minValue && numVal <= maxValue;
		} else {
			if (val == null)
				return false;
			return allowedValues.contains(val);
		}
	}

	public void setNumericalFilter(double minValue, double maxValue) {
		this.minValue = minValue;
		this.maxValue = maxValue;
	}

	public double getMinValue() {
		return minValue;
	}

	public double getMaxValue() {
		return maxValue;
	}

	public void setNominalFilter(Collection<Object> allowedValues) {
		this.allowedValues.clear();
		this.allowedValues.addAll(allowedValues);
	}

	public void addAllowedNominalValue(Object val) {
		if (!allowedValues.contains(val))
			allowedValues.add(val);
	}

	public void removeAllowedNominalValue(Object val) {
		allowedValues.remove(val);
	}
}
