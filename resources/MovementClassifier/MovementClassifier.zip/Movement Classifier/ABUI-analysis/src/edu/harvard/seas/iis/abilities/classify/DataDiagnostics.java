package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import org.apache.commons.math.MathException;
import org.apache.commons.math.stat.inference.TTestImpl;

import weka.core.Attribute;
import weka.experiment.Stats;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;
import edu.harvard.seas.iis.util.stats.BasicStats;

/**
 * @author kgajos
 * 
 *         This class contains tools for inspecting our data (through
 *         descriptive statistics and any other mechanisms that turn out to be
 *         helpful)
 */
public class DataDiagnostics {

	/*** BASIC STATS *****/

	public static String[] BASIC_STATS = { "num instances",
			"num explicit instances", "num implicit instances",
			"explicit Fitts' intercept", "explicit Fitts' slope",
			"explicit Fitts' IP", "implicit Fitts' intercept",
			"implicit Fitts' slope", "implicit Fitts' IP",
			"implicit Fitts' MT error", "explicit MT/ID mean",
			"explicit MT/ID stdev", "implicit MT/ID mean",
			"implicit MT/ID stdev" };

	public static Double[] getBasicStats(DataSet dataSet,
			boolean computeFittsStats) {
		Double[] res = new Double[14];

		DataSet explicit = dataSet.getExplicitInstances();
		DataSet implicit = dataSet.getImplicitInstances();

		res[0] = new Double(dataSet.numInstances());
		res[1] = new Double(explicit.numInstances());
		res[2] = new Double(implicit.numInstances());

		double[] explicitFitts = new double[0];
		if (explicit.numInstances() >= 10 && computeFittsStats) {
			explicitFitts = ClassifierEvaluator
					.computeFittsLawCoefficients(explicit);
			res[3] = explicitFitts[0];
			res[4] = explicitFitts[1];
			res[5] = 1000.0 / explicitFitts[1];
		}

		if (implicit.numInstances() >= 10 && computeFittsStats) {
			double[] fitts = ClassifierEvaluator
					.computeFittsLawCoefficients(implicit);
			res[6] = fitts[0];
			res[7] = fitts[1];
			res[8] = 1000.0 / fitts[1];

			if (explicitFitts.length > 0) {
				res[9] = ClassifierEvaluator.compareFittsLawModels(
						explicitFitts, fitts)[1];
			}
		}
		if (explicit.attribute("Movement Time divided by ID") != null) {
			int mtbyidIndex = explicit.attribute("Movement Time divided by ID")
					.index();
			res[10] = explicit.meanOrMode(mtbyidIndex);
			res[11] = Math.sqrt(explicit.variance(mtbyidIndex));
			res[12] = implicit.meanOrMode(mtbyidIndex);
			res[13] = Math.sqrt(implicit.variance(mtbyidIndex));
		}

		return res;
	}

	public static void generateBasicStatistics(File dataDirectory,
			boolean computeFittsStats, String[] users) {

		System.out.println("user\tParticipant\t"
				+ PrettyPrint.toPrettyLine(BASIC_STATS, "\t"));

		for (String user : users) {
			try {
				File f = new File(dataDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				Double[] stats = getBasicStats(dataSet, computeFittsStats);
				System.out.println(user + "\t"
						+ Transform.getParticipantCode(user) + "\t"
						+ PrettyPrint.toPrettyLine(stats, "\t"));
			} catch (IOException e) {
				System.err.println("Trouble rading data for user " + user);
				e.printStackTrace();
			}
		}
	}

	/*** BASIC PER-ATTRIBUTE STATS *****/

	public static String[] basicAttributeStatsNames;

	public static Double[] getBasicAttributeStats(DataSet dataSet) {
		Vector<String> names = new Vector<String>();
		Vector<Double> values = new Vector<Double>();

		Attribute curAttribute = null;
		for (int i = 0; i < dataSet.numAttributes(); i++) {
			curAttribute = dataSet.attribute(i);
			if (curAttribute.type() == Attribute.NUMERIC) {
				Stats stats = dataSet.attributeStats(i).numericStats;
				names.add(curAttribute.name() + " (Mean)");
				values.add(stats.mean);
				names.add(curAttribute.name() + " (Stdev)");
				values.add(stats.stdDev);
			}
		}

		basicAttributeStatsNames = names.toArray(new String[] {});
		return values.toArray(new Double[] {});
	}

	public static void generateBasicAttributeStatistics(File dataDirectory,
			String[] usersToInclude) {
		boolean headerPrinted = false;

		for (String user : usersToInclude) {
			try {
				File f = new File(dataDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				dataSet = dataSet.getImplicitInstances();
				Double[] stats = getBasicAttributeStats(dataSet);
				if (!headerPrinted)
					System.out.println("user\t"
							+ PrettyPrint.toPrettyLine(
									basicAttributeStatsNames, "\t"));
				System.out.println(user + "\t"
						+ PrettyPrint.toPrettyLine(stats, "\t"));
				headerPrinted = true;
			} catch (IOException e) {
				System.err.println("Trouble rading file for " + user);
				e.printStackTrace();
			}
		}
	}

	/*** PER-ATTRIBUTE CORRELATIONS WITH TASK PROPERTIES *****/

	public static String[] perAttributeCorrelationNames;

	public static Double[] getPerAttributeCorrelations(DataSet dataSet) {
		Vector<String> names = new Vector<String>();
		Vector<Double> values = new Vector<Double>();

		double[] ID = dataSet.attributeToDoubleArray("ID");
		double[] A = dataSet.attributeToDoubleArray("A");
		double[] W = dataSet.attributeToDoubleArray("W");

		Attribute curAttribute = null;
		for (int i = 0; i < dataSet.numAttributes(); i++) {
			curAttribute = dataSet.attribute(i);
			if (curAttribute.type() == Attribute.NUMERIC) {
				double[] vals = dataSet.attributeToDoubleArray(i);
				names.add(curAttribute.name() + " vs ID");
				values.add(BasicStats.getR2(ID, vals));
				names.add(curAttribute.name() + " vs A");
				values.add(BasicStats.getR2(A, vals));
				names.add(curAttribute.name() + " vs W");
				values.add(BasicStats.getR2(W, vals));
			}
		}

		perAttributeCorrelationNames = names.toArray(new String[] {});
		return values.toArray(new Double[] {});
	}

	public static void generatePerAttributeCorrelations(File dataDirectory) {
		boolean headerPrinted = false;

		for (String user : Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA) {
			try {
				File f = new File(dataDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				// dataSet = dataSet.getExplicitInstances();
				dataSet = dataSet.getImplicitInstances();
				Double[] stats = getPerAttributeCorrelations(dataSet);
				if (!headerPrinted)
					System.out.println("user\t"
							+ PrettyPrint.toPrettyLine(
									perAttributeCorrelationNames, "\t"));
				System.out.println(user + "\t"
						+ PrettyPrint.toPrettyLine(stats, "\t"));
				headerPrinted = true;
			} catch (IOException e) {
				System.err.println("Trouble rading file for " + user);
				e.printStackTrace();
			}
		}
	}

	/***
	 * PER-ATTRIBUTE T-TESTS CHECKING IF ATTRIBUTE VARIES SIGNIFICANTLY BETWEEN
	 * IMPLICIT AND EXPLICIT DATA
	 *****/

	public static String[] perAttributeNames;

	public static Double[] getTTests(DataSet dataSet) {
		Vector<String> names = new Vector<String>();
		Vector<Double> values = new Vector<Double>();

		DataSet implicit = dataSet.getImplicitInstances();
		DataSet explicit = dataSet.getExplicitInstances();

		TTestImpl ttest = new TTestImpl();

		Attribute curAttribute = null;
		for (int i = 0; i < dataSet.numAttributes(); i++) {
			curAttribute = dataSet.attribute(i);
			if (curAttribute.type() == Attribute.NUMERIC) {
				names.add(curAttribute.name());
				double[] implicitVals = implicit.attributeToDoubleArray(i);
				double[] explicitVals = explicit.attributeToDoubleArray(i);

				double res;
				try {
					res = ttest.tTest(implicitVals, explicitVals);
					values.add(res);
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (MathException e) {
					e.printStackTrace();
				}
			}
		}

		perAttributeNames = names.toArray(new String[] {});
		return values.toArray(new Double[] {});
	}

	public static void getTTests(File dataDirectory, String[] usersToInclude) {
		boolean headerPrinted = false;

		for (String user : usersToInclude) {
			try {
				File f = new File(dataDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				Double[] stats = getTTests(dataSet);
				if (!headerPrinted)
					System.out
							.println("user\t"
									+ PrettyPrint.toPrettyLine(
											perAttributeNames, "\t"));
				System.out.println(user + "\t"
						+ PrettyPrint.toPrettyLine(stats, "\t"));
				headerPrinted = true;
			} catch (IOException e) {
				System.err.println("Trouble rading file for " + user);
				e.printStackTrace();
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File dataDir = new File(Settings.DATA_DIRECTORY);
		if (!dataDir.exists()) {
			System.out.println("Select the data directory");
			dataDir = FileManipulation.getUserSpecifiedDirForReading();
			Settings.DATA_DIRECTORY = dataDir.getAbsolutePath();
		}

		File explicitDataDir = new File(Settings.EXPLICIT_DATA_DIRECTORY);
		File naturalDataDir = new File(Settings.NATURAL_DATA_DIRECTORY);
		File parsedDataDir = new File(Settings.PARSED_DATA_DIRECTORY);
		File transformedDataDir = new File(Settings.TRANSFORMED_DATA_DIRECTORY);
		File cleanDataDir = new File(Settings.CLEAN_DATA_DIRECTORY);
		File normalizedDataDir = new File(Settings.NORMALIZED_DATA_DIRECTORY);

		generateBasicStatistics(cleanDataDir, true, Settings.ALL_USER_NAMES);
		System.exit(0);
		generateBasicStatistics(normalizedDataDir, false,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);

		generatePerAttributeCorrelations(transformedDataDir);
		getTTests(transformedDataDir,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA);
	}

}
