package edu.harvard.seas.iis.abilities.analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

/**
 * This class allows us to read logs from different sources
 * 
 * @author kgajos
 * 
 */
public class LogSource {

	protected File[] logFiles;
	protected int fileCounter = 0;
	protected BufferedReader currentLogFileReader;
	protected String logString;
	protected StringTokenizer currentLogStringTokenizer;

	public LogSource(String log) {
		logString = log;
		currentLogStringTokenizer = new StringTokenizer(log);
	}

	public LogSource(File[] files) throws FileNotFoundException {
		// make sure that files are ordered correctly
		Arrays.sort(files, new ParserFileComparator());
		logFiles = files;

		if (logFiles.length > 0 && logFiles[0] != null)
			currentLogFileReader = new BufferedReader(new FileReader(
					logFiles[0]));
	}

	public String getNextLine() throws IOException {
		if (currentLogStringTokenizer != null) {
			if (currentLogStringTokenizer.hasMoreElements())
				return currentLogStringTokenizer.nextToken();
			else
				return null;
		} else if (currentLogFileReader != null) {
			String nextLine = currentLogFileReader.readLine();
			if (nextLine == null && fileCounter < logFiles.length - 1) {
				currentLogFileReader.close();
				fileCounter++;
				currentLogFileReader = new BufferedReader(new FileReader(
						logFiles[fileCounter]));
				nextLine = currentLogFileReader.readLine();
			}
			return nextLine;
		}
		return null;
	}

	public String getCurrentSource() {
		if (logString != null)
			return "string log";
		else
			return logFiles[fileCounter].getAbsolutePath();
	}

}

class ParserFileComparator implements Comparator<File> {
	public int compare(File one, File two) {
		// for files belonging to the same user, order them chronologically
		if (ParserFileComparator.getUserName(one).equals(
				ParserFileComparator.getUserName(two)))
			return ParserFileComparator.getUserNum(one).compareTo(
					ParserFileComparator.getUserNum(two));
		// if files belong to different users, simply order them alphabetically
		// by user name
		return ParserFileComparator.getUserName(one).compareTo(
				ParserFileComparator.getUserName(two));
	}

	public static String getUserName(File file) {
		String name = file.getName();
		String res = name;
		if (name.indexOf("_") > 0) {
			res = name.substring(0, name.lastIndexOf("_"));
			if (name.indexOf("_") == name.lastIndexOf("_"))
				res = name.substring(name.lastIndexOf("_"), name.length());
		}
		return res;
	}

	public static Integer getUserNum(File file) {
		String name = file.getName();
		return new Integer(name.substring(name.lastIndexOf("_") + 1));
	}
}
