package edu.harvard.seas.iis.abilities.analysis;

import java.io.File;
import java.util.Collection;
import java.util.Vector;

import edu.harvard.seas.iis.abilities.classify.MovementClassifier;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;
import edu.harvard.seas.iis.util.stats.BasicStats;

/**
 * A set of tools that allow you to visualize properties of an "average"
 * movement
 * 
 * @author kgajos
 * 
 */
public class MovementAverage {

	protected double[] averagedSpeed, averagedAcceleration, averagedJerk;
	// standard errors for each sample
	protected double[] speedStderr, accelerationStderr, jerkStderr;
	protected int numMovements;

	public void computeAverages(Collection<Movement> movements,
			int samplesPerMovement) {
		averagedSpeed = new double[samplesPerMovement];
		averagedAcceleration = new double[samplesPerMovement];
		averagedJerk = new double[samplesPerMovement];
		numMovements = movements.size();

		double samplingInterval;
		for (Movement m : movements) {
			samplingInterval = (m.resampledAndFilteredMovementPoints
					.lastElement().relativeT)
					/ (samplesPerMovement - 1.5);
			double curT;
			for (int n = 0; n < samplesPerMovement; n++) {
				curT = m.resampledAndFilteredMovementPoints.firstElement()
						.getT()
						+ n * samplingInterval;
				averagedSpeed[n] += m.getSpeedAtTime(curT);
				averagedAcceleration[n] += m.getAccelerationAtTime(curT);
				averagedJerk[n] += m.getJerkAtTime(curT);
			}
		}
		for (int i = 0; i < averagedSpeed.length; i++) {
			averagedSpeed[i] /= numMovements;
			averagedAcceleration[i] /= numMovements;
			averagedJerk[i] /= numMovements;
		}
	}

	public void computeAveragesAndBounds(Collection<Movement> movements,
			int samplesPerMovement) {
		averagedSpeed = new double[samplesPerMovement];
		averagedAcceleration = new double[samplesPerMovement];
		averagedJerk = new double[samplesPerMovement];

		speedStderr = new double[samplesPerMovement];
		accelerationStderr = new double[samplesPerMovement];
		jerkStderr = new double[samplesPerMovement];

		numMovements = movements.size();

		double[][] speedData = new double[samplesPerMovement][numMovements];
		double[][] accelerationData = new double[samplesPerMovement][numMovements];
		double[][] jerkData = new double[samplesPerMovement][numMovements];

		double samplingInterval;
		int cnt = 0;
		for (Movement m : movements) {
			samplingInterval = (m.resampledAndFilteredMovementPoints
					.lastElement().relativeT)
					/ (samplesPerMovement - 1.5);
			double curT;
			for (int n = 0; n < samplesPerMovement; n++) {
				curT = m.resampledAndFilteredMovementPoints.firstElement()
						.getT()
						+ n * samplingInterval;
				speedData[n][cnt] = m.getSpeedAtTime(curT);
				accelerationData[n][cnt] = m.getAccelerationAtTime(curT);
				jerkData[n][cnt] = m.getJerkAtTime(curT);
			}
			cnt++;
		}
		for (int i = 0; i < averagedSpeed.length; i++) {
			averagedSpeed[i] = BasicStats.getMean(speedData[i]);
			averagedAcceleration[i] = BasicStats.getMean(accelerationData[i]);
			averagedJerk[i] = BasicStats.getMean(jerkData[i]);

			speedStderr[i] = Math.sqrt(BasicStats.getVariance(speedData[i])
					/ numMovements);
			accelerationStderr[i] = Math.sqrt(BasicStats
					.getVariance(accelerationData[i])
					/ numMovements);
			jerkStderr[i] = Math.sqrt(BasicStats.getVariance(jerkData[i])
					/ numMovements);
		}
	}

	public String classifyAndComputeAverages(Collection<Movement> movements,
			MovementFilter filter, int samplesPerMovement) throws Exception {
		MovementClassifier classify = new MovementClassifier();
		Vector<Movement> deliberate = new Vector<Movement>();
		Vector<Movement> distracted = new Vector<Movement>();
		classify.classifyMovements(movements, deliberate, distracted, true);

		movements = filter.filter(movements);
		deliberate = filter.filter(deliberate);
		distracted = filter.filter(distracted);

		String res = "";
		computeAveragesAndBounds(movements, samplesPerMovement);
		res += getReportWithBounds("all movements");
		computeAverages(deliberate, samplesPerMovement);
		res += getReportWithBounds("deliberate movements");
		computeAverages(distracted, samplesPerMovement);
		res += getReportWithBounds("distracted movements");

		return res;
	}

	public double[] getAveragedSpeed() {
		return averagedSpeed;
	}

	public double[] getAveragedAcceleration() {
		return averagedAcceleration;
	}

	public double[] getAveragedJerk() {
		return averagedJerk;
	}

	public void test() throws Exception {
		System.out.println("Indicate raw data files");
		File[] files = FileManipulation
				.getUserSpecifiedFilesForReading(new File(
						"/Users/kgajos/Documents/projects/abilities/dataDir/"));
		Vector<Movement> movements = (new IISMouseLogParser()).parseMovementLog(files);
		System.out.println("We ahave " + movements.size() + " movements");

		MovementFilter filter = new MovementFilter() {

			@Override
			public boolean evaluateMovement(Movement m) {
				boolean res = true;
//				res = res && m.indexOfDifficulty >= 3
//						&& m.indexOfDifficulty <= 5;
//				 res = res && "btn-next".equals(m.targetType);
				 res = res && "targ-ok".equals(m.targetType);
				return res;
			}
		};

		String res = classifyAndComputeAverages(movements, filter, 200);

		System.out.println(res);
	}

	public String toString() {
		String res = "Averaged over " + numMovements;
		return res;
	}

	public String getReport(String prefix) {
		String res = prefix + ": Averaged over " + numMovements + "\n";
		res += prefix + ": Velocity\t"
				+ PrettyPrint.toPrettyLine(averagedSpeed, "\t") + "\n";
		res += prefix + ": Acceleration\t"
				+ PrettyPrint.toPrettyLine(averagedAcceleration, "\t") + "\n";
		res += prefix + ": Jerk\t"
				+ PrettyPrint.toPrettyLine(averagedJerk, "\t") + "\n";
		return res;
	}

	public String getReportWithBounds(String prefix) {
		String res = prefix + ": Averaged over " + numMovements + "\n";
		res += prefix + ": Velocity\t"
				+ PrettyPrint.toPrettyLine(averagedSpeed, "\t") + "\n";
		res += prefix + ": Velocity stderr\t"
				+ PrettyPrint.toPrettyLine(speedStderr, "\t") + "\n";
		res += prefix + ": Acceleration\t"
				+ PrettyPrint.toPrettyLine(averagedAcceleration, "\t") + "\n";
		res += prefix + ": Acceleration stderr\t"
				+ PrettyPrint.toPrettyLine(accelerationStderr, "\t") + "\n";
		res += prefix + ": Jerk\t"
				+ PrettyPrint.toPrettyLine(averagedJerk, "\t") + "\n";
		res += prefix + ": Jerk stderr\t"
				+ PrettyPrint.toPrettyLine(jerkStderr, "\t") + "\n";
		return res;
	}

	public static void main(String[] args) throws Exception {
		MovementAverage ma = new MovementAverage();
		ma.test();
	}

}
