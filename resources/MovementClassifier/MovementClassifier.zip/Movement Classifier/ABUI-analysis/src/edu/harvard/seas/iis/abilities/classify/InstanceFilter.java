package edu.harvard.seas.iis.abilities.classify;

import weka.core.Instance;
import weka.core.Instances;

/**
 * Can be used to obtain a subset of instances that meet specific criteria
 * 
 * @author kgajos
 * 
 */
public abstract class InstanceFilter {

	/**
	 * The method for subclasses to implement
	 * 
	 * @return true if the instance should be kept, false otherwise
	 */
	public abstract boolean evaluateInstance(Instance instance,
			Instances theCompleteDataSet);

	/**
	 * Returns a new set of Instances that only contain a subset of the data
	 * that meet the criteria specified in the evaluateInstance() method
	 * 
	 * @param data
	 * @return
	 */
	public Instances filter(Instances data) {
		Instances res = new Instances(data);
		for (int i = res.numInstances() - 1; i >= 0; i--)
			if (!evaluateInstance(res.instance(i), res))
				res.delete(i);
		return res;
	}

}
