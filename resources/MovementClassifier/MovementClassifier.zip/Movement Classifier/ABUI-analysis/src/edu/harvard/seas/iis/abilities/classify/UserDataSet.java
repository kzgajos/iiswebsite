package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import edu.harvard.seas.iis.abilities.analysis.IISMouseLogParser;
import edu.harvard.seas.iis.abilities.analysis.Movement;
import edu.harvard.seas.iis.util.io.FileManipulation;

public class UserDataSet extends DataSet {

	private static FastVector attributes;

	public UserDataSet(int suspectedCapacity) {
		super("UserDataSet" + suspectedCapacity, ensureAttributes(),
				suspectedCapacity);
		setClass(attribute("Class"));
	}

	public UserDataSet(Instances data) {
		super(data);
		ensureAttributes();
		for (int i = 0; i < data.numAttributes(); i++)
			assert data.attribute(i).equals(attributes.elementAt(i));
		setClass(attribute("Class"));
	}

	public void addUser(String user, File[] implicit, File[] explicit)
			throws IOException {
		addFiles(implicit, "implicit", user);
		addFiles(explicit, "explicit", user);
	}

	/**
	 * Adds a movement to the data set
	 * 
	 * @param mov
	 * @param label
	 *            "implicit" for natural data, "explicit" for experimental data
	 * @param user
	 * @return
	 */
	public boolean addMovement(Movement mov, String label, String user) {
		try {
			Instance inst = movementToInstance(mov, label, user);
			if (inst != null) {
				add(inst);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public void addFiles(File[] files, String label, String user)
			throws IOException {
		Vector<Movement> rawMovements = (new IISMouseLogParser())
				.parseMovementLog(files);
		for (Movement mov : rawMovements)
			addMovement(mov, label, user);
	}

	/**
	 * adds data from files; all data are assumed to come from a single user;
	 * movement instances matching the filter will be marked as being positive
	 * examples of deliberate movements
	 * 
	 * @param files
	 * @param deliberateDataFilter
	 * @param user
	 * @throws IOException
	 */
	public void addFiles(File[] files, InstanceFilter deliberateDataFilter,
			String user) throws IOException {
		addFiles(files, "implicit", user);
		setValue(attribute("Class"), "explicit", deliberateDataFilter);
	}

	private static FastVector ensureAttributes() {
		if (attributes != null)
			return attributes;

		// initialize the User attribute as a string attribute
		Attribute userAttribute = new Attribute("User", (FastVector) null);
		attributes = new FastVector();
		attributes
				.appendElements((FastVector) initializeMovementSpecificAttributes());
		attributes.insertElementAt(userAttribute, attributes.size() - 1);

		return attributes;
	}

	private static FastVector initializeMovementSpecificAttributes() {
		FastVector classType = new FastVector();
		classType.addElement("implicit");
		classType.addElement("explicit");

		attributes = new FastVector();

		// a hack for extracting all information the Movement class is currently
		// able to report about a movement
		for (String att : Movement.getSummaryHeadingsNew())
			// "Target type" will be a free text attribute
			if ("Target type".equals(att))
				attributes.addElement(new Attribute(att, (FastVector) null));
			else
				// all others are numeric attributes
				attributes.addElement(new Attribute(att));
		attributes.addElement(new Attribute("Class", classType));

		return attributes;
	}

	protected Instance movementToInstance(Movement mov, String classLabel,
			String user) {
		ensureAttributes();
		Instance res = new Instance(attributes.size());
		res.setDataset(this);
		String[] attributeNames = Movement.getSummaryHeadingsNew();
		Hashtable<String, Object> featureValues = mov.getMovementFeatures();
		for (String attrName : attributeNames) {
			Attribute attr = attribute(attrName);
			Object val = featureValues.get(attrName);
			// ignore movements with infinities or other parsing problems
			if (ignoreMovement(attr, val.toString()))
				return null;
			if (attr.isNumeric())
				res.setValue(attr, ((Number) val).doubleValue());
			else
				res.setValue(attr, val.toString());
		}

		res.setValue(attribute("User"), user);
		res.setValue(attribute("Class"), classLabel);

		return res;
	}

	private static boolean ignoreMovement(Attribute att, String val) {
		boolean infty = (val.replace(" ", "").toString().indexOf("Infinity") >= 0 || val
				.replace(" ", "").toString().equals("NaN"));

		return infty;
	}

	/**
	 * Gets movement data from raw log files; assumes that examples of
	 * deliberate movements are in one directory and natural data are in another
	 * 
	 * @param explicitDataDir
	 * @param naturalDataDir
	 * @param parsedDataDir
	 * @param users
	 */
	public static void parseRawData(File explicitDataDir, File naturalDataDir,
			File parsedDataDir, String[] users) {
		for (String user : users) {
			System.out.println("Working on user \"" + user + "\"");
			// find implicit and explicit files containing that user name
			File explicitDataFile = null;
			for (File f : explicitDataDir.listFiles())
				if (f.getName().endsWith("data_" + user))
					explicitDataFile = f;
			Vector<File> implicitDataFiles = new Vector<File>();
			for (File f : naturalDataDir.listFiles())
				if (f.getName().indexOf("data_" + user + "_") >= 0)
					implicitDataFiles.add(f);
			System.out.println("  Found " + implicitDataFiles.size()
					+ " implicit data files");
			// create a data set
			UserDataSet curDataSet = new UserDataSet(1000);
			try {
				curDataSet.addUser(user, implicitDataFiles
						.toArray(new File[] {}),
						new File[] { explicitDataFile });
			} catch (IOException e) {
				System.err.println("Failed to load data for user " + user);
				e.printStackTrace();
			}

			// save the parsed data
			if (curDataSet.numInstances() > 0) {
				String outputFile = parsedDataDir.getAbsolutePath()
						+ File.separator + user;
				System.out.println("Saving to \"" + outputFile + "\"");
				try {
					curDataSet.saveAsCSV(outputFile + ".csv");
					curDataSet.saveAsARFF(outputFile + ".arff");
				} catch (IOException e) {
					System.err.println("Trouble saving " + outputFile);
					e.printStackTrace();
				}
			}
		}
	}

	public static void parseRawData(File dataDir, File parsedDataDir,
			InstanceFilter experimentalDataFilter) throws IOException {
		File[] dataFiles = dataDir.listFiles();
		// create a data set
		for (File f : dataFiles) {
			if (f.isDirectory())
				continue;
			String user = f.getName();
			System.out.println("Working on file " + f);
			UserDataSet curDataSet = new UserDataSet(1000);
			curDataSet.addFiles(new File[] { f }, experimentalDataFilter, user);
			System.out.println("Found " + curDataSet.getNumExplicitInstances()
					+ " explicit instances and "
					+ curDataSet.getNumImplicitInstances()
					+ " implicit instances");
			// save the parsed data
			String outputFile = parsedDataDir.getAbsolutePath()
					+ File.separator + user;
			System.out.println("Saving to \"" + outputFile + "\"");
			try {
				curDataSet.saveAsBothARFFandCSV(outputFile);
			} catch (IOException e) {
				System.err.println("Trouble saving " + outputFile);
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		File explicitDataDir = new File(Settings.EXPLICIT_DATA_DIRECTORY);
		if (!explicitDataDir.exists()) {
			System.out.println("Select the directory with explicit data");
			explicitDataDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		File implicitDataDir = new File(Settings.NATURAL_DATA_DIRECTORY);
		if (!implicitDataDir.exists()) {
			System.out.println("Select the directory with implicit data");
			implicitDataDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		File outputDir = new File(Settings.PARSED_DATA_DIRECTORY);
		if (!outputDir.exists()) {
			System.out
					.println("Select the directory for saving processed data");
			outputDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		parseRawData(explicitDataDir, implicitDataDir, outputDir,
				Settings.ALL_USER_NAMES);

	}
}
