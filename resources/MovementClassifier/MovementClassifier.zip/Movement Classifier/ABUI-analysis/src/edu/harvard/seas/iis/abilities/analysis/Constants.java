package edu.harvard.seas.iis.abilities.analysis;

public class Constants {

	// separator between columns in the stats reports
	protected static final String SEPARATOR = ",";

	// sampling interval in ms (10ms = 100Hz)
	public static final double SAMPLING_INTERVAL = 10;

	// amount of time (in ms) that must pass between successive mouse events for
	// us to conclude that we have a beginning of a new movement -- this is used
	// to assume that what follows is a separate movement
	public static long MOVEMENT_SEPARATOR_DURATION = 1000;

	// amount of time (in ms) that must pass between successive mouse events for
	// us to conclude that we have a beginning of a new submovement -- this is
	// used to resume accepting movements after a break
	public static long SUBMOVEMENT_SEPARATOR_DURATION = 250;

	// the longest acceptable movement duration --- longer movements will be
	// ignored
	public static long LONGEST_ACCEPTABLE_MOVEMENT = 10000;

}
