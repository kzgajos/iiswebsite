package edu.harvard.seas.iis.abilities.analysis;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

public interface Parser {

	public abstract Vector<Movement> parseMovementLog(LogSource source)
			throws IOException;

	public abstract Vector<Movement> parseMovementLog(File[] files)
			throws IOException;

	public abstract Vector<Movement> parseMovementLog(String log)
			throws IOException;
}