package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.SelectedTag;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Add;
import edu.harvard.seas.iis.util.collections.ArrayUtils;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * This class contains the tool chain for transforming raw parsed data into
 * something that is usable for ML (computing additional features, normalizing,
 * etc)
 * 
 * @author kgajos
 * @author Charles Herrmann
 * 
 */
public class Transform {

	public static String[] FEATURES_TO_DIVIDE_BY_ID = new String[] {
			"Movement Time", "S-TLastPeak", "A-TLastPeak", "J-TLastPeak" };
	public static String[] FEATURES_TO_DIVIDE_BY_A = new String[] {
			"Movement Time", "S-MaxVal", "A-MaxVal", "A-MinVal", "J-MaxVal",
			"J-MinVal", "fAverageAbsoluteJerk" };
	public static String[] FEATURES_TO_DIVIDE_BY_logA = new String[] {
			"Movement Time", "S-MaxVal", "A-MaxVal", "A-MinVal", "J-MaxVal",
			"J-MinVal", "fAverageAbsoluteJerk" };
	public static String[] FEATURES_TO_DIVIDE_BY_W = new String[] {};
	public static String[] FEATURES_TO_ADD_FOR_LATER_USE = new String[] {
			"Predicted class", "Prediction probability" };
	// these are the features whose original values we want to keep around (for
	// analyses and such)
	public static String[] FEATURES_TO_PRESERVE_DURING_NORMALIZATION = new String[] {
			"Movement Time divided by ID",
			"Fraction of distance to target covered in the first submovement" };
	public static String[] FEATURES_TO_LOG_TRANSFORM = new String[] { "Movement Time divided by ID" };

	/**
	 * Translates study code (e.g., "lemur") into a participant code that can be
	 * used in the paper (e.g., "P13")
	 * 
	 * @param user
	 * @return
	 */
	public static String getParticipantCode(String user) {
		int index = ArrayUtils.search(Settings.ALL_USER_NAMES, user);
		String newParticipantCode = "P" + ((index < 10) ? "0" : "") + index;
		return newParticipantCode;
	}

	public static DataSet computeAdditonalFeatures(DataSet dataSet)
			throws Exception {
		Attribute attrID = dataSet.attribute("ID");
		Attribute attrA = dataSet.attribute("A");

		for (String attrName : FEATURES_TO_DIVIDE_BY_ID) {
			Attribute curAttr = dataSet.attribute(attrName);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = curAttr.name() + " divided by ID";
			filter.setAttributeName(newName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
			Attribute newAttr = dataSet.attribute(newName);

			for (int i = 0; i < dataSet.numInstances(); i++) {
				Instance curInstance = dataSet.instance(i);
				double val = curInstance.value(curAttr)
						/ curInstance.value(attrID);
				curInstance.setValue(newAttr, val);
			}
		}

		for (String attrName : FEATURES_TO_DIVIDE_BY_A) {
			Attribute curAttr = dataSet.attribute(attrName);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = curAttr.name() + " divided by A";
			filter.setAttributeName(newName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
			Attribute newAttr = dataSet.attribute(newName);

			for (int i = 0; i < dataSet.numInstances(); i++) {
				Instance curInstance = dataSet.instance(i);
				double val = curInstance.value(curAttr)
						/ curInstance.value(attrA);
				curInstance.setValue(newAttr, val);
			}
		}

		for (String attrName : FEATURES_TO_DIVIDE_BY_logA) {
			Attribute curAttr = dataSet.attribute(attrName);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = curAttr.name() + " divided by log A";
			filter.setAttributeName(newName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
			Attribute newAttr = dataSet.attribute(newName);

			for (int i = 0; i < dataSet.numInstances(); i++) {
				Instance curInstance = dataSet.instance(i);
				double val = curInstance.value(curAttr)
						/ Math.log(curInstance.value(attrA));
				curInstance.setValue(newAttr, val);
			}
		}

		// add columns that will come in handy for capturing the output of the
		// classifier
		for (String attrName : FEATURES_TO_ADD_FOR_LATER_USE) {
			Add filter = new Add();
			filter.setAttributeIndex("last");
			filter.setAttributeName(attrName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
		}

		for (String attrName : FEATURES_TO_LOG_TRANSFORM) {
			Attribute curAttr = dataSet.attribute(attrName);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = "log " + curAttr.name();
			filter.setAttributeName(newName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
			Attribute newAttr = dataSet.attribute(newName);

			for (int i = 0; i < dataSet.numInstances(); i++) {
				Instance curInstance = dataSet.instance(i);
				double val = Math.log(curInstance.value(curAttr));
				curInstance.setValue(newAttr, val);
			}
		}

		// set up features for the original values for some of the features so
		// that we have access to them even after values of all the features
		// have been normalized
		for (String attrName : FEATURES_TO_PRESERVE_DURING_NORMALIZATION) {
			Attribute curAttr = dataSet.attribute(attrName);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = curAttr.name() + "-original";
			filter.setAttributeName(newName);
			filter.setInputFormat(dataSet);
			dataSet = new DataSet(Filter.useFilter(dataSet, filter));
			Attribute newAttr = dataSet.attribute(newName);

			for (int i = 0; i < dataSet.numInstances(); i++) {
				Instance curInstance = dataSet.instance(i);
				double val = curInstance.value(curAttr);
				curInstance.setValue(newAttr, val);
			}
		}

		return dataSet;
	}

	public static DataSet computeParticipantCodes(DataSet dataSet)
			throws Exception {
		// give participants new codes that we can actually use in the paper
		Attribute curAttr = dataSet.attribute("User");
		String alternativeParticipantCodes = "";
		for (int i = 0; i < Settings.ALL_USER_NAMES.length; i++)
			alternativeParticipantCodes += ((i > 0) ? "," : "") + "P"
					+ ((i < 10) ? "0" : "") + i;
		Add filter = new Add();
		filter.setAttributeIndex("last");
		String newName = "Alternative participant code";
		filter.setAttributeName(newName);
		// make it a nominal attribute
		filter.setAttributeType(new SelectedTag(1, Add.TAGS_TYPE));
		filter.setNominalLabels(alternativeParticipantCodes);
		filter.setInputFormat(dataSet);
		dataSet = new DataSet(Filter.useFilter(dataSet, filter));
		Attribute newAttr = dataSet.attribute(newName);

		for (int i = 0; i < dataSet.numInstances(); i++) {
			Instance curInstance = dataSet.instance(i);
			String user = curInstance.stringValue(curAttr);
			curInstance.setValue(newAttr, getParticipantCode(user));
		}
		return dataSet;
	}

	public static void computeAdditonalFeatures(File inputDirectory,
			File outputDirectory) throws Exception {

		for (String user : Settings.ALL_USER_NAMES) {
			System.out.println("Processing data for user " + user);
			try {
				File f = new File(inputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				dataSet = computeAdditonalFeatures(dataSet);
				dataSet = computeParticipantCodes(dataSet);

				dataSet.saveAsCSV(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".csv");
				dataSet.saveAsARFF(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");

			} catch (IOException e) {
				System.err.println("Trouble processing file for " + user);
				e.printStackTrace();
			}
		}
	}

	/**
	 * Combine data sets for several users into a single file
	 * 
	 * @param inputDirectory
	 * @param userNames
	 * @param outputFile
	 *            where the combined data should be saved (if set to null, the
	 *            combined data set does not get saved to a file)
	 * @throws IOException
	 */
	public static DataSet combineDataSets(File inputDirectory,
			String[] userNames, File outputFile) throws IOException {
		Vector<File> files = new Vector<File>();
		for (String user : userNames) {
			File f = new File(inputDirectory.getAbsolutePath() + File.separator
					+ user + ".arff");
			if (f.exists())
				files.add(f);
			else
				System.err.println("Cannot find " + f);
		}
		DataSet combinedDataSet = DataSet.fromArffFiles(files
				.toArray(new File[] {}));
		if (outputFile != null) {
			combinedDataSet.saveAsCSV(outputFile + ".csv");
			combinedDataSet.saveAsARFF(outputFile + ".arff");
		}

		return combinedDataSet;
	}

	/**
	 * Normalize the data such that values for each feature in each file have a
	 * zero mean and a unit stdev (actually, we currently normalize by the
	 * natural data --- see DataSetTransform.normalize() for more)
	 * 
	 * @param inputDirectory
	 * @param outputDirectory
	 * @param featuresToNormalize
	 * @param usersToInclude
	 * @throws Exception
	 */
	public static void normalize(File inputDirectory, File outputDirectory,
			String[] featuresToNormalize, String[] usersToInclude)
			throws Exception {

		for (String user : usersToInclude) {
			System.out.println("Processing data for user " + user);
			try {
				File f = new File(inputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");
				DataSet dataSet = UserDataSet.fromArffFile(f);
				dataSet = Transform.normalize(dataSet, featuresToNormalize,
						null, null);

				dataSet.saveAsCSV(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".csv");
				dataSet.saveAsARFF(outputDirectory.getAbsolutePath()
						+ File.separator + user + ".arff");

			} catch (IOException e) {
				System.err.println("Trouble processing file for " + user);
				e.printStackTrace();
			}
		}
	}

	public static NormalizationConstants createGloballyNormalizedFile(
			File cleanDataDir, File normalizedDataDir, String[] usersToInclude,
			String[] usersToUseForComputingNormalizationConstants,
			String globallyNormalizedCombinedDataFileName,
			String[] featuresToNormalize) throws IOException {

		DataSet dataSet = combineDataSets(cleanDataDir, usersToInclude, null);

		NormalizationConstants constants = new NormalizationConstants();
		dataSet = Transform.normalize(dataSet, featuresToNormalize,
				usersToUseForComputingNormalizationConstants, constants);

		dataSet.saveAsCSV(globallyNormalizedCombinedDataFileName + ".csv");
		dataSet.saveAsARFF(globallyNormalizedCombinedDataFileName + ".arff");

		return constants;
	}

	/**
	 * Combines features from two files
	 * 
	 * @param globalFile
	 * @param individualFile
	 * @param featuresToCombine
	 * @param resultFileName
	 * @throws Exception
	 */
	public static void combineGloballyAndIndividuallyNormalizedData(
			File globalFile, File individualFile, String[] featuresToCombine,
			String[] usersToInclude, String resultFileName) throws Exception {
		DataSet global = UserDataSet.fromArffFile(globalFile);
		// limit the entries just to the users we are interested in
		global = global.getInstancesWithAttributeValues(global
				.attribute("User"), ArrayUtils.asArrayList(usersToInclude));
		DataSet individual = UserDataSet.fromArffFile(individualFile);

		for (String feature : featuresToCombine) {
			Attribute curAttr = global.attribute(feature);
			Add filter = new Add();
			filter.setAttributeIndex("last");
			String newName = curAttr.name() + "-individual";
			filter.setAttributeName(newName);
			filter.setInputFormat(global);
			global = new DataSet(Filter.useFilter(global, filter));
			Attribute newAttr = global.attribute(newName);

			for (int i = 0; i < global.numInstances(); i++) {
				Instance globalInstance = global.instance(i);
				Instance individualInstance = individual.instance(i);
				globalInstance.setValue(newAttr, individualInstance
						.value(curAttr));
			}
		}
		global.saveAsCSV(resultFileName + ".csv");
		global.saveAsARFF(resultFileName + ".arff");

	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		File parsedDataDir = new File(Settings.PARSED_DATA_DIRECTORY);
		if (!parsedDataDir.exists()) {
			System.out
					.println("Select the directory for reading parsed raw data");
			parsedDataDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		File transformedDataDir = new File(Settings.TRANSFORMED_DATA_DIRECTORY);
		if (!transformedDataDir.exists()) {
			System.out
					.println("Select the directory for reading/saving transformed data");
			transformedDataDir = FileManipulation
					.getUserSpecifiedDirForReading();
		}

		File cleanDataDir = new File(Settings.CLEAN_DATA_DIRECTORY);
		if (!cleanDataDir.exists()) {
			System.out.println("Select the directory for saving clean data");
			cleanDataDir = FileManipulation.getUserSpecifiedDirForReading();
		}

		File normalizedDataDir = new File(Settings.NORMALIZED_DATA_DIRECTORY);
		if (!normalizedDataDir.exists()) {
			System.out
					.println("Select the directory for saving normalized data");
			normalizedDataDir = FileManipulation
					.getUserSpecifiedDirForReading();
		}

		// filter out outliers from explicit data
		Clean.clean(parsedDataDir, cleanDataDir, Clean.CLEAN1);

		// compute the extra features
		computeAdditonalFeatures(parsedDataDir, transformedDataDir);

		// filter out outliers from explicit data
		Clean.clean(transformedDataDir, cleanDataDir, Clean.CLEAN2);

		// perform per-user normalization
		normalize(cleanDataDir, normalizedDataDir,
				Settings.FEATURES_TO_NORMALIZE,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA);

		// combine per-user normalized data into a single file
		combineDataSets(normalizedDataDir,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
				new File(normalizedDataDir.getAbsolutePath()
						+ "/allUsersWithGoodImplicitAndExplicitData"));

		// combine all clean data into a single file
		combineDataSets(cleanDataDir,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
				new File(cleanDataDir.getAbsolutePath()
						+ "/allUsersWithGoodImplicitAndExplicitData"));

		// create a single file with globally normalized data
		// createGloballyNormalizedFile(cleanDataDir, normalizedDataDir,
		// Settings.FEATURES_TO_NORMALIZE);

		// create a single file with both globally and individually normalized
		// features
		combineGloballyAndIndividuallyNormalizedData(
				new File(
						normalizedDataDir.getAbsolutePath()
								+ "/allUsersWithGoodImplicitAndExplicitData-globallyNormalized.arff"),
				new File(normalizedDataDir.getAbsolutePath()
						+ "/allUsersWithGoodImplicitAndExplicitData.arff"),
				Settings.ALLOWED_FEATURES,
				Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
				"/Users/kgajos/Documents/projects/abilities/normalized data/allUsersWithGoodImplicitAndExplicitData-mixed");
		System.exit(0);

	}

	/**
	 * Normalizes listed features (zero mean and unit stdev); unlike the other
	 * normalize() method, it does not attempt to separate the users -- if you
	 * want normalization per user, feed it separate data sets for each user
	 * 
	 * @param oldData
	 * @param attributesToNormalize
	 * @param usersToUseForComputingNormalizationConstants
	 *            will only use data from these users to compute normalization
	 *            constants; if set to null, will use all users represented in
	 *            the data set
	 * @param normalizationConstants
	 *            the contents of this object will be updated with the constants
	 *            computed during the run of this method
	 * @return
	 * @throws IOException
	 */
	public static DataSet normalize(DataSet oldData,
			String[] attributesToNormalize,
			String[] usersToUseForComputingNormalizationConstants,
			NormalizationConstants normalizationConstants) throws IOException {
		DataSet newData = new UserDataSet(oldData);
		// normalization constants are computed on natural data
		DataSet implicit = oldData.getImplicitInstances();
		// and only for a subset of the users
		if (usersToUseForComputingNormalizationConstants != null)
			implicit = implicit.getInstancesWithAttributeValues(implicit
					.attribute("User"), ArrayUtils
					.asArrayList(usersToUseForComputingNormalizationConstants));

		for (String attributeName : attributesToNormalize) {
			int attIndex = oldData.attribute(attributeName).index();
			double mean = implicit.meanOrMode(attIndex);
			double var = implicit.variance(attIndex);
			if (normalizationConstants != null)
				normalizationConstants.setConstantsForAttribute(attributeName,
						mean, var);
			normalizeAttribute(newData, attIndex, mean, var);
		}
		return newData;
	}

	public static void normalizeAttribute(DataSet data, int attIndex,
			double mean, double var) {
		double result = 0;
		for (int i = 0; i < data.numInstances(); i++) {
			Instance inst = data.instance(i);
			result = 0;
			if (var != 0) {
				result = (inst.value(attIndex) - mean) / Math.sqrt(var);
			}
			data.instance(i).setValue(attIndex, result);
		}
	}

	/**
	 * This method uses the constants provided in the normalizationConstants to
	 * perform the normalization
	 * 
	 * @param dataSet
	 * @param attributesToNormalize
	 * @param normalizationConstants
	 * @return
	 */
	public static DataSet normalizeUsingNormalizationConstants(DataSet dataSet,
			String[] attributesToNormalize,
			NormalizationConstants normalizationConstants) {
		for (String attributeName : attributesToNormalize) {
			int attrIndex = dataSet.attribute(attributeName).index();
			normalizeAttribute(dataSet, attrIndex, normalizationConstants
					.getMean(attributeName), normalizationConstants
					.getVariance(attributeName));
		}
		return dataSet;
	}

}
