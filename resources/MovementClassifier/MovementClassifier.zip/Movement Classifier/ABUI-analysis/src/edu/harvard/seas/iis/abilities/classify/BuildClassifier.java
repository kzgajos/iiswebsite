package edu.harvard.seas.iis.abilities.classify;

import java.io.File;

import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;
import edu.harvard.seas.iis.util.Logger;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * @author kgajos
 * 
 *         This class contains a chain of tools to create a classifier starting
 *         with the raw data and ending with a trained classifier. By default,
 *         it also evaluates the trained classifiers and prints out a table with
 *         basic performance results for each. It does not include feature
 *         selection, though!
 */
public class BuildClassifier {

	/*
	 * These are the different stages of building the movement classifiers; by
	 * giving something other than PARSE as input to buildClassifier() method,
	 * you can skip some steps in the process (e.g., if your data is already
	 * parsed)
	 */
	public static int PARSE = 1; // parse raw log files to extract movements
	public static int CLEAN1 = 2; // throw away movements with unreasonably low
	// Indices of Difficulty or other obvious
	// problems
	public static int COMPUTE_FEATURES = 3; // compute additional features
	public static int CLEAN2 = 4; // remove outliers from experimental data
	public static int NORMALIZE = 5; // normalize values of features that may be
	// used in classification
	public static int TRAIN = 6; // train the classifiers

	protected File explicitDataDir;
	protected File naturalDataDir;
	protected File otherStudiesReliableDataDir;
	protected File otherStudiesUnreliableDataDir;
	protected File parsedDataDir;
	protected File transformedDataDir;
	protected File cleanDataDir;
	protected File normalizedDataDir;

	public BuildClassifier() {
		prepareFileHandles();
	}

	protected void prepareFileHandles() {
		File dataDir = new File(Settings.DATA_DIRECTORY);
		if (!dataDir.exists()) {
			System.out.println("Select the data directory");
			dataDir = FileManipulation.getUserSpecifiedDirForReading();
			Settings.DATA_DIRECTORY = dataDir.getAbsolutePath();
		}

		explicitDataDir = new File(Settings.EXPLICIT_DATA_DIRECTORY);
		naturalDataDir = new File(Settings.NATURAL_DATA_DIRECTORY);
		otherStudiesReliableDataDir = new File(
				Settings.OTHER_STUDIES_RELIABLE_DATA_DIRECTORY);
		otherStudiesUnreliableDataDir = new File(
				Settings.OTHER_STUDIES_UNRELIABLE_DATA_DIRECTORY);
		parsedDataDir = new File(Settings.PARSED_DATA_DIRECTORY);
		transformedDataDir = new File(Settings.TRANSFORMED_DATA_DIRECTORY);
		cleanDataDir = new File(Settings.CLEAN_DATA_DIRECTORY);
		normalizedDataDir = new File(Settings.NORMALIZED_DATA_DIRECTORY);
	}

	public PositiveAndUnlabeledClassifier[] buildClassifier(int startingStage,
			boolean evaluateClassifiers) throws Exception {
		// parse the raw data and store the results in the parsedDataDir
		if (startingStage <= PARSE) {
			System.out.println("** Parsing raw data **");

			// get data from our original data collection
			UserDataSet.parseRawData(explicitDataDir, naturalDataDir,
					parsedDataDir, Settings.ALL_USER_NAMES);
			// now add data from trustworthy (i.e., lab-based) participants from
			// the ephemeral menus study
			/*
			UserDataSet.parseRawData(otherStudiesReliableDataDir,
					parsedDataDir, new InstanceFilter() {
						public boolean evaluateInstance(Instance instance,
								Instances theCompleteDataSet) {
							return "btn-next".equals(instance
									.stringValue(theCompleteDataSet
											.attribute("Target type")));
						}
					});
					*/
			// now add data from unreliable (i.e., Turkers) participants from
			// the ephemeral menus study -- in this case we are building on the
			// self-training concept and using our current classifier to
			// identify the movements that should be included among the positive
			// examples; one should really iterate on this process until
			// convergence
			/*
			final MovementClassifier movementClassifier = new MovementClassifier();
			UserDataSet.parseRawData(otherStudiesUnreliableDataDir,
					parsedDataDir, new InstanceFilter() {
						public boolean evaluateInstance(Instance instance,
								Instances theCompleteDataSet) {
							boolean res = "btn-next".equals(instance
									.stringValue(theCompleteDataSet
											.attribute("Target type")));
							if (res)
								try {
									DataSet temp = new UserDataSet(1);
									temp.add(instance);
									temp = Transform
											.computeAdditonalFeatures(temp);
									temp = Transform
											.normalizeUsingNormalizationConstants(
													temp,
													Settings.FEATURES_TO_NORMALIZE,
													movementClassifier.normalizationConstants);
									res = movementClassifier
											.getDeliberateProbability(temp
													.firstInstance(), true) > .5;
								} catch (Exception e) {
									Logger.log("Trouble classifying "
											+ instance);
									res = false;
								}
							return res;
						}
					});
			 */
		}
		// remove instances that we cannot quite work with
		if (startingStage <= CLEAN1) {
			System.out
					.println("** Cleaning the data - removing useless data points **");

			// filter out outliers from explicit data
			Clean.clean(parsedDataDir, parsedDataDir, Clean.CLEAN1);
		}

		// compute the extra features
		if (startingStage <= COMPUTE_FEATURES) {
			System.out.println("** Computing additional features **");
			Transform.computeAdditonalFeatures(parsedDataDir,
					transformedDataDir);

			// combine all transformed data into a single file
			Transform.combineDataSets(transformedDataDir,
					Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
					new File(Settings.COMBINED_TRANSFORMED_DATA_FILE));
		}

		// remove instances that we cannot quite work with
		if (startingStage <= CLEAN2) {
			System.out.println("** Cleaning the data - removing outliers **");

			// filter out outliers from explicit data
			Clean.clean(transformedDataDir, cleanDataDir, Clean.CLEAN2);

			// combine all clean data into a single file
			Transform.combineDataSets(cleanDataDir,
					Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
					new File(Settings.COMBINED_CLEAN_DATA_FILE));
		}

		if (startingStage <= NORMALIZE) {
			System.out.println("** Normalizing data **");

			// perform per-user normalization
			Transform.normalize(cleanDataDir, normalizedDataDir,
					Settings.FEATURES_TO_NORMALIZE,
					Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA);

			// combine per-user normalized data into a single file
			Transform
					.combineDataSets(normalizedDataDir,
							// Settings.USERS_WITH_SUFFICIENT_IMPLICIT_AND_EXPLICIT_DATA,
							Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
							new File(
									Settings.INDIVIDUALLY_NORMALIZED_COMBINED_DATA_FILE));

			// create a single file with globally normalized data
			NormalizationConstants normalizationConstants = Transform
					.createGloballyNormalizedFile(cleanDataDir,
							normalizedDataDir,
							Settings.USERS_WITH_SOME_USEFUL_DATA,
							Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
							Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE,
							Settings.FEATURES_TO_NORMALIZE);

			// create a single file with both globally and individually
			// normalized features
			Transform.combineGloballyAndIndividuallyNormalizedData(new File(
					Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE + ".arff"),
					new File(
							Settings.INDIVIDUALLY_NORMALIZED_COMBINED_DATA_FILE
									+ ".arff"), Settings.ALLOWED_FEATURES,
					Settings.USERS_WITH_SUFFICIENT_IMPLICIT_DATA,
					Settings.MIXED_NORMALIZED_COMBINED_DATA_FILE);

			System.out.println("Saving the global normalization constants to "
					+ Settings.TRAINED_CLASSIFIER_DIRECTORY);
			FileManipulation.saveObjectToFile(normalizationConstants, new File(
					Settings.TRAINED_CLASSIFIER_DIRECTORY + File.separator
							+ "normalizationConstants"));
		}

		// now build the classifiers
		System.out.println("** Building classifiers **");

		// training data sets
		DataSet globallyNormalizedDataSet = UserDataSet.fromArffFile(new File(
				Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
		DataSet mixedNormalizedDataSet = UserDataSet.fromArffFile(new File(
				Settings.MIXED_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
		int numExplicitData = globallyNormalizedDataSet.getExplicitInstances()
				.numInstances();
		int numNaturalData = globallyNormalizedDataSet.getImplicitInstances()
				.numInstances();

		// the classifiers
		PositiveAndUnlabeledClassifier classifier1 = new PositiveAndUnlabeledClassifier(
				getBaseClassifier(), Settings.BEST_FEATURES_LOGISTIC_GLOBAL);
		PositiveAndUnlabeledClassifier classifier2 = new PositiveAndUnlabeledClassifier(
				getBaseClassifier(), Settings.BEST_FEATURES_LOGISTIC_MIXED);
		PositiveAndUnlabeledClassifier classifier3 = new PositiveAndUnlabeledClassifier(
				getBaseClassifier(),
				Settings.BEST_FEATURES_LOGISTIC_GLOBAL_TARGET_AGNOSTIC);
		PositiveAndUnlabeledClassifier classifier4 = new PositiveAndUnlabeledClassifier(
				getBaseClassifier(),
				Settings.BEST_FEATURES_LOGISTIC_MIXED_TARGET_AGNOSTIC);

		classifier1.buildClassifier(globallyNormalizedDataSet);
		classifier2.buildClassifier(mixedNormalizedDataSet);
		classifier3.buildClassifier(globallyNormalizedDataSet);
		classifier4.buildClassifier(mixedNormalizedDataSet);

		System.out.println("Saving the classifiers to "
				+ Settings.TRAINED_CLASSIFIER_DIRECTORY);
		FileManipulation.saveObjectToFile(classifier1, new File(
				Settings.TRAINED_CLASSIFIER_DIRECTORY + File.separator
						+ "c1.classifier"));
		FileManipulation.saveObjectToFile(classifier2, new File(
				Settings.TRAINED_CLASSIFIER_DIRECTORY + File.separator
						+ "c2.classifier"));
		FileManipulation.saveObjectToFile(classifier3, new File(
				Settings.TRAINED_CLASSIFIER_DIRECTORY + File.separator
						+ "c3.classifier"));
		FileManipulation.saveObjectToFile(classifier4, new File(
				Settings.TRAINED_CLASSIFIER_DIRECTORY + File.separator
						+ "c4.classifier"));

		// evaluate the classifiers (if requested)
		ClassifierEvalStats res1 = null;
		if (evaluateClassifiers) {
			System.out.println("** Evaluating classifiers **");
			PositiveAndUnlabeledClassifier classifier = new PositiveAndUnlabeledClassifier(
					getBaseClassifier());

			FeatureSelection fs = new FeatureSelection();

			DataSet dataSet = DataSet.fromArffFile(new File(
					Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
			res1 = fs.evaluateFeatureSet(
					Settings.BEST_FEATURES_LOGISTIC_GLOBAL, classifier,
					dataSet, true);
			dataSet
					.saveAsBothARFFandCSV(Settings.CLASSIFIED_DATA_DIRECTORY
							+ File.separator
							+ "allUsersWithGoodImplicitAndExplicitData-globallyNormalized-classified with C1");

			dataSet = DataSet.fromArffFile(new File(
					Settings.MIXED_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
			ClassifierEvalStats res2 = fs.evaluateFeatureSet(
					Settings.BEST_FEATURES_LOGISTIC_MIXED, classifier, dataSet,
					true);
			dataSet
					.saveAsBothARFFandCSV(Settings.CLASSIFIED_DATA_DIRECTORY
							+ File.separator
							+ "allUsersWithGoodImplicitAndExplicitData-mixed-classified with C2");

			dataSet = DataSet.fromArffFile(new File(
					Settings.GLOBALLY_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
			ClassifierEvalStats res3 = fs.evaluateFeatureSet(
					Settings.BEST_FEATURES_LOGISTIC_GLOBAL_TARGET_AGNOSTIC,
					classifier, dataSet, true);
			dataSet
					.saveAsBothARFFandCSV(Settings.CLASSIFIED_DATA_DIRECTORY
							+ File.separator
							+ "allUsersWithGoodImplicitAndExplicitData-globallyNormalized-classified with C3");

			dataSet = DataSet.fromArffFile(new File(
					Settings.MIXED_NORMALIZED_COMBINED_DATA_FILE + ".arff"));
			ClassifierEvalStats res4 = fs.evaluateFeatureSet(
					Settings.BEST_FEATURES_LOGISTIC_MIXED_TARGET_AGNOSTIC,
					classifier, dataSet, true);
			dataSet
					.saveAsBothARFFandCSV(Settings.CLASSIFIED_DATA_DIRECTORY
							+ File.separator
							+ "allUsersWithGoodImplicitAndExplicitData-mixed-classified with C4");

			System.out.println("\n\nclassifier\t" + res1.getHeader1());
			System.out.println("Natural data (unfiltered)\t"
					+ res1.getReport1ForNaturalData());
			System.out.println("Logistic, globally normalized\t"
					+ res1.getReport1());
			System.out
					.println("Logistic, globally and individually normalized\t"
							+ res2.getReport1());
			System.out
					.println("Logistic, globally normalized, target agnostic\t"
							+ res3.getReport1());
			System.out
					.println("Logistic, globally and individually normalized, target agnostic\t"
							+ res4.getReport1());
		}

		if (res1 != null)
			System.out
					.println("Mean per user Stdev of MT/ID in data from a formal experiment: "
							+ res1.explicitMTbyIDstdev);
		System.out.println("\nThere were a total of "
				+ (numExplicitData + numNaturalData) + " movements ("
				+ numExplicitData + " from a formal experiment and "
				+ numNaturalData + " from natural observations)");

		return new PositiveAndUnlabeledClassifier[] { classifier1, classifier2,
				classifier3, classifier4 };
	}

	/**
	 * The PositiveAndUnlabelledClassifier uses a traditional classifier under
	 * the hood. This method returns a classifier to put under the hood. It can
	 * be any classifier as long as it returns well-calibrated probabilities.
	 * Logistic is a perfect fit. Avoid NaiveBayes or SVM.
	 * 
	 * @return
	 */
	protected Classifier getBaseClassifier() {
		// the base classifier
		Classifier baseClassifier = null;
		try {
			baseClassifier = Classifier.forName(
					"weka.classifiers.functions.Logistic", new String[] { "-R",
							"1.0E-8", "-M", "-1" });
		} catch (Exception e) {
			e.printStackTrace();
		}
		return baseClassifier;
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		BuildClassifier bc = new BuildClassifier();
		bc.buildClassifier(PARSE, true);
	}

}
