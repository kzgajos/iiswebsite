package edu.harvard.seas.iis.abilities.classify;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Collection;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.Instance;
import edu.harvard.seas.iis.abilities.analysis.IISMouseLogParser;
import edu.harvard.seas.iis.abilities.analysis.Movement;
import edu.harvard.seas.iis.abilities.analysis.MovementFilter;
import edu.harvard.seas.iis.abilities.analysis.Parser;
import edu.harvard.seas.iis.util.Logger;
import edu.harvard.seas.iis.util.collections.PrettyPrint;
import edu.harvard.seas.iis.util.io.FileManipulation;

/**
 * A front end class with high level tools for classifying pointing movements as
 * deliberate or distracted; uses pre-trained classifiers to perform the
 * classification so it is all ready to go.
 * 
 * @author kgajos
 * 
 */
public class MovementClassifier {

	// keys for storing meta data with the Movement objects
	public static final String DELIBERATE_PROBABILITY_KEY = "deliberate probability";
	public static final String PREDICTED_CLASS_KEY = "predicted class";

	// classifiers
	protected PositiveAndUnlabeledClassifier c1, c2, c3, c4;
	protected NormalizationConstants normalizationConstants;

	public static final String REPORT_HEADER = "File name\ttotal number of movements\tdeliberate movements\tdistracted movements\tfraction of deliberate movements";

	/**
	 * Initializes the class and loads the default serialized versions of the
	 * classifiers from the following location in the classpath:
	 * edu/harvard/seas/iis/abilities/classify/resources/
	 */
	public MovementClassifier() {
		try {
			loadClassifiers(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initializes the class and loads serialized classifiers from the location
	 * indicated in classifierDirectory variable
	 * 
	 * @param classifierDirectory
	 *            the location where the serialized classifiers may be found
	 */
	public MovementClassifier(String classifierDirectory) {
		try {
			loadClassifiers(classifierDirectory);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Loads the serialized classifiers
	 * 
	 * @param classifierDirectory
	 *            if this variable is set, this is where the classifier will be
	 *            loaded from; if it is set to null or empty string, the default
	 *            versions of the classifier will be loaded from the following
	 *            path in the classpath:
	 *            edu/harvard/seas/iis/abilities/classify/resources/
	 * @throws IOException
	 */
	protected void loadClassifiers(String classifierDirectory)
			throws IOException {
		try {
			if (classifierDirectory == null
					|| "".equals(classifierDirectory.trim())) {
				// if the classifier directory is not specified, load the
				// versions included in the classpath
				c1 = (PositiveAndUnlabeledClassifier) (new ObjectInputStream(
						MovementClassifier.class
								.getClassLoader()
								.getResourceAsStream(
										"edu/harvard/seas/iis/abilities/classify/resources/c1.classifier")))
						.readObject();
				c2 = (PositiveAndUnlabeledClassifier) (new ObjectInputStream(
						MovementClassifier.class
								.getClassLoader()
								.getResourceAsStream(
										"edu/harvard/seas/iis/abilities/classify/resources/c2.classifier")))
						.readObject();
				c3 = (PositiveAndUnlabeledClassifier) (new ObjectInputStream(
						MovementClassifier.class
								.getClassLoader()
								.getResourceAsStream(
										"edu/harvard/seas/iis/abilities/classify/resources/c3.classifier")))
						.readObject();
				c4 = (PositiveAndUnlabeledClassifier) (new ObjectInputStream(
						MovementClassifier.class
								.getClassLoader()
								.getResourceAsStream(
										"edu/harvard/seas/iis/abilities/classify/resources/c4.classifier")))
						.readObject();
				normalizationConstants = (NormalizationConstants) (new ObjectInputStream(
						MovementClassifier.class
								.getClassLoader()
								.getResourceAsStream(
										"edu/harvard/seas/iis/abilities/classify/resources/normalizationConstants")))
						.readObject();
			} else {
				// if the location of the classifier directory is specified,
				// load them from there
				String curFile = "";
				curFile = classifierDirectory + File.separator
						+ "c1.classifier";
				c1 = PositiveAndUnlabeledClassifier
						.deserializeFromFile(new File(curFile));
				curFile = classifierDirectory + File.separator
						+ "c2.classifier";
				c2 = PositiveAndUnlabeledClassifier
						.deserializeFromFile(new File(curFile));
				curFile = classifierDirectory + File.separator
						+ "c3.classifier";
				c3 = PositiveAndUnlabeledClassifier
						.deserializeFromFile(new File(curFile));
				curFile = classifierDirectory + File.separator
						+ "c4.classifier";
				c4 = PositiveAndUnlabeledClassifier
						.deserializeFromFile(new File(curFile));
				curFile = classifierDirectory + File.separator
						+ "normalizationConstants";
				normalizationConstants = (NormalizationConstants) FileManipulation
						.readObjectFromFile(new File(curFile));
			}
		} catch (IOException e) {
			System.err.println("Problems deserializing the classifiers");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Takes movements and classifies them; classified movements are added to
	 * the deliberate and distracted vectors
	 * 
	 * @param movements
	 *            movement objects to be classified
	 * @param deliberate
	 *            movements classified as deliberate will be added to this
	 *            vector
	 * @param distracted
	 *            movements classified as distracted will be added to this
	 *            vector
	 * @param useTargetInformation
	 *            if set to true, the classifier will make use of features that
	 *            rely on the knowledge of the target size; if set to false, the
	 *            classification will be done in a target agnostic manner
	 * @throws Exception
	 */
	public void classifyMovements(Collection<Movement> movements,
			Vector<Movement> deliberate, Vector<Movement> distracted,
			boolean useTargetInformation) throws Exception {

		for (Movement m : movements) {
			if (getDeliberateProbability(m, useTargetInformation) >= .5)
				deliberate.add(m);
			else if (getDeliberateProbability(m, useTargetInformation) >= 0)
				distracted.add(m);
		}
	}

	/**
	 * Returns the probability that the movement was deliberate; also modifies
	 * the movement object by adding two pieces of meta data:
	 * "deliberate probability" and "predicted class"
	 * 
	 * @param movement
	 *            Movement to classify
	 * @param useTargetInformation
	 *            if set to true, the classifier will make use of features that
	 *            rely on the knowledge of the target size; if set to false, the
	 *            classification will be done in a target agnostic manner
	 * @return probability that the movement was deliberate or -1 if the
	 *         movement could not be classified
	 * @throws Exception
	 */
	public double getDeliberateProbability(Movement movement,
			boolean useTargetInformation) throws Exception {

		UserDataSet tempUserDataSet = new UserDataSet(1);
		tempUserDataSet.addMovement(movement, "implicit", "test");

		if (tempUserDataSet.numInstances() > 0) {
			DataSet tempDataSet = Transform
					.computeAdditonalFeatures(tempUserDataSet);
			tempDataSet = Transform.normalizeUsingNormalizationConstants(
					tempDataSet, Settings.FEATURES_TO_NORMALIZE,
					normalizationConstants);

			double res = getDeliberateProbability(tempDataSet.firstInstance(),
					useTargetInformation);

			movement.setAdditionalMetaData(DELIBERATE_PROBABILITY_KEY, res);
			movement.setAdditionalMetaData(PREDICTED_CLASS_KEY, res >= .5);

			return res;
		} else {
			Logger
					.log(Logger.ERROR,
							"Could not process this movement (perhaps an NaN or an Infinity somewhere?)");
			return -1;
		}
	}

	/**
	 * Returns the probability that the movement was deliberate
	 * 
	 * @param movement
	 *            movement already encoded as a Weka Instance, transformed to
	 *            include additional features, and normalized!
	 * @param useTargetInformation
	 *            if set to true, the classifier will make use of features that
	 *            rely on the knowledge of the target size; if set to false, the
	 *            classification will be done in a target agnostic manner
	 * @return
	 * @throws Exception
	 */
	public double getDeliberateProbability(Instance movement,
			boolean useTargetInformation) throws Exception {
		double res = -1;
		try {
			PositiveAndUnlabeledClassifier classifier = (useTargetInformation ? c1
					: c3);
			res = classifier.getDeliberateProbability(movement);
		} catch (Exception e) {
			System.err.println("Trouble when trying to classify " + movement);
			e.printStackTrace();
		}
		return res;
	}

	/**
	 * Assumes the movements data set has "Predicted class" and
	 * "Prediction probability" attributes present. This method classifies each
	 * movement and sets the value of these two attributes and returns such
	 * annotated data set
	 * 
	 * @param movements
	 *            movements encoded as Weka Intances; they have to have had
	 *            additional features already computed and they have to have
	 *            been normalized before being passed here
	 * @param useTargetInformation
	 * @return
	 * @throws Exception
	 */
	public DataSet classifyMovements(DataSet movements,
			boolean useTargetInformation) throws Exception {
		double p = 0;
		Attribute probAttr = movements.attribute("Prediction probability");
		Attribute classAttr = movements.attribute("Predicted class");
		Instance curMovment;
		for (int i = 0; i < movements.numInstances(); i++) {
			curMovment = movements.instance(i);
			p = getDeliberateProbability(curMovment, useTargetInformation);
			curMovment.setValue(probAttr, p);
			curMovment.setValue(classAttr, p > .5 ? 1 : 0);
		}
		return movements;
	}

	/**
	 * Reads log files, uses the parser to extract movements out of the log
	 * files, uses the filter to select only the subset of the movements that
	 * are of interest, and classifies them. For now it just prints an aggregate
	 * report to the stdout
	 * 
	 * @param files
	 *            log files from which the movements are to be extracted
	 * @param filter
	 *            filter for selecting a subset of the movements to be
	 *            classified; if null, all movements get classified
	 * @param parser
	 *            instance of Parser for extracting Movements from the log
	 * @param useTargetInformation
	 *            if set to true, the classifier will make use of features that
	 *            rely on the knowledge of the target size; if set to false, the
	 *            classification will be done in a target agnostic manner
	 * @param returnParsedMovements
	 *            will return a vector of Movement objects if this parameter is
	 *            set to true; will return an empty vector otherwise; useful, if
	 *            all that is needed is the report and not the movements
	 *            themselves
	 * @param report
	 *            a string report will be appended to this variable
	 * 
	 * @throws Exception
	 */
	public Vector<Movement> parseAndClassify(File[] files,
			MovementFilter filter, Parser parser, boolean useTargetInformation,
			boolean returnParsedMovements, Vector<String> report)
			throws Exception {
		Vector<Movement> res = new Vector<Movement>();
		for (File f : files) {
			Logger.log("Working on " + f);
			Vector<Movement> movements = parser
					.parseMovementLog(new File[] { f });
			int numMovements = 0, numDeliberate = 0, numDistracted = 0;
			for (int i = 0; i < movements.size(); i++) {
				if (filter == null
						|| filter.evaluateMovement(movements.elementAt(i))) {
					double p = getDeliberateProbability(movements.elementAt(i),
							useTargetInformation);
					if (p >= .5)
						numDeliberate++;
					else
						numDistracted++;
					numMovements++;
				}
			}
			if (report != null)
				report.add(f.getName() + " \t" + numMovements + "\t"
						+ numDeliberate + "\t" + numDistracted + "\t"
						+ ((double) numDeliberate / (double) numMovements));
			if (returnParsedMovements)
				res.addAll(movements);
		}
		return res;
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		final String targetTypeFilter = args.length > 0 ? args[0] : null;

		MovementClassifier cm = new MovementClassifier();

		Vector<String> report = new Vector<String>();
		report.add(REPORT_HEADER);
		cm.parseAndClassify(FileManipulation
				.getUserSpecifiedFilesForReading(new File(
						Settings.DATA_DIRECTORY)), new MovementFilter() {
			public boolean evaluateMovement(Movement m) {
				if (targetTypeFilter != null)
					return targetTypeFilter.equals(m.getTargetType());
				return true;
			}
		}, new IISMouseLogParser(), true, false, report);

		if (targetTypeFilter != null)
			System.out.println("Only including movements where target type = "
					+ targetTypeFilter);

		System.out
				.println("\n\n=============================\n\nPaste the output that follows into a spreadsheet for an easy to read summary of your data\n\n");
		System.out.println(PrettyPrint.toPrettyString(report, ""));
	}

}
