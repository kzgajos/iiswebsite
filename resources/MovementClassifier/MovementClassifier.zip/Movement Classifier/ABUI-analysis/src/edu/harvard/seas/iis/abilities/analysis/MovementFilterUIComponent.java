package edu.harvard.seas.iis.abilities.analysis;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collection;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.harvard.seas.iis.util.ui.JRangeSlider;

public class MovementFilterUIComponent extends JPanel {

	protected SimpleMovementFilter filter;
	protected Vector<Object> allPossibleValues = new Vector<Object>();
	protected double minAllowed, maxAllowed;
	protected ActionListener listener;
	protected JCheckBox[] checkBoxes;
	protected JRangeSlider slider;
	// slider only operates on ints so if the numeric filter operates on
	// large/small numbers, we will need to rescale
	protected double a, b;

	public MovementFilterUIComponent(String name, SimpleMovementFilter filter,
			Object[] allPossibleValues) {
		this(name, filter, Arrays.asList(allPossibleValues));
	}

	public MovementFilterUIComponent(String name, SimpleMovementFilter filter,
			Collection<Object> allPossibleValues) {
		super(new GridLayout(allPossibleValues.size(), 1));
		setBorder(BorderFactory.createTitledBorder(name));
		this.filter = filter;
		this.allPossibleValues.addAll(allPossibleValues);

		createUI();
	}

	public MovementFilterUIComponent(String name, SimpleMovementFilter filter,
			double minAllowed, double maxAllowed) {
		super();
		setBorder(BorderFactory.createTitledBorder(name));
		this.filter = filter;
		this.minAllowed = minAllowed;
		this.maxAllowed = maxAllowed;
		createUI();
	}

	public ActionListener getListener() {
		return listener;
	}

	public void setListener(ActionListener listener) {
		this.listener = listener;
	}

	public Vector<Object> getSelectedValues() {
		Vector<Object> res = new Vector<Object>();
		for (int i = 0; i < checkBoxes.length; i++)
			if (checkBoxes[i].isSelected())
				res.add(allPossibleValues.elementAt(i));
		return res;
	}

	protected JLabel valueLabel, minLabel, maxLabel;

	protected void createUI() {
		if (filter.isNumerical()) {
			JPanel sliderPanel = new JPanel(new BorderLayout());
			a = minAllowed;
			b = 1000.0 / (maxAllowed - a);

			slider = new JRangeSlider(0, 1000,
					(int) ((filter.minValue - a) * b),
					(int) ((filter.maxValue - a) * b), JRangeSlider.HORIZONTAL);
			slider.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					filter.setNumericalFilter((double) slider.getLowValue() / b
							+ a, (double) slider.getHighValue() / b + a);
					if (listener != null)
						listener.actionPerformed(null);
					valueLabel.setText(filter.getMinValue() + " to "
							+ filter.getMaxValue());
				}
			});

			minLabel = new JLabel(minAllowed + "");
			maxLabel = new JLabel(maxAllowed + "");
			valueLabel = new JLabel(filter.getMinValue() + " to "
					+ filter.getMaxValue());
			JPanel valuePanel = new JPanel(new BorderLayout());
			valuePanel.add(valueLabel, BorderLayout.CENTER);
			valuePanel.add(minLabel, BorderLayout.WEST);
			valuePanel.add(maxLabel, BorderLayout.EAST);

			sliderPanel.add(slider, BorderLayout.CENTER);
			sliderPanel.add(valuePanel, BorderLayout.NORTH);

			add(sliderPanel);
		} else {
			checkBoxes = new JCheckBox[allPossibleValues.size()];
			for (int i = 0; i < allPossibleValues.size(); i++) {
				final JCheckBox vBox = new JCheckBox(allPossibleValues
						.elementAt(i).toString());
				checkBoxes[i] = vBox;
				final Object finalVal = allPossibleValues.elementAt(i);
				vBox.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (vBox.isSelected())
							filter.addAllowedNominalValue(finalVal);
						else
							filter.removeAllowedNominalValue(finalVal);
						if (listener != null)
							listener.actionPerformed(null);
					}
				});
				add(vBox);
			}

		}

	}

}
