package redstone.xmlrpc.serializers;

import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import redstone.xmlrpc.XmlRpcException;
import redstone.xmlrpc.XmlRpcSerializer;
import edu.harvard.seas.iis.util.io.SerializableToMap;

public class MouseEventSerializer extends MapSerializer {

	public Class getSupportedClass() {
		return MouseEvent.class;
	}

	public void serialize(Object value, Writer output,
			XmlRpcSerializer builtInSerializer) throws XmlRpcException,
			IOException {
		Map<String, Object> map = null;
		if (value instanceof SerializableToMap)
			map = ((SerializableToMap) value).serializeToMap();
		else {
			map = new HashMap<String, Object>();
			map.put("id", ((MouseEvent) value).getID());
			map.put("x", ((MouseEvent) value).getPoint().x);
			map.put("y", ((MouseEvent) value).getPoint().y);
			map.put("time", ((MouseEvent) value).getWhen());
		}
		super.serialize(map, output, builtInSerializer);
	}
}
