package redstone.xmlrpc.serializers;

import java.awt.Point;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;

import redstone.xmlrpc.XmlRpcException;
import redstone.xmlrpc.XmlRpcSerializer;

public class PointSerializer extends MapSerializer {

	public Class getSupportedClass() {
		return Point.class;
	}

	public void serialize(Object value, Writer output,
			XmlRpcSerializer builtInSerializer) throws XmlRpcException,
			IOException {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("x", ((Point) value).x);
		map.put("y", ((Point) value).y);
		super.serialize(map, output, builtInSerializer);
	}

}
