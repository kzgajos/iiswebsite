/*
 * Created on Aug 14, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package redstone.xmlrpc.serializers;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import redstone.xmlrpc.XmlRpcException;
import redstone.xmlrpc.XmlRpcSerializer;
import edu.harvard.seas.iis.util.Logger;
import edu.harvard.seas.iis.util.io.SerializableToMap;

public class SerializableToMapSerializer extends MapSerializer {

	public SerializableToMapSerializer() {
	}

	public Class getSupportedClass() {
		return SerializableToMap.class;
	}

	public void serialize(Object value, Writer output,
			XmlRpcSerializer builtInSerializer) throws XmlRpcException,
			IOException {
		Map map = ((SerializableToMap) value).serializeToMap();
		try {
			super.serialize(map, output, builtInSerializer);
		} catch (RuntimeException ex) {
			Logger.log(Logger.ERROR, "Value: " + value);
			Logger.log(Logger.ERROR, "Map: " + map);
			ex.printStackTrace();
		}
	}

}
