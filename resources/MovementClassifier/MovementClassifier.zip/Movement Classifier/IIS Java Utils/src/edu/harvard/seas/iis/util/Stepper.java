package edu.harvard.seas.iis.util;


public class Stepper {




  public static void step(String info) {
    System.out.println("*** Stepper step: " + info);
    System.out.println("*** Press any button to continue");
    try {
      System.in.read();
    } catch (Exception ex) {}
  }




}
