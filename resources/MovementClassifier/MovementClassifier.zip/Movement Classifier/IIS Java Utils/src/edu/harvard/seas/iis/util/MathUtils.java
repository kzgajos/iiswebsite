/*
 * Created on Feb 8, 2007
 */
package edu.harvard.seas.iis.util;

public class MathUtils {

    public static double log(double a, double base) {
        return Math.log(a) / Math.log(base);
    }

    public static double[] rationalApproximation(double x, double minDenom) {
        double[] left = new double[] { 0, 1 };
        double[] right = new double[] { 1, 0 };
        double[] best = left;
        double bestError = Math.abs(x);

        // do Stern-Brocot binary search
        while (best[1] < minDenom) {

            // compute next possible rational approximation
            double[] mediant = new double[] { left[0] + right[0],
                    left[1] + right[1] };
            if (x < mediant[0] / mediant[1])
                right = mediant; // go left
            else
                left = mediant; // go right

            // check if better and update champion
            double error = Math.abs(mediant[0] / mediant[1] - x);
            if (error < bestError) {
                best = mediant;
                bestError = error;
            }
        }
        return best;
    }

    public static void main(String[] args) {
        rationalApproximation(Math.E, 300);
    }
}
