/*
 * Created on Nov 27, 2004
 */
package edu.harvard.seas.iis.util.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;

/**
 * @author kgajos
 */
public class ArrayUtils {

	/**
	 * Searches the array for the first occurance of key
	 * 
	 * @param array
	 *            array to be searched
	 * @param key
	 *            object to be found
	 * @return index of the first occurance of the object in the array or -1 if
	 *         not found
	 */
	public static int search(Object[] array, Object key) {
		if (array == null || key == null)
			return -1;
		for (int i = 0; i < array.length; i++)
			try {
				if (key.equals(array[i]))
					return i;
			} catch (Exception ex) {
			}
		return -1;
	}

	public static <T> T[] appendArrays(T[] a1, T[] a2) {
		Vector<T> tempRes = new Vector<T>();
		for (int i = 0; i < a1.length; i++)
			tempRes.add(a1[i]);
		for (int i = 0; i < a2.length; i++)
			tempRes.add(a2[i]);
		return tempRes.toArray(a1);
	}

	public static <T> ArrayList<T> asArrayList(T[] a) {
		ArrayList<T> res = new ArrayList<T>();
		for (T el : a)
			res.add(el);
		return res;
	}

	public static <T> T[] union(T[] a1, T[] a2) {
		ArrayList<T> al1 = asArrayList(a1);
		ArrayList<T> al2 = asArrayList(a2);
		Vector<T> union = CollectionUtils.union(al1, al2);
		return union.toArray(Arrays.copyOf(a1, 1));
	}

	public static <T> T[] intersection(T[] a1, T[] a2) {
		ArrayList<T> al1 = asArrayList(a1);
		ArrayList<T> al2 = asArrayList(a2);
		Vector<T> intersection = CollectionUtils.intersection(al1, al2);
		return intersection.toArray(Arrays.copyOf(a1, 1));
	}

	public static ArrayList<Double> asArrayList(double[] a) {
		ArrayList<Double> res = new ArrayList<Double>();
		for (double el : a)
			res.add(el);
		return res;
	}

	public static double[] toPrimitiveArray(Double[] in) {
		double[] res = new double[in.length];
		for (int i = 0; i < in.length; i++)
			res[i] = in[i];
		return res;
	}

	public static double[] getRandomSubset(double[] source, int subsetSize) {
		return toPrimitiveArray(CollectionUtils.getRandomSubset(
				asArrayList(source), subsetSize).toArray(new Double[] {}));
	}

}
