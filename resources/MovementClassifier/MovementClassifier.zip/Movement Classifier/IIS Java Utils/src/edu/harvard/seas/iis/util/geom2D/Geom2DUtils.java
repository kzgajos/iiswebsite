/*
 * Created on Nov 17, 2006
 */
package edu.harvard.seas.iis.util.geom2D;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;

/**
 * @author kgajos with some code copied from
 *         org/metagraph/utility/graphics/GraphicsUtil.java
 * 
 */
public class Geom2DUtils {

	/**
	 * Rotate a point around the origin
	 * 
	 * @param point
	 *            point to be rotated
	 * @param angle
	 *            the rotation angle (in radians)
	 * @return the new point object rotated
	 */
	public static Point rotate(Point point, double angle) {
		return new Point((int) (point.x * Math.cos(angle) - point.y
				* Math.sin(angle)), (int) (point.x * Math.sin(angle) + point.y
				* Math.cos(angle)));
	}

	public static double[] rotate(double x, double y, double angle) {
		double[] res = new double[2];
		res[0] = x * Math.cos(angle) - y * Math.sin(angle);
		res[1] = x * Math.sin(angle) + y * Math.cos(angle);
		return res;
	}

	public static Point translate(Point point, Point offset) {
		return new Point(point.x + offset.x, point.y + offset.y);
	}

	public static Point translate(Point point, double distance, double angle) {
		return translate(point, getXY(distance, angle));
	}

	/**
	 * Computes distance between two points
	 * 
	 * @param point1
	 * @param point2
	 * @return
	 */
	public static double getDistance(Point point1, Point point2) {
		double res = Math.sqrt(Math.pow((double) (point1.x - point2.x), 2)
				+ Math.pow((double) (point1.y - point2.y), 2));
		return res;
	}

	public static double getDistance(double p1x, double p1y, double p2x,
			double p2y) {
		double res = Math.sqrt(Math.pow((double) (p1x - p2x), 2)
				+ Math.pow((double) (p1y - p2y), 2));
		return res;
	}

	/**
	 * computes the distance from the point to the nearest point on the polygon
	 * boundary (works for points insider or outside the plygon)
	 * 
	 * @param x
	 * @param y
	 * @param polygn
	 * @return
	 */
	public static double getDistance(double x, double y, Polygon polygn) {
		PathIterator pi = polygn.getPathIterator(null);
		double[] firstPoint = new double[2];
		pi.currentSegment(firstPoint);
		pi.next();

		double lastX = firstPoint[0];
		double lastY = firstPoint[1];
		double[] curPoint = new double[2];
		int segType;
		double curDist;

		double dist = Double.MAX_VALUE;

		while (!pi.isDone()) {
			segType = pi.currentSegment(curPoint);
			// if we are instructed to close the polygon, then connect the
			// current point to the first one
			if (segType == PathIterator.SEG_CLOSE) {
				lastX = firstPoint[0];
				lastY = firstPoint[1];
			}
			curDist = Line2D.ptSegDist(lastX, lastY, curPoint[0], curPoint[1],
					x, y);
			dist = Math.min(dist, curDist);
			lastX = curPoint[0];
			lastY = curPoint[1];
			pi.next();
		}

		return dist;
	}

	/**
	 * Returns the norm of the vector represented by point
	 * 
	 * @param point
	 * @return
	 */
	public static double getDistance(Point point) {
		double res = Math.sqrt(Math.pow((double) point.x, 2)
				+ Math.pow((double) point.y, 2));
		return res;
	}

	public static Point getVector(Point start, Point end) {
		return new Point(end.x - start.x, end.y - start.y);
	}

	/**
	 * Converts vector representation from polar to Euclidian coordinates
	 * 
	 * @param distance
	 * @param angle
	 * @return
	 */
	public static Point getXY(double distance, double angle) {
		Point res = new Point((int) Math.round(Math.cos(angle) * distance),
				(int) Math.round(Math.sin(angle) * distance));
		return res;
	}

	public static Point getXY(Point offset, double distance, double angle) {
		Point res = new Point((int) Math.round(Math.cos(angle) * distance)
				+ offset.x, (int) Math.round(Math.sin(angle) * distance)
				+ offset.y);
		return res;
	}

	public static Point getCenter(Dimension dim) {
		return new Point((int) Math.round(dim.getWidth() / 2.0), (int) Math
				.round(dim.getHeight() / 2.0));
	}

	public static Point getCenter(Rectangle loc) {
		return new Point((int) Math.round(loc.getWidth() / 2 + loc.getX()),
				(int) Math.round(loc.getHeight() / 2 + loc.getY()));
	}

	public static Dimension getMin(Dimension d1, Dimension d2) {
		return new Dimension((int) (Math.min(d1.getWidth(), d2.getWidth())),
				(int) Math.min(d1.getHeight(), d2.getHeight()));
	}

	/**
	 * computes min of the two dimensions but instead of creating a new return
	 * object, it modifies the first parameter to contain the answer
	 * 
	 * @param res
	 * @param other
	 * @return
	 */
	public static Dimension getMinInPlace(Dimension res, Dimension other) {
		res.height = Math.min(res.height, other.height);
		res.width = Math.min(res.width, other.width);
		return res;
	}

	public static Dimension getMax(Dimension d1, Dimension d2) {
		return new Dimension((int) (Math.max(d1.getWidth(), d2.getWidth())),
				(int) Math.max(d1.getHeight(), d2.getHeight()));
	}

	public static Dimension getMaxInPlace(Dimension res, int otherWidth,
			int otherHeight) {
		res.height = Math.max(res.height, otherHeight);
		res.width = Math.max(res.width, otherWidth);
		return res;
	}

	/**
	 * computes max of the two dimensions but instead of creating a new return
	 * object, it modifies the first parameter to contain the answer
	 * 
	 * @param res
	 * @param other
	 * @return
	 */
	public static Dimension getMaxInPlace(Dimension res, Dimension other) {
		res.height = Math.max(res.height, other.height);
		res.width = Math.max(res.width, other.width);
		return res;
	}

	public static Dimension getSumInPlace(Dimension res, Dimension other) {
		res.height += other.height;
		res.width += other.width;
		return res;
	}

	public static Dimension getSumInPlace(Dimension res, int x, int y) {
		res.height += y;
		res.width += x;
		return res;
	}

	public static Insets getMinInPlace(Insets res, Insets other) {
		res.bottom = Math.min(res.bottom, other.bottom);
		res.top = Math.min(res.top, other.top);
		res.left = Math.min(res.left, other.left);
		res.right = Math.min(res.right, other.right);
		return res;
	}

	/**
	 * Returns the angle of the vector from p1 to p2
	 * 
	 * @param p1
	 * @param p2
	 * @return
	 */
	public static double getAngle(Point p1, Point p2) {
		return Math.atan2(p1.y - p2.y, p1.x - p2.x);
	}

	/**
	 * Find the shortest connecting line between two rectangles.
	 * 
	 * copied from org/metagraph/utility/graphics/GraphicsUtil.java
	 * 
	 * @return An array of two coordinates describing the line
	 */
	public static Point[] getConnectingLine(Rectangle r1, Rectangle r2) {
		// Find centers of rectangles
		int x1 = r1.x + (r1.width >> 1);
		int y1 = r1.y + (r1.height >> 1);
		int x2 = r2.x + (r2.width >> 1);
		int y2 = r2.y + (r2.height >> 1);

		// Find the intersection with each of the rectangles,
		// and the line between the two centers
		Point[] p = new Point[2];
		p[0] = uniqueLineSegmentRectangleIntersection(new Point(x1, y1),
				new Point(x2, y2), r1);
		p[1] = uniqueLineSegmentRectangleIntersection(new Point(x1, y1),
				new Point(x2, y2), r2);
		if (p[0] != null && p[1] != null) {
			return p;
		}
		return null;
	}

	public static Point[] getConnectingLine(Point start, Rectangle r2) {
		// Find centers of rectangle
		int x2 = r2.x + (r2.width >> 1);
		int y2 = r2.y + (r2.height >> 1);

		// Find the intersection with each of the rectangles,
		// and the line between the two centers
		Point[] p = new Point[2];
		p[0] = start;
		p[1] = uniqueLineSegmentRectangleIntersection(start, new Point(x2, y2),
				r2);
		if (p[0] != null && p[1] != null) {
			return p;
		}
		return null;
	}

	/**
	 * Determine the unique intersection point of a line segment and a
	 * rectangle.
	 * 
	 * @param p1
	 *            Coordinates of one end of a line
	 * @param p2
	 *            Coordinates of the other end of a line
	 * @param r
	 *            Rectangle object
	 * 
	 *            copied from org/metagraph/utility/graphics/GraphicsUtil.java
	 * 
	 * @return A Point representing the unique intersection, or null if no
	 *         unique intersection exists.
	 */
	public static Point uniqueLineSegmentRectangleIntersection(Point p1,
			Point p2, Rectangle r) {
		// Only four corners on a rectangle (well, duh!)
		Point[] corner = new Point[4];
		corner[0] = new Point(r.x, r.y);
		corner[1] = new Point(r.x + r.width, r.y);
		corner[2] = new Point(r.x, r.y + r.height);
		corner[3] = new Point(r.x + r.width, r.y + r.height);

		// Only four lines in the rectangle to intersect with
		Point[] intersect = new Point[4];
		intersect[0] = lineSegmentIntersection(corner[0], corner[1], p1, p2);
		intersect[1] = lineSegmentIntersection(corner[0], corner[2], p1, p2);
		intersect[2] = lineSegmentIntersection(corner[1], corner[3], p1, p2);
		intersect[3] = lineSegmentIntersection(corner[2], corner[3], p1, p2);

		int count = 0;
		Point found = null;
		for (int i = 0; i < 4; i++) {
			if (intersect[i] != null) {
				found = intersect[i];
				count++;
			}
		}
		if (count > 0) {
			// there is at least one intersection - doesn't matter if there are
			// more - just return one!
			return found;
		}
		return null;
	}

	/**
	 * Determine the intersection point of two line segments, or return null if
	 * no intersection.
	 * 
	 * @param line1P1
	 *            Coordinates of one end of line #1
	 * @param line1P2
	 *            Coordinates of the other end of line #1
	 * @param line2P1
	 *            Coordinates of one end of line #2
	 * @param line2P2
	 *            Coordinates of the other end of line #2
	 * 
	 *            copied from org/metagraph/utility/graphics/GraphicsUtil.java
	 * 
	 * @return Coordinates of the intersection, or null if none exists
	 */
	public static Point lineSegmentIntersection(Point line1P1, Point line1P2,
			Point line2P1, Point line2P2) {
		double numA = ((line2P2.x - line2P1.x) * (line1P1.y - line2P1.y))
				- ((line2P2.y - line2P1.y) * (line1P1.x - line2P1.x));
		double numB = ((line1P2.x - line1P1.x) * (line1P1.y - line2P1.y))
				- ((line1P2.y - line1P1.y) * (line1P1.x - line2P1.x));
		double den = ((line2P2.y - line2P1.y) * (line1P2.x - line1P1.x))
				- ((line2P2.x - line2P1.x) * (line1P2.y - line1P1.y));
		if ((numA == 0 || numB == 0) && den == 0) {
			// Coincident lines
			return null; // there is no precise intersection
		} else if (den == 0) {
			// Parallel lines
			return null;
		} else {
			// The lines intersect...
			double ua = numA / den;
			double ub = numB / den;

			// ...but do the line SEGMENTS intersect?
			if (ua >= 0.0 && ua <= 1.0 && ub >= 0.0 && ub <= 1.0) {
				// Yes, the line segements intersect
				int x = line1P1.x
						+ (int) (ua * (double) (line1P2.x - line1P1.x));
				int y = line1P1.y
						+ (int) (ua * (double) (line1P2.y - line1P1.y));
				return new Point(x, y);
			}
		}
		return null; // no intersection
	}

	/**
	 * Returns a rectangle that is an interpolation between start and target; if
	 * res is not null, the result will be put into it and returned; if res is
	 * null, a new Rectangle object will be allocated
	 * 
	 * @param start
	 * @param target
	 * @param fraction
	 * @param res
	 * @return
	 */
	public static Rectangle interpolate(Rectangle start, Rectangle target,
			double fraction, Rectangle res) {
		if (res == null)
			res = new Rectangle();
		res.x = (int) Math.round(fraction * (double) target.x
				+ (1.0 - fraction) * (double) start.x);
		res.y = (int) Math.round(fraction * (double) target.y
				+ (1.0 - fraction) * (double) start.y);
		res.width = (int) Math.round(fraction * (double) target.width
				+ (1.0 - fraction) * (double) start.width);
		res.height = (int) Math.round(fraction * (double) target.height
				+ (1.0 - fraction) * (double) start.height);
		return res;
	}

}
