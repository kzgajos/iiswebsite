/*
 * Created on Apr 4, 2004
 */
package edu.harvard.seas.iis.util.combinatorics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author kgajos
 * 
 *         Iterator that generates subsets of a given size from an underlying
 *         collection
 */
public class ChooseNIterator implements Iterator {

	protected ArrayList collection;
	protected int n;
	protected int[] indices;
	protected boolean stop = false;

	public ChooseNIterator(Collection c, int n) {
		if (n > c.size())
			n = c.size();
		collection = new ArrayList(c);
		this.n = n;

		// initialize indices
		indices = new int[n];
		for (int i = 0; i < indices.length; i++)
			indices[i] = i;
	}

	/**
	 * This iterator does not support the remove operation
	 * 
	 * @see java.util.Iterator#remove()
	 */
	public void remove() {
		throw new UnsupportedOperationException();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.Iterator#hasNext()
	 */
	public boolean hasNext() {
		/*
		 * for (int i = indices.length - 1; i >= 0; i--) { if (indices[i] >
		 * collection.size() - n + i) return false; } return true;
		 */
		return !stop;
	}

	private boolean willCarryOver(int index) {
		for (int i = 0; i < indices.length - index; i++)
			if (indices[indices.length - i - 1] < collection.size() - i - 1)
				return false;

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.Iterator#next()
	 */
	public Object next() {
		ArrayList res = new ArrayList();
		// pick values from the underlying collection as suggested by the
		// current indices
		for (int i = 0; i < indices.length; i++)
			res.add(collection.get(indices[i]));

		// update indices
		updateIndices();

		return res;
	}

	protected void updateIndices() {
		if (hasNext())
			updateIndicesHelper(0);
	}

	private void updateIndicesHelper(int curIndex) {
		if (curIndex == indices.length - 1 || willCarryOver(curIndex + 1)) {
			if (indices[curIndex] < collection.size() - indices.length
					+ curIndex) {
				indices[curIndex]++;
			} else {
				if (curIndex == 0)
					stop = true;
				else if (indices[curIndex - 1] + 1 < collection.size())
					indices[curIndex] = indices[curIndex - 1] + 1;
			}
		}

		if (curIndex < indices.length - 1)
			updateIndicesHelper(curIndex + 1);
	}

	protected static void test() {
		ArrayList dom = new ArrayList();
		for (int i = 0; i < 5; i++)
			dom.add(new Integer(i));
		Iterator it = new ChooseNIterator(dom, 2);
		while (it.hasNext())
			System.out.println("choice: " + it.next());
	}

	public static void main(String[] args) {
		test();
	}

}
