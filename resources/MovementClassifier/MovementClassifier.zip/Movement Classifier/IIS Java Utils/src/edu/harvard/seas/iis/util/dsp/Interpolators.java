/*
 * Created on May 14, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package edu.harvard.seas.iis.util.dsp;

public class Interpolators {

	public static double getNormalCoefficient(double mean, double value,
			double stdev) {

		double normalizationConstant = 1 / (Math.sqrt(Math.PI * 2) * stdev);
		double exponent = -0.5
				* (Math.pow(value - mean, 2) / Math.pow(stdev, 2));
		return normalizationConstant * Math.exp(exponent);
	}

	public static double[] gaussianSmoothing(double[] data, double stdev) {
		double[] res = new double[data.length];
		for (int i = 0; i < data.length; i++)
			res[i] = getGaussianSmoothedValue(data, i, stdev);
		return res;
	}

	protected static double getGaussianSmoothedValue(double[] data,
			int smoothedIndex, double stdev) {
		double res = 0;
		for (int i = 0; i < data.length; i++)
			res += getNormalCoefficient((double) smoothedIndex, (double) i,
					stdev)
					* data[i];
		return res;
	}

	public static void main(String[] args) {
		double[] data = new double[1000];
		for (int i = 0; i < data.length; i++) {
			data[i] = Math.sin((double) i / 50.0);
			data[i] += 0.1 * Math.random();
		}
		double[] out = gaussianSmoothing(data, 5);
		for (int i = 0; i < data.length; i++) {
			System.out.println(data[i] + "\t" + out[i]);
		}
	}
}
