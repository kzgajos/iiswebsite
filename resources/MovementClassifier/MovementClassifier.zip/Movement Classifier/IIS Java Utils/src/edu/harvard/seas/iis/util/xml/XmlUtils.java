/*
 * Created on Feb 12, 2005
 */
package edu.harvard.seas.iis.util.xml;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author kgajos
 */
public class XmlUtils {

	/**
	 * Performs depth-first search of a document tree and returns the first node
	 * it finds with a given name
	 * 
	 * @param name
	 *            name of the node we are looking for
	 * @param start
	 *            start node
	 * @return a node with a given name or null if none was found
	 */
	public static Node findFirstNodeByName(String name, Node start) {
		if (start == null)
			return null;
		if (name.equals(start.getNodeName()))
			return start;
		NodeList children = start.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			Node res = findFirstNodeByName(name, children.item(i));
			if (res != null)
				return res;
		}
		return null;
	}

	public static String getNodeAttributeValue(Node node, String attributeName,
			String defaultValue) {
		if (node == null)
			return defaultValue;
		if (!node.hasAttributes())
			return defaultValue;
		String res = defaultValue;
		try {
			res = node.getAttributes().getNamedItem(attributeName)
					.getNodeValue();
		} catch (Exception ex) {
		}
		return res;
	}

	public static boolean getNodeAttributeBooleanValue(Node node,
			String attributeName, boolean defaultValue) {
		String stringRes = getNodeAttributeValue(node, attributeName, null);
		boolean res = defaultValue;
		try {
			res = Boolean.parseBoolean(stringRes);
		} catch (Exception ex) {
		}
		return res;
	}

	public static int getNodeAttributeIntValue(Node node, String attributeName,
			int defaultValue) {
		String stringRes = getNodeAttributeValue(node, attributeName, null);
		int res = defaultValue;
		try {
			res = Integer.parseInt(stringRes);
		} catch (Exception ex) {
		}
		return res;
	}

	public static long getNodeAttributeLongValue(Node node,
			String attributeName, long defaultValue) {
		String stringRes = getNodeAttributeValue(node, attributeName, null);
		long res = defaultValue;
		try {
			res = Long.parseLong(stringRes);
		} catch (Exception ex) {
		}
		return res;
	}

	public static double getNodeAttributeDoubleValue(Node node,
			String attributeName, double defaultValue) {
		String stringRes = getNodeAttributeValue(node, attributeName, null);
		double res = defaultValue;
		try {
			res = Double.parseDouble(stringRes);
		} catch (Exception ex) {
		}
		return res;
	}
}
