/*
 * Created on Mar 29, 2005
 */
package edu.harvard.seas.iis.util.combinatorics;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

/**
 * @author kgajos
 * 
 * Generates distinct pairs out of a single collection of objects (if pair A,B
 * is generated, then B,A won't be; it will never generate A,A either)
 */
public class DistinctPairsIterator implements Iterator {

    protected Vector collection;
    protected int outer = 0;
    protected int inner = 1;
    
    /**
     * 
     */
    public DistinctPairsIterator(Collection c) {
        collection = new Vector(c);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#hasNext()
     */
    public boolean hasNext() {
        return outer + 2 < collection.size() || inner + 1 < collection.size();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#next()
     */
    public Object next() {
        Object[] res = null;
        if (hasNext()) {
            res = new Object[] {collection.elementAt(outer), collection.elementAt(inner)};
            inner++;
            if (inner + 1 == collection.size()) {
                outer++;
                inner = outer + 1;
            }
        }
        return res;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#remove()
     */
    public void remove() {
        throw new UnsupportedOperationException("Remove not supported");
    }

}
