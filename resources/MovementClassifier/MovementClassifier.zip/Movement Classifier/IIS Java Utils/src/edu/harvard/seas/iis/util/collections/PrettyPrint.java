/*
 * Created on Feb 20, 2005
 */
package edu.harvard.seas.iis.util.collections;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

/**
 * @author kgajos
 */
public class PrettyPrint {

	public static String toPrettyLine(Collection c, String separator) {
		Iterator it = c.iterator();
		String res = "";
		while (it.hasNext())
			res += it.next() + (it.hasNext() ? separator : "");
		return res;
	}

	public static String toPrettyLine(Object[] c, String separator) {
		String res = "";
		for (int i = 0; c != null && i < c.length - 1; i++)
			res += c[i] + separator;
		if (c.length > 0)
			res += c[c.length - 1];
		return res;
	}

	public static String toPrettyLine(double[] c, String separator) {
		String res = "";
		for (int i = 0; c != null && i < c.length - 1; i++)
			res += c[i] + separator;
		if (c.length > 0)
			res += c[c.length - 1];
		return res;
	}

	public static String toPrettyString(Collection c, String prefix) {
		return toPrettyString(c, prefix, "\n");
	}

	public static String toPrettyString(Collection c, String prefix,
			String separator) {
		Iterator it = c.iterator();
		String res = "";
		while (it.hasNext())
			res += prefix + it.next() + (it.hasNext() ? separator : "");
		return res;
	}

	public static String toPrettyString(double[] c, String prefix) {
		String res = "[";
		for (int i = 0; i < c.length; i++)
			res += prefix + c[i] + (i < c.length - 1 ? "," : "]");
		return res;
	}

	public static String toPrettyString(float[] c, String prefix) {
		String res = "[";
		for (int i = 0; i < c.length; i++)
			res += prefix + c[i] + (i < c.length - 1 ? "," : "]");
		return res;
	}

	public static String toPrettyString(Object[] c, String prefix) {
		String res = "[";
		for (int i = 0; c != null && i < c.length; i++)
			res += prefix + c[i] + (i < c.length - 1 ? "," : "]");
		return res;
	}

	public static String toPrettyString(double[][] c, String separator) {
		String res = "";
		for (int row = 0; row < c.length; row++)
			for (int col = 0; col < c[row].length; col++)
				res += c[row][col]
						+ (col < c[row].length - 1 ? separator : "\n");
		return res;
	}

	public static String toPrettyString(Hashtable table) {
		Set keys = table.keySet();
		String res = "";
		for (Object key : keys) {
			res += key + ": " + table.get(key) + "\n";
		}
		return res;
	}

}
