package edu.harvard.seas.iis.util.stats;

public class LinearRegressionCalculator {

	protected double[] x, y;

	protected double n, a, b;

	private double SSR = 0.0; // regression sum of squares

	private double SSE = 0.0; // error sum of squares

	public LinearRegressionCalculator() {
	}

	public void setData(double[] x, double[] y) {
		if (x.length != y.length)
			throw new IllegalArgumentException(
					"Arguments must be of equal length!");
		this.x = x;
		this.y = y;
		n = y.length;
		doStatistics();
	}

	protected void doStatistics() {
		double minX = 0, maxX = 0, minY = 0, maxY = 0, sumX = 0, sumY = 0, sumXsquared = 0, sumYsquared = 0, sumXY = 0, Sxx = 0, Syy = 0, Sxy = 0;
		// Find sum of squares for x,y and sum of xy
		for (int i = 0; i < n; i++) {
			minX = Math.min(minX, x[i]);
			maxX = Math.max(maxX, x[i]);
			minY = Math.min(minY, y[i]);
			maxY = Math.max(maxY, y[i]);
			sumX += x[i];
			sumY += y[i];
			sumXsquared += x[i] * x[i];
			sumYsquared += y[i] * y[i];
			sumXY += x[i] * y[i];
		}
		Sxx = sumXsquared - sumX * sumX / n;
		Syy = sumYsquared - sumY * sumY / n;
		Sxy = sumXY - sumX * sumY / n;
		b = Sxy / Sxx;
		a = (sumY - b * sumX) / n;
		SSR = Sxy * Sxy / Sxx;
		SSE = Syy - SSR;
	}

	public double getIntercept() {
		return a;
	}

	public double getSlope() {
		return b;
	}

	/**
	 * Computes linear regression coefficients
	 * 
	 * @param x
	 * @param y
	 * @return [intercept, slope]
	 */
	public static double[] computeLinearRegressionParameters(double[] x,
			double[] y) {
		LinearRegressionCalculator calculator = new LinearRegressionCalculator();
		calculator.setData(x, y);
		calculator.doStatistics();
		return new double[] { calculator.getIntercept(), calculator.getSlope() };
	}

}
