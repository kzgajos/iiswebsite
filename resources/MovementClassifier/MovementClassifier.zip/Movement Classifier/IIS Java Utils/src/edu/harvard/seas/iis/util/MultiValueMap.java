package edu.harvard.seas.iis.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 * This class contains a bunch of static methods that make it easier
 * to deal with Maps (e.g. Hashtables, PersistentMaps) that contain
 * more than one value per key.
 * 
 * @author Krzysztof Gajos
 */
public class MultiValueMap {

	/******************
	 *  CONSTRUCTORS  *
	 ******************/
	/**
	 * Class constructor
	 */
	public MultiValueMap() {
	}

	/*************
	 *  METHODS  *
	 *************/

	/**
	 * Adds a value to a collection of values under a specific key. If
	 * there already is a value under the key and it is not a
	 * collection, this method does nothing and returns false;
	 * otherwise it returns true. (if the value is already there, the
	 * new one does not get added) 
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @param  val  value to be referenced by <code>key</code>
	 * @return  True if successful insert or <code>val</code> already present,
	 *          False otherwise
	 */
	public static boolean addValue(Map map, Object key, Object val) {
		Collection v = getValueCollection(map, key);
		if (v == null) {
			return false;
		}
		if (!v.contains(val)) {
			v.add(val);
		}
		map.put(key, v);

		return true;
	}

	/**
	 * Adds a whole collection of values to a collection of values
	 * under a specific key. If there already is a value under the key
	 * and it is not a collection, this method does nothing and
	 * returns false; otherwise it returns true. (if the any of the
	 * values is already there, the new one does not get added) 
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @param  vals  a collection of values to be referenced by <code>key</code>
	 * @return  True if successful insert or <code>vals</code> already present,
	 *          False otherwise
	 */
	public static boolean addValues(Map map, Object key, Collection vals) {
		Collection v = getValueCollection(map, key);
		if (v == null) {
			return false;
		}
		Iterator it = vals.iterator();

		while (it.hasNext()) {
			Object val = it.next();
			if (!v.contains(val)) {
				v.add(val);
			}
		}

		map.put(key, v);

		return true;
	}

	/**
	 * Returns true if the list of values for a key contains the
	 * value; false otherwise 
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @param  val  value to be referenced by <code>key</code>
	 * @return  true if the list of values for a key contains the value; false
	 *          otherwise 
	 */
	public static boolean containsValue(Map map, Object key, Object val) {
		Object o = map.get(key);
		if (o == null || !(o instanceof Collection)) {
			return false;
		}
		Collection v = (Collection) o;

		return v.contains(val);
	}

	/**
	 * Remove the value from the list of values associated with a
	 * given key (there can be many values under the same key); if
	 * this is the last value under the key, the key will be removed
	 * as well.
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @param  val  value to be referenced by <code>key</code>
	 * @return true if there was something there, false otherwise 
	 */
	public static boolean removeValue(Map map, Object key, Object val) {
		Object o = map.get(key);
		if (o == null || !(o instanceof Collection)) {
			return false;
		}
		Collection v = (Collection) o;

		boolean res = v.remove(val);

		if (v.size() == 0) { // if no value is left, remove the whole key
			map.remove(key);
		} else { // this is necessary for persistent maps...
			map.put(key, v);
		}
		return res;
	}

	/**
	 * Replaces one value in the list of values with another
	 * one. Returns true if the old value was there and the new one
	 * was added successfully.
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @param  oldVal  previous value to remove
	 * @param  newVal  value to insert
	 * @return  true if remove and insert are successful, false otherwise
	 */
	public static boolean replaceValue(
		Map map,
		Object key,
		Object oldVal,
		Object newVal) {
		return removeValue(map, key, oldVal) && addValue(map, key, newVal);
	}

	/**
	 * private helper function -- if the key in a map holds a
	 * Collection of values, it will be returned; if the key holds
	 * nothing, a new ArrayList will be returned, finally, null will
	 * be returned if the current value under the key is something
	 * other than a Collection.  
	 *
	 * @param  map  object holding the key-val(s) binding
	 * @param  key  identifier for a specific binding
	 * @return  the collection of values identified by <code>key</code> or null
	 */
	private static Collection getValueCollection(Map map, Object key) {
		Object o = map.get(key);
		Collection v = null;
		if (o == null) {
			v = new ArrayList();
		} else {
			if (o instanceof Collection) {
				v = (Collection) o;
			} else {
				return null;
			}
		}

		return v;
	}
	
	
	/**
	 * Returns a collection of all values contained in the map
	 * 
	 * @param map input
	 * @return a collection of all values inside this map
	 */
	public static Vector getValues(Map map) {
		Vector res = new Vector();
		if (map == null) return res;
        Iterator keys = map.keySet().iterator();
        while(keys.hasNext()) {
			Object key = keys.next();
			Object val = map.get(key);
			if (val != null && val instanceof Collection)
				res.addAll((Collection)val);
			else if (val != null)
				res.addElement(val);			
		}		
		return res;
	}

    /**
     * Test if any keys in the map have values
     * 
     * @param map
     * @return
     */
    public static boolean isEmpty(Map map) {
        Iterator values = map.values().iterator();
        while (values.hasNext()) {
            final Object val = values.next();
            if (val != null || !(val instanceof Collection) || !((Collection)val).isEmpty())
                return false;
        }
        return true;
    }
	
	/**
	 * Returns the number of values associated with a key
	 * 
	 * @param map a particular map to be used
	 * @param key the key, whose values we want to count
	 * @return the number of values for the key
	 */
	public static int getNumValuesFor(Map map, Object key) {
		Object o = map.get(key);
		if (o == null)
			return 0;
		if (o instanceof Collection)
			return ((Collection)o).size();
		return 1;
	}
	
} //end MultiValueMap
