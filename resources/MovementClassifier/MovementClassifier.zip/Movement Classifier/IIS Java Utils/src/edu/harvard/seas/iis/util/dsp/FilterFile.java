package edu.harvard.seas.iis.util.dsp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.LinkedList;

import edu.harvard.seas.iis.util.io.FileManipulation;

public class FilterFile {

	public FilterFile() {
	}

	public void filter(double[] coefficients, BufferedReader input,
			Writer output, int numColsToFilter, int numOtherCols)
			throws IOException {

		// initialize filters and queues
		LowPassFilter[] filters = new LowPassFilter[numColsToFilter];
		// Butterworth[] filters = new Butterworth[numColsToFilter];
		LinkedList[] queues = new LinkedList[numOtherCols];
		for (int i = 0; i < numColsToFilter; i++)
			// filters[i] = new Butterworth();
			filters[i] = new LowPassFilter(coefficients);
		for (int i = 0; i < numOtherCols; i++)
			queues[i] = new LinkedList<String>();
		boolean ready = false;

		String nextLine = input.readLine();
		String cur = null;
		int tokenCount = 0;
		String nextToken;
		while (nextLine != null) {
			tokenCount = 0;
			while (nextLine.length() > 0) {
				if (nextLine.indexOf("\t") >= 0) {
					nextToken = nextLine.substring(0, nextLine.indexOf("\t"));
					nextLine = nextLine.substring(nextLine.indexOf("\t") + 1);
				} else {
					nextToken = nextLine;
					nextLine = "";
				}

				if (tokenCount < numColsToFilter) {
					cur = ""
							+ filters[tokenCount].onlineFilter(Double
									.parseDouble(nextToken));
					// we are ready once the filter starts returning stuff
					if (!"".equals(cur))
						ready = true;
				} else {
					if (nextToken == null)
						nextToken = "";
					queues[tokenCount - numColsToFilter].add(nextToken);
					if (ready)
						cur = (String) queues[tokenCount - numColsToFilter]
								.removeFirst();
				}
				// if we are ready, then we should start outputting stuff
				if (ready)
					output.write(cur + "\t");

				tokenCount++;
			}
			if (ready)
				output.write("\n");
			nextLine = input.readLine();
		}
	}

	public File filterFile(File in, double[] coefficients, int numColsToFilter,
			int numOtherCols, String outputFileSuffix) throws IOException {

		File outputFile = FileManipulation.injectSuffixIntoFileName(in,
				outputFileSuffix);
		System.out.println("About to filter " + in + " to\n  " + outputFile);

		BufferedReader reader = new BufferedReader(new FileReader(in));
		BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

		filter(coefficients, reader, writer, numColsToFilter, numOtherCols);

		writer.flush();
		writer.close();

		return outputFile;
	}

	public void filterFiles(File[] inputFiles, double[] coefficients,
			int numColsToFilter, int numOtherCols, String outputFileSuffix)
			throws IOException {
		for (File in : inputFiles)
			filterFile(in, coefficients, numColsToFilter, numOtherCols,
					outputFileSuffix);
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		double[] firPoint5To50Hz_409HzSampleRate = new double[] { -0.0005,
				-0.0001, -0.0000, -0.0004, -0.0010, -0.0014, -0.0013, -0.0006,
				-0.0000, -0.0002, -0.0013, -0.0026, -0.0032, -0.0024, -0.0007,
				0.0003, -0.0008, -0.0036, -0.0061, -0.0062, -0.0034, 0.0001,
				0.0009, -0.0025, -0.0082, -0.0117, -0.0096, -0.0029, 0.0028,
				0.0019, -0.0064, -0.0163, -0.0193, -0.0116, 0.0017, 0.0094,
				0.0031, -0.0148, -0.0306, -0.0297, -0.0090, 0.0174, 0.0263,
				0.0039, -0.0397, -0.0718, -0.0558, 0.0226, 0.1406, 0.2468,
				0.2894, 0.2468, 0.1406, 0.0226, -0.0558, -0.0718, -0.0397,
				0.0039, 0.0263, 0.0174, -0.0090, -0.0297, -0.0306, -0.0148,
				0.0031, 0.0094, 0.0017, -0.0116, -0.0193, -0.0163, -0.0064,
				0.0019, 0.0028, -0.0029, -0.0096, -0.0117, -0.0082, -0.0025,
				0.0009, 0.0001, -0.0034, -0.0062, -0.0061, -0.0036, -0.0008,
				0.0003, -0.0007, -0.0024, -0.0032, -0.0026, -0.0013, -0.0002,
				-0.0000, -0.0006, -0.0013, -0.0014, -0.0010, -0.0004, -0.0000,
				-0.0001, -0.0005 };
		// settings for a 50Hz low pass filter
		// double[] filterCoefficients = LowPassFilter.ner(50.0, 0.0488, .01,
		// 150);
		// settings for a 15Hz low pass filter with sampling rate of 409Hz
		double[] filterCoefficients = LowPassFilter.ner(50.0, 0.0735, .01,
				150);

		//filterCoefficients = firPoint5To50Hz_409HzSampleRate;
		FilterFile filter = new FilterFile();
		File[] in = FileManipulation.getUserSpecifiedFilesForReading();
		filter.filterFiles(in, filterCoefficients, 32, 1, "-NERfilter-15Hz");
	}

}
