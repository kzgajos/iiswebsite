/*
 * Created on Feb 2, 2005
 */
package edu.harvard.seas.iis.util.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

import edu.harvard.seas.iis.util.Logger;

/**
 * @author kgajos
 */
public class MapUtils {

    public static Object findFirstKeyForValue(Map map, Object value) {
        if (map == null || value == null || !map.containsValue(value))
            return null;
        Iterator it = map.keySet().iterator();
        Object key;
        while (it.hasNext()) {
            key = it.next();
            try {
                if (value.equals(map.get(key)))
                    return key;
                // that's in case equals throws exceptions
            } catch (Exception ex) {
            }
        }
        Logger
                .log(Logger.WARNING,
                        "The value is reportedly somewhere in the map but could not find a key for it!");
        return null;
    }

    public static String prettyPrintMap(Map map) {
        String res = "";
        ArrayList keys = new ArrayList(map.keySet());
        Collections.sort(keys);
        for (Object key : keys)
            res += key + ": " + map.get(key) + "\n";
        return res;
    }

}
