/*
 * Created on May 12, 2005
 */
package edu.harvard.seas.iis.util.collections;

import java.util.Hashtable;

/**
 * @author kgajos
 * 
 * A reverse index for an array of objects -- given an array it builds a reverse
 * mapping that lets you lookup the object's position within the array.
 * 
 * At the moment it is assumed that objects are unique within each array.
 * 
 * The objects have to implement hashCode() and equals()
 */
public class ReverseIndex {

	protected Hashtable index;
	
	/**
	 * 
	 */
	public ReverseIndex(Object[] in) {
		buildIndex(in);
	}
	
	protected void buildIndex(Object[] in) {
		index = new Hashtable();
		for(int i=0; i<in.length; i++)
			index.put(in[i], new Integer(i));
	}

	/**
	 * Returns the location of the given object in the original array; 
	 * 
	 * @param o object to be looked up
	 * @return its position in the original array or -1 if not found
	 */
	public int getLocation(Object o) {
		if (index == null)
			return -1;
		Object res = index.get(o);
		if (res == null)
			return -1;
		return ((Integer)res).intValue();
	}
}
