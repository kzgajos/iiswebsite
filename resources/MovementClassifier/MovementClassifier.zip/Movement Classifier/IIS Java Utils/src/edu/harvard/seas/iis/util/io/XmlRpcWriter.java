/*
 * Created on Jul 20, 2007
 */
package edu.harvard.seas.iis.util.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;

import javax.swing.JFileChooser;

import redstone.xmlrpc.XmlRpcException;
import redstone.xmlrpc.XmlRpcSerializer;
import redstone.xmlrpc.serializers.BooleanArraySerializer;
import redstone.xmlrpc.serializers.CollectionSerializer;
import redstone.xmlrpc.serializers.DoubleArraySerializer;
import redstone.xmlrpc.serializers.FloatArraySerializer;
import redstone.xmlrpc.serializers.IntArraySerializer;
import redstone.xmlrpc.serializers.ListSerializer;
import redstone.xmlrpc.serializers.MapSerializer;
import redstone.xmlrpc.serializers.MouseEventSerializer;
import redstone.xmlrpc.serializers.ObjectArraySerializer;
import redstone.xmlrpc.serializers.PointSerializer;
import redstone.xmlrpc.serializers.SerializableToMapSerializer;

public class XmlRpcWriter {

    protected Writer writer;

    protected XmlRpcSerializer serializer;

    public XmlRpcWriter(Writer writer) {
        this.writer = writer;
        initSerializer();
    }

    public XmlRpcWriter(File file, boolean append) throws IOException {
        this.writer = new FileWriter(file, append);
        initSerializer();
    }

    public static XmlRpcWriter createWriterFromUserSpecifiedFile(boolean append) {
        JFileChooser chooser = new JFileChooser();

        int retVal = chooser.showSaveDialog(null);
        if (retVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                return new XmlRpcWriter(file, append);
            } catch (IOException e) {
                return null;
            }
        }
        return null;
    }

    protected void initSerializer() {
        serializer = new XmlRpcSerializer();
        serializer.addCustomSerializer(new MapSerializer());
        serializer.addCustomSerializer(new BooleanArraySerializer());
        serializer.addCustomSerializer(new CollectionSerializer());
        serializer.addCustomSerializer(new FloatArraySerializer());
        serializer.addCustomSerializer(new ObjectArraySerializer());
        serializer.addCustomSerializer(new IntArraySerializer());
        serializer.addCustomSerializer(new DoubleArraySerializer());
        serializer.addCustomSerializer(new ListSerializer());
        serializer.addCustomSerializer(new PointSerializer());
        serializer.addCustomSerializer(new MouseEventSerializer());
        serializer.addCustomSerializer(new SerializableToMapSerializer());
    }

    public void write(Object o) throws XmlRpcException, IOException {
        serializer.serialize(o, writer);
        writer.flush();
    }

    /**
     * Allows raw text to be written to the stream
     * 
     * @param str
     * @throws IOException
     */
    public void writeRaw(String str) throws IOException {
        writer.write(str);
        writer.flush();
    }

    public void close() throws IOException {
        writer.flush();
        writer.close();
    }

    public static void main(String[] args) throws XmlRpcException, IOException {
        XmlRpcWriter w = createWriterFromUserSpecifiedFile(false);
        HashMap<String, Double> map = new HashMap<String, Double>();
        map.put("foo", 1.0);
        map.put("boo", 2.0);
        Object[] array = new Object[] { map, (HashMap) map.clone(), new Foo() };
        w.write(array);
        w.close();
    }

}
