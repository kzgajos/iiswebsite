package edu.harvard.seas.iis.util.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.JFileChooser;

import redstone.xmlrpc.XmlRpcException;

public class FileManipulation {

	public static void saveStringToFile(String data, File file, boolean append)
			throws IOException {
		FileWriter writer = new FileWriter(file, append);
		writer.write(data);
		writer.close();
	}

	public static String readStringFromFile(File file) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String nextLine = reader.readLine();
		String res = "";
		while (nextLine != null) {
			res += nextLine + "\n";
			nextLine = reader.readLine();
		}
		return res;
	}

	public static String readStringFromUserSpecifiedFile() throws IOException {
		JFileChooser chooser = new JFileChooser();

		int retVal = chooser.showOpenDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return readStringFromFile(chooser.getSelectedFile());
		}
		return null;
	}

	public static Object readXmlRpcObjectFromFile(File file)
			throws FileNotFoundException {
		XmlRpcReader reader = new XmlRpcReader(file);
		return reader.readObject();
	}

	public static Object readXmlRpcObjectFromUserSpecifiedFile()
			throws IOException {
		JFileChooser chooser = new JFileChooser();

		int retVal = chooser.showOpenDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return readXmlRpcObjectFromFile(chooser.getSelectedFile());
		}
		return null;
	}

	public static File getUserSpecifiedFileForSaving() {
		JFileChooser chooser = new JFileChooser();

		int retVal = chooser.showSaveDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return (chooser.getSelectedFile());
		}
		return null;
	}

	public static File getUserSpecifiedDirForReading() {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		int retVal = chooser.showOpenDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return (chooser.getSelectedFile());
		}
		return null;
	}

	public static File getUserSpecifiedFileForReading() {
		return getUserSpecifiedFileForReading(null);
	}

	public static File getUserSpecifiedFileForReading(File curDir) {
		JFileChooser chooser = new JFileChooser();
		if (curDir != null && curDir.exists())
			chooser.setCurrentDirectory(curDir);

		int retVal = chooser.showOpenDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return (chooser.getSelectedFile());
		}
		return null;
	}

	public static File[] getUserSpecifiedFilesForReading() {
		return getUserSpecifiedFilesForReading(null);
	}

	public static File[] getUserSpecifiedFilesForReading(File curDir) {
		JFileChooser chooser = new JFileChooser();
		if (curDir != null && curDir.exists())
			chooser.setCurrentDirectory(curDir);
		chooser.setMultiSelectionEnabled(true);

		int retVal = chooser.showOpenDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return (chooser.getSelectedFiles());
		}
		return null;
	}

	public static boolean saveObjectToUserSpecifiedFile(Serializable o)
			throws IOException {
		JFileChooser chooser = new JFileChooser();

		int retVal = chooser.showSaveDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			File file = chooser.getSelectedFile();
			return saveObjectToFile(chooser, file);
		}
		return false;
	}

	public static boolean saveObjectToFile(Serializable o, File file)
			throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(o);
		oos.close();
		fos.close();
		return true;
	}

	public static Serializable readObjectFromFile(File file)
			throws IOException, ClassNotFoundException {
		Serializable res = null;
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		res = (Serializable) ois.readObject();
		ois.close();
		fis.close();
		return res;
	}

	public static boolean saveObjectAsXmlRpcFile(File file, Object o)
			throws IOException, XmlRpcException {
		XmlRpcWriter writer = new XmlRpcWriter(file, false);
		writer.write(o);
		writer.close();
		return true;
	}

	public static boolean saveObjectAsXmlRpcUserSpecifiedFile(Object o)
			throws IOException, XmlRpcException {
		JFileChooser chooser = new JFileChooser();

		int retVal = chooser.showSaveDialog(null);
		if (retVal == JFileChooser.APPROVE_OPTION) {
			return saveObjectAsXmlRpcFile(chooser.getSelectedFile(), o);
		}
		return false;
	}

	public static String injectSuffixIntoFileName(String originalFileName,
			String suffix) {
		String outputFileName = originalFileName;
		if (outputFileName.lastIndexOf(".") > outputFileName
				.lastIndexOf(File.pathSeparator))
			outputFileName = outputFileName.substring(0, outputFileName
					.lastIndexOf("."))
					+ suffix
					+ outputFileName.substring(outputFileName.lastIndexOf("."));
		else
			outputFileName += suffix;
		return outputFileName;
	}

	public static File injectSuffixIntoFileName(File originalFile, String suffix) {
		String outputFileName = originalFile.getPath();
		if (outputFileName.lastIndexOf(".") > outputFileName
				.lastIndexOf(File.pathSeparator))
			outputFileName = outputFileName.substring(0, outputFileName
					.lastIndexOf("."))
					+ suffix
					+ outputFileName.substring(outputFileName.lastIndexOf("."));
		else
			outputFileName += suffix;
		return new File(outputFileName);
	}

}
