/*
 * Created on Dec 11, 2006
 */
package edu.harvard.seas.iis.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;

public class ReflectionUtils {

    /**
     * Returns the value of the static field of a given name from a given class;
     * if the field is not defined in that class, the method will inspect all of
     * the ancestors of the class (though not interfaces)
     * 
     * @param fieldName
     * @param c
     * @param defaultValue
     *            the value to be returned if actual value cannot be retrieved
     *            for some reason
     * @return value of the field or defaultValue if there is any problem
     *         (security exception, the field is not declared in the class or
     *         any of it ancestors, etc)
     */
    public static Object getStaticFieldValueForClass(String fieldName, Class c,
            Object defaultValue) {
        try {
            if (c == null)
                return defaultValue;
            Field field = null;
            try {
                field = c.getDeclaredField(fieldName);
            } catch (NoSuchFieldException ex) {
            }
            if (field != null)
                return field.get(null);
            return getStaticFieldValueForClass(fieldName, c.getSuperclass(),
                    defaultValue);
        } catch (Exception e) {
            Logger.log(Logger.WARNING, "Could not get field named " + fieldName
                    + " from class " + c.getName() + " because: " + e);
        }
        return defaultValue;
    }

    /**
     * Returns all interfaces implemented by a given class or its parents
     * 
     * @param c
     * @return an array of interfaces
     */
    public static Class[] getInterfaces(Class c) {
        ArrayList list = new ArrayList();
        Class curClass = c;
        // go through the inheritance hierarchy and pull out all the
        // interfaces o or its ancestors implement
        while (curClass != null) {
            list.addAll(Arrays.asList(curClass.getInterfaces()));
            curClass = curClass.getSuperclass();
        }
        Class[] res = new Class[list.size()];
        return (Class[]) list.toArray(res);
    }

}
