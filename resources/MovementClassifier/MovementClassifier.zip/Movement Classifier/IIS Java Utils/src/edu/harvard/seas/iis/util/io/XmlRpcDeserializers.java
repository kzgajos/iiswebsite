package edu.harvard.seas.iis.util.io;

import java.awt.Point;
import java.util.Map;

public class XmlRpcDeserializers {

	public static Point getPointFromMap(Map map) {
		return new Point(((Number) map.get("x")).intValue(), ((Integer) map
				.get("y")).intValue());
	}

}
