/*
 * Created on May 14, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package edu.harvard.seas.iis.util.dsp;

import java.util.Arrays;

public class FIRFilter {

	// filter parameters
	protected double[] h;

	protected int length;

	protected double[] delayLine;

	protected int count = 0;

	public FIRFilter(double[] h) {
		this.h = h;
		length = h.length;
		delayLine = new double[length];
	}

	/**
	 * A method for off-line processing of an entire input
	 * 
	 * @param input
	 * @return
	 */
	public double[] getFilteredOutput(double[] input) {
		double[] res = new double[input.length];
		for (int i = 0; i < input.length; i++)
			res[i] = getOutputSample(input[i]);
		return res;
	}

	public double getOutputSample(double inputSample) {
		delayLine[count] = inputSample;
		double result = 0.0;
		int index = count;
		for (int i = 0; i < length; i++) {
			result += h[i] * delayLine[index--];
			if (index < 0)
				index = length - 1;
		}
		if (++count >= length)
			count = 0;
		return result;
	}

	/**
	 * Clears the filter in preparation for processing new input
	 */
	public void clear() {
		Arrays.fill(delayLine, 0);
		count = 0;
	}

	public static void main(String[] args) {
		FIRFilter filter = new FIRFilter(filterCoefficients50HzSampleRate);
		double[] data = new double[1000];
		for (int i = 0; i < data.length; i++) {
			data[i] = Math.sin((double) i / 50.0);
			// if (i % 10 == 5)
			data[i] += 0.1 * Math.random();
		}
		double[] out = filter.getFilteredOutput(data);
		for (int i = 0; i < data.length; i++) {
			System.out.println(data[i] + "\t" + out[i]);
		}
	}

	protected static double[] filterCoefficients50HzSampleRate = new double[] {
			0.000962465, -0.002093352, 0.001748717, 0.001356665, -0.006027026,
			0.007251125, 1.49368E-05, -0.013589679, 0.021257322, -0.009088796,
			-0.022821374, 0.051366325, -0.040804712, -0.030428285, 0.146393805,
			-0.255362718, 1.3, -0.255362718, 0.146393805, -0.030428285,
			-0.040804712, 0.051366325, -0.022821374, -0.009088796, 0.021257322,
			-0.013589679, 1.49368E-05, 0.007251125, -0.006027026, 0.001356665,
			0.001748717, -0.002093352, 0.000962465 };
}
