/*
 * Created on Feb 5, 2007
 */
package edu.harvard.seas.iis.util.stats;

import java.util.Collection;
import java.util.List;

public class BasicStats {

	public static double getR2(double[] x, double[] y) {
		double meanX = getMean(x), meanY = getMean(y);
		double nom = 0, denom1 = 0, denom2 = 0;
		for (int i = 0; i < Math.min(x.length, y.length); i++) {
			nom += (x[i] - meanX) * (y[i] - meanY);
			denom1 += Math.pow(x[i] - meanX, 2);
			denom2 += Math.pow(y[i] - meanY, 2);
		}
		return Math.pow(nom, 2) / (denom1 * denom2);
	}

	public static double getR2(List<? extends Number> x,
			List<? extends Number> y) {
		double meanX = getMean(x), meanY = getMean(y);
		double nom = 0, denom1 = 0, denom2 = 0;
		for (int i = 0; i < Math.min(x.size(), y.size()); i++) {
			nom += (x.get(i).doubleValue() - meanX)
					* (y.get(i).doubleValue() - meanY);
			denom1 += Math.pow(x.get(i).doubleValue() - meanX, 2);
			denom2 += Math.pow(y.get(i).doubleValue() - meanY, 2);
		}
		return Math.pow(nom, 2) / (denom1 * denom2);
	}

	public static double getVariance(Collection<? extends Number> data) {
		double mean = getMean(data);
		double res = 0;
		for (Number n : data)
			res += Math.pow(mean - n.doubleValue(), 2);
		return res / (double) data.size();
	}

	public static double getVariance(double[] data) {
		double mean = getMean(data);
		double res = 0;
		for (Number n : data)
			res += Math.pow(mean - n.doubleValue(), 2);
		return res / (double) data.length;
	}

	public static double getMean(Collection<? extends Number> data) {
		return getSum(data) / (double) data.size();
	}

	public static double getMean(double[] data) {
		return getSum(data) / (double) data.length;
	}

	public static double getSum(Collection<? extends Number> data) {
		double res = 0;
		for (Number n : data)
			res += n.doubleValue();
		return res;
	}

	public static double getSum(double[] data) {
		double res = 0;
		for (Number n : data)
			res += n.doubleValue();
		return res;
	}

}
