package edu.harvard.seas.iis.util;

import java.util.StringTokenizer;
import java.util.Vector;

public class TokenizedStringVector extends Vector<String> {

	public TokenizedStringVector(String s, String delimiters) {
		StringTokenizer tokenizer = new StringTokenizer(s, delimiters);
		while (tokenizer.hasMoreTokens())
			add(tokenizer.nextToken());
	}

	public TokenizedStringVector(String s) {
		StringTokenizer tokenizer = new StringTokenizer(s);
		while (tokenizer.hasMoreTokens())
			add(tokenizer.nextToken());
	}

	public int getAsInt(int i) {
		return Integer.parseInt(get(i));
	}

	public double getAsDouble(int i) {
		return Double.parseDouble(get(i));
	}

	public long getAsLong(int i) {
		return Long.parseLong(get(i));
	}

	public float getAsFloat(int i) {
		return Float.parseFloat(get(i));
	}

	/**
	 * Gets an element indexed from the end of the vector rather than beginning
	 * (i = 0 is the last element)
	 * 
	 * @param i
	 * @return
	 */
	public String getNthFromLast(int i) {
		return get(size() - 1 - i);
	}

	public int getNthFromLastAsInt(int i) {
		return Integer.parseInt(getNthFromLast(i));
	}

	public double getNthFromLastAsDouble(int i) {
		return Double.parseDouble(getNthFromLast(i));
	}

	public long getNthFromLastAsLong(int i) {
		return Long.parseLong(getNthFromLast(i));
	}

	public float getNthFromLastAsFloat(int i) {
		return Float.parseFloat(getNthFromLast(i));
	}
}
