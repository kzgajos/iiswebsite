package edu.harvard.seas.iis.util.dsp;

public class Butterworth {

	protected int cnt = 0;
	protected boolean ready = false;

	public Butterworth() {
	}

	public Double onlineFilter(double datum) {
		Double res = null;
		double temp = filterNext(datum);

		if (cnt >= NZEROS / 2)
			res = temp;

		cnt++;
		return res;
	}

	protected int NZEROS = 10;
	protected int NPOLES = 10;
	protected double GAIN = 8.200642507e+04;

	protected double xv[] = new double[NZEROS + 1];
	protected double yv[] = new double[NPOLES + 1];

	protected double filterNext(double input) {
		xv[0] = xv[1];
		xv[1] = xv[2];
		xv[2] = xv[3];
		xv[3] = xv[4];
		xv[4] = xv[5];
		xv[5] = xv[6];
		xv[6] = xv[7];
		xv[7] = xv[8];
		xv[8] = xv[9];
		xv[9] = xv[10];
		xv[10] = input / GAIN;
		yv[0] = yv[1];
		yv[1] = yv[2];
		yv[2] = yv[3];
		yv[3] = yv[4];
		yv[4] = yv[5];
		yv[5] = yv[6];
		yv[6] = yv[7];
		yv[7] = yv[8];
		yv[8] = yv[9];
		yv[9] = yv[10];
		yv[10] = (xv[10] - xv[0]) + 5 * (xv[2] - xv[8]) + 10 * (xv[6] - xv[4])
				+ (-0.4854421343 * yv[0]) + (5.1995180834 * yv[1])
				+ (-25.0819564080 * yv[2]) + (71.7584887270 * yv[3])
				+ (-134.8366300400 * yv[4]) + (173.8737252100 * yv[5])
				+ (-155.8257739600 * yv[6]) + (95.8344351650 * yv[7])
				+ (-38.7077020680 * yv[8]) + (9.2713374207 * yv[9]);

		return yv[10];

	}
}
