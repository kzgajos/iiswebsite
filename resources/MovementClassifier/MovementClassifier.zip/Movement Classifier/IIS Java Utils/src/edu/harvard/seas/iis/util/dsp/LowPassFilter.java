package edu.harvard.seas.iis.util.dsp;

import java.util.Arrays;

/**
 * Implementation of NER and NERD filters from
 * 
 * Kaiser, J. F. and Reed, W. A. (1977). Data smoothing using low-pass digital
 * filters. Review of Scientific Instruments, 48(11):1447-1457.
 * 
 * @author kgajos
 * 
 */
public class LowPassFilter {

	protected double[] buffer;
	// points to the location of the oldest element in the buffer
	protected int offset;
	protected boolean ready = false;
	protected double[] coefficients;
	
	public LowPassFilter(double[] coefficients) {
		buffer = new double[coefficients.length];
		offset = 0;
		this.coefficients = coefficients;
	}

	public Double onlineFilter(double datum) {
		Double res = null;
		if (!ready && offset == 0)
			// fill the buffer with the first data point
			Arrays.fill(buffer, datum);

		buffer[offset] = datum;
		// we are ready as soon as we fill up half the buffer
		if (!ready && offset >= buffer.length / 2)
			ready = true;

		offset = (offset + 1) % buffer.length;

		if (ready)
			res = LowPassFilter.filterSingle(buffer, coefficients, offset);

		return res;
	}

	/**
	 * runs a filter with given coefficients (no time shifting)
	 * 
	 * @param data
	 *            data to be filtered
	 * @param coefficients
	 *            filter coefficients (from the ner filter)
	 * @return filtered data (same size as the original)
	 */
	public static double[] filter(double[] data, double[] coefficients) {
		double[] res = new double[data.length];
		int filterSpan = (int) (coefficients.length / 2);
		for (int i = 0; i < data.length; i++)
			for (int j = -filterSpan; j <= coefficients.length - filterSpan - 1; j++)
				res[i] += coefficients[j + filterSpan]
						* getArrayElement(data, i + j);
		return res;
	}

	/**
	 * assumes that the length of data and the coefficients array is the same
	 * and computes the filtered value for the middle element in the array
	 * 
	 * 
	 * @param data
	 * @param coefficients
	 * @return
	 */
	public static double filterSingle(double[] data, double[] coefficients,
			int offset) {
		double res = 0;
		for (int j = 0; j < coefficients.length; j++)
			res += coefficients[j] * data[(j + offset) % data.length];
		return res;
	}

	/**
	 * runs a differentiating filter (that also does some smoothing -- otherwise
	 * differentiating noisy data amplifies noise)
	 * 
	 * @param data
	 *            input time series
	 * @param coefficients
	 *            filter coefficients (from the nerd filter)
	 * @param timeUnitsPerSample
	 *            sampling interval -- important to make sure that the output of
	 *            the filter is in correct units (e.g., if input is speed with
	 *            100 samples per second and the output is to be in m/s^2, then
	 *            this param should be 0.01)
	 * @return
	 */
	public static double[] differentiatingFilter(double[] data,
			double[] coefficients, double timeUnitsPerSample) {
		double[] res = new double[data.length];
		for (int i = 1; i < data.length; i++) {
			for (int j = 0; j < coefficients.length; j++)
				res[i] += coefficients[j]
						* (getArrayElement(data, i - j) - getArrayElement(data,
								i - j - 1));
			// make sure that we get the right time unit for the derivative
			res[i] /= timeUnitsPerSample;
		}
		return res;
	}

	/**
	 * returns the array element at the given index; if index is smaller than 0
	 * or lager than the last index in the array, it returns the first or the
	 * last element, respectively
	 * 
	 * @param data
	 * @param index
	 * @return
	 */
	protected static double getArrayElement(double[] data, int index) {
		if (index < 0)
			return data[0];
		else if (index >= data.length)
			return data[data.length - 1];
		else
			return data[index];
	}

	/**
	 * generate coefficients for a smoothing filter (nearly-equal ripple (NER)
	 * filter)
	 * 
	 * @param al
	 *            stopband loss in db
	 * @param be
	 *            relative location of stopband; 0 < be < 1 and be =
	 *            2*stopband_frequency / sampling_frequency
	 * @param de
	 *            relative width of transition band; 0 < de < 1
	 * @param maxNumCoefs
	 *            maximum number of coefficients to generate (the paper suggests
	 *            150)
	 * @return
	 */
	public static double[] ner(double al, double be, double de, int maxNumCoefs) {

		double et = 0.0;
		double fia = 0.0;
		double e = 0.0;
		int k = 0;
		double fnp = 0.0;
		double ge = 0.0;
		double fk = 0.0;
		double gk = 0.0;
		int np = 0;
		fk = 1.8445;
		if (al >= 21)
			fk = 0.13927 * (al - 7.95);

		et = 0.58417 * ((double) Math.pow((al - 21.0), 0.4)) + 0.07886
				* (al - 21.0);
		if (al < 21.0)
			et = 0.0;
		if (al > 50)
			et = 0.1102 * (al - 8.7);
		np = (int) ((fk / (2.0 * de)) + 0.75);
		if (np >= maxNumCoefs)
			np = maxNumCoefs - 1;

		double[] bk = new double[np + 1];
		fnp = (double) np;
		fia = ino(et);
		for (k = 1; k <= np; k++) {
			gk = Math.PI * (double) (k);
			ge = et
					* (double) Math.sqrt((double) (1.0 - ((double) Math.pow(
							((double) (k) / fnp), 2))));
			e = ino(ge);
			bk[k] = ((double) Math.sin((double) (be * gk)) / gk) * (e / fia);
		}
		bk[np] = bk[np] / 2.0;
		bk[0] = be;
		return symmetrifyCoefficients(bk, false);
	}

	/**
	 * Generate coefficients for a differentiating filter
	 * 
	 * @param al
	 *            stopband loss in db
	 * @param be
	 *            relative location of stopband; 0 < be < 1 and be =
	 *            2*stopband_frequency / sampling_frequency
	 * @param de
	 *            relative width of transition band; 0 < de < 1
	 * @param maxNumCoefs
	 *            maximum number of coefficients to generate (the paper suggests
	 *            150)
	 * @return
	 */
	public static double[] nerd(double al, double be, double de, int maxNumCoefs) {
		double gp = 0.0;
		double et = 0.0;
		double th = 0.0;
		double e = 0.0;
		double fia = 0.0;
		double flk = 0.0;
		int k = 0;
		double fnp = 0.0;
		double ge = 0.0;
		double cn = 0.0;
		double fk = 0.0;
		int np = 0;

		fk = 1.8445;
		if (al >= 21)
			fk = 0.13927 * (al - 7.95);
		et = 0.58417 * ((double) Math.pow((al - 21.0), 0.4)) + 0.07886
				* (al - 21.0);
		if (al < 21)
			et = 0.0;
		if (al > 50)
			et = (0.1102 * (al - 8.7));
		np = (int) ((fk / (2.0 * de)) + 0.75);
		if (np >= maxNumCoefs)
			np = maxNumCoefs - 1;

		double[] ck = new double[np + 1];
		fnp = (double) np;
		gp = (be * Math.PI);
		fia = ino(et);

		for (k = 1; k <= np; k++) {
			flk = (double) ((2 * k) - 1) / 2.0;
			ge = et
					* (double) Math.sqrt((double) (1.0 - ((double) Math.pow(
							(flk / fnp), 2))));
			e = ino(ge);
			th = (flk * gp);
			cn = (-gp * Math.cos(th) + Math.sin(th) / flk) * e;
			ck[k - 1] = cn / ((fia * Math.PI) * flk);
		}

		return ck;
	}

	private static double ino(double x) {
		double ds = 1.0;
		double d = 0.0;
		double s = 1.0;
		boolean done = false;
		while (!done) {
			d = d + 2.0;
			ds = ((ds * x) * x) / (d * d);
			s = (s + ds);
			if (ds <= (0.2e-8 * s))
				done = true;
		}
		return s;
	}

	protected static double[] symmetrifyCoefficients(double[] in, boolean even) {
		double[] out = new double[(even ? 2 * in.length : 2 * in.length - 1)];
		int midpoint = in.length - 1;
		for (int i = 0; i < in.length; i++) {
			out[midpoint - i] = in[i];
			if (even)
				out[midpoint + i + 1] = in[i];
			else
				out[midpoint + i] = in[i];
		}
		return out;
	}

	public static void main(String args[]) {
		double[] coefs = ner(20, .05, .005, 150);
		double[] coefsd = nerd(5, .8, .2, 150);
		/*
		 * System.out.println(coefsMaxFlat.length + "\n" +
		 * PrettyPrint.toPrettyString(coefsMaxFlat, "\n"));
		 */
		double[] data = new double[1000];
		for (int i = 0; i < data.length; i++) {
			data[i] = Math.sin((double) i / 20.0);
			// if (i % 10 == 5)
			data[i] += 0.3 * Math.random() - .15;
		}
		double[] out = filter(data, coefs);
		double[] outdsimple = new double[out.length];
		for (int i = 1; i < out.length; i++) {
			outdsimple[i] = out[i] - out[i - 1];
		}
	}

}
