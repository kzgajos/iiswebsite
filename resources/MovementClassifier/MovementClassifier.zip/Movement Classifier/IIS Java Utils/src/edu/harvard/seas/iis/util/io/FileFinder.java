/*
 * Created on Feb 12, 2005
 */
package edu.harvard.seas.iis.util.io;

import java.io.File;
import java.net.URL;

/**
 * @author kgajos
 */
public class FileFinder {

    public static File getFileInClasspath(String name) {
        File res = null;
        URL resource = getURLInClasspath(name);
        if (resource != null)
            res = new File(resource.getFile());
        return res;
    }
    
    public static URL getURLInClasspath(String name) {
        if (name == null)
            return null;
        URL res = FileFinder.class.getClassLoader().getResource(name);
        return res;
    }
    
}
