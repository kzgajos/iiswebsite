/*
 * Created on Feb 27, 2005
 */
package edu.harvard.seas.iis.util.collections;

import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * @author kgajos
 */
public class CollectionUtils {

	/**
	 * Returns a vector that is a sum of the two collection passed as input
	 * 
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static <T> Vector<T> union(Collection<T> c1, Collection<T> c2) {
		Vector<T> res = new Vector<T>();
		res.addAll(c1);
		Iterator<T> it = c2.iterator();
		T cur;
		while (it.hasNext()) {
			cur = it.next();
			if (!res.contains(cur))
				res.addElement(cur);
		}
		return res;
	}

	/**
	 * Returns a vector that contains the intersection of the elements of the
	 * two collection passed as input
	 * 
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static <T> Vector<T> intersection(Collection<T> c1, Collection<T> c2) {
		Vector<T> res = new Vector<T>();
		Iterator<T> it = c1.iterator();
		T cur;
		while (it.hasNext()) {
			cur = it.next();
			if (!res.contains(cur) && c2.contains(cur))
				res.addElement(cur);
		}
		return res;
	}

	public static <T> List<T> getRandomSubset(List<T> data, int subsetSize) {
		Collections.shuffle(data);
		Vector<T> res = new Vector<T>(data);
		return res.subList(0, subsetSize);
	}

	/**
	 * Takes a collection of objects and returns a Hashtable giving counts for
	 * how many times each object appears in the collection
	 * 
	 * @param <K>
	 * @param c
	 * @return
	 */
	public static <K> Hashtable<K, Integer> getCounts(Collection<K> c) {
		Hashtable<K, Integer> counts = new Hashtable<K, Integer>();
		for (K o : c) {
			if (!counts.containsKey(o))
				counts.put(o, 1);
			else
				counts.put(o, counts.get(o) + 1);
		}
		return counts;
	}

	/**
	 * Returns the most frequent element in a collection. If there is a tie, it
	 * returns all elements tied for the first place.
	 * 
	 * @param <K>
	 * @param c
	 * @return
	 */
	public static <K> Object[] getMostCommonElements(Collection<K> c) {
		Hashtable<K, Integer> counts = getCounts(c);

		// first find what is the highest count
		int topCount = 0;
		int numOfTopCounts = 0;
		for (K o : counts.keySet()) {
			if (counts.get(o) > topCount) {
				topCount = counts.get(o);
				numOfTopCounts = 1;
			} else if (counts.get(o) == topCount)
				numOfTopCounts++;
		}

		// then extract all the elements with the highest count
		Object[] res = new Object[numOfTopCounts];
		int cnt = 0;
		for (K o : counts.keySet()) {
			if (counts.get(o) == topCount)
				res[cnt++] = o;
		}
		return res;
	}

}
