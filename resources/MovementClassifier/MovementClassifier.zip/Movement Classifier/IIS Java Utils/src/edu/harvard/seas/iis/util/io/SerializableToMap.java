package edu.harvard.seas.iis.util.io;

import java.util.Map;

public interface SerializableToMap {

	/**
	 * Returns a representation of this object as a map
	 * 
	 * @return
	 */
	public Map<String, Object> serializeToMap();

}
