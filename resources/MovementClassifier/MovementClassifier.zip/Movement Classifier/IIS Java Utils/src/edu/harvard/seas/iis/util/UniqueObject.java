/*
 * Created on Jun 22, 2004
 */
package edu.harvard.seas.iis.util;

import java.rmi.server.UID;


/**
 * @author kgajos
 */
public interface UniqueObject {

    /**
     * @return a unique ID for this object
     */
    public UID getUid();
    
}
