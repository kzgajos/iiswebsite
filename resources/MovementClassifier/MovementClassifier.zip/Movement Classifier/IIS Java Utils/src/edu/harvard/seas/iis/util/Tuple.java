/*
 * Created on Nov 25, 2005
 */
package edu.harvard.seas.iis.util;

import java.io.Serializable;
import java.util.Arrays;

public class Tuple implements Serializable {

	private static final long serialVersionUID = 1L;

	protected Object[] stuff;

	public Tuple(Object o1, Object o2) {
		stuff = new Object[] { o1, o2 };
	}

	public Tuple(Object o1, Object o2, Object o3) {
		stuff = new Object[] { o1, o2, o3 };
	}

	public Tuple(Object o1, Object o2, Object o3, Object o4) {
		stuff = new Object[] { o1, o2, o3, o4 };
	}

	public Object get(int i) {
		return stuff[i];
	}

	public int getInt(int i) {
		return (Integer) get(i);
	}
	
	public int size() {
		return stuff.length;
	}

	public int hashCode() {
		int res = 0;
		for (int i = 0; i < stuff.length; i++)
			res += stuff[i].hashCode();
		return res;
	}

	public boolean equals(Object o) {
		if (o == null || !(o instanceof Tuple))
			return false;
		return Arrays.equals(stuff, ((Tuple) o).stuff);
	}

	public String toString() {
		String res = "<" + stuff[0];
		for (int i = 1; i < stuff.length; i++)
			res += "," + stuff[i];
		return res + ">";
	}
}
