/*
 * Created on Jul 20, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package edu.harvard.seas.iis.util.io;

public class Foo {
    protected double var1 = 2.0;

    public double getVar1() {
        return var1;
    }
    /*
    public void setVar1(double var1) {
        this.var1 = var1;
    }
*/
}
