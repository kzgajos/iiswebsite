package edu.harvard.seas.iis.util;

import java.io.*;
import java.util.*;

public class Logger extends PrintStream {
  
  /***************
   *  CONSTANTS  *
   ***************/
  public static final int DEBUG = 0;
  public static final int INFO = 1;
  public static final int WARNING = 2;
  public static final int ERROR = 3;
  public static final int CRITICAL = 4;

  
  public static final String[] sLevelNames = { "DEBUG",
					       "INFO",
					       "WARNING",
					       "ERROR",
					       "CRITICAL" };

  /******************
   *  CONSTRUCTORS  *
   ******************/

  public Logger( OutputStream out ) {
    super( out );
    setLogLevel( INFO );
    idLevels = new Hashtable();
  }

  public Logger( OutputStream out, boolean autoFlush, int level ) {
    super( out, autoFlush );
    setLogLevel( level );
    idLevels = new Hashtable();
  }


  /*************
   *  METHODS  *
   *************/

  public void setLogLevel( int i ) {
    if ( i > CRITICAL ) { 
      i = CRITICAL;
    } else if ( i < DEBUG ) {
      i = DEBUG;
    }
    
    if ( defaultLogLevel != i ) {
      //System.out.println( "LOG LEVEL SET TO: " + sLevelNames[i] );
      defaultLogLevel = i;
    }
  }


  public int getLogLevel() {
    return defaultLogLevel;
  }


  /**
   * Tack on a flag so error log messages are easily seen.
   */
  public static String levelIndicator( int level ) {
    if ( level >= ERROR ) {
      return "** ";
    } else {
      return ""; // + level + " ";
    }
  }


  public static boolean logCheck( int lvl, int complvl ) {
    return ( ( lvl >= complvl ) || FORCE_LOGGING );
  }

  
  public void println( int level, String s ) {
    if ( logCheck( level, defaultLogLevel ) ) {
      super.println( levelIndicator( level ) + s );
    }
  }

  static public void printerr( int logLevel, String who, String s ) {
    // useful for subclasses to override, to redirect all output
    // somewhere else.
    if ( logCheck( logLevel, static_level ) ) {
      System.out.println( levelIndicator( logLevel ) + who + ": " + s );
    }
  }

  static public void log( int logLevel, String s ) {
    // if necessary, do a fast print so there is little system overhead.
    if ( FAST_LOGGING ) {
      printerr( logLevel, "[FAST LOG]", s );
      return;
    }

    // set up a temp stream to check so we can hunt down my caller.
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter( sw );
    Throwable t = new Throwable();
    t.printStackTrace( pw );
    pw.flush();
    
    String out;
    String x = sw.toString();

    // let's check for the first paren following something other than
    // a Logger method, and go for the following close paren.
    StringTokenizer st = new StringTokenizer( x, "\n\r\f" ); // split by lines
    String line = null;
    st.nextToken();  // skip first line
    while ( st.hasMoreTokens() ) {
      line = st.nextToken();
      if ( line.indexOf( "Logger" ) == -1 ) {
	break;
      }
      
      line = null;
    }
    
    if ( line == null ) {
      // couldn't get a good stack trace;
      printerr( logLevel, "unknown", s );
      return;
    }
    
    int b = line.indexOf( '(' );
    int e = line.indexOf( ')', b );

    if ( e == -1 || b == -1 ) {
      // couldn't get a good stack trace.
      printerr( logLevel, "unknown", s );
      return;
    }
    
    out = line.substring( b, e + 1 );

    if ( out.equals( "(Compiled Code)" ) ) {
      // instead, try to pull out the class name from the line
      b = line.indexOf( "at " ) + 2;
      
      // start looking through for last class portion
      String cls = null;
      while ( b != -1 ) {
	int b2 = b + 1 ;
	b = line.indexOf( '.', b2 );
	if ( b != -1 ) {
	  cls = line.substring( b2, b );
	}
      }
      out = "(" + cls + ")" ;
    }

    printerr ( logLevel, out, s );
  }

  static public void log( String s ) {
    Logger.log( DEBUG, s );
  }

  static public void setStaticLogLevel( int lvl ) {
    static_level = lvl;
  }


  /**
   * Dump a local stack trace to the screen.
   */
  public static void printLocalStack( String msg ) {
    System.out.println( "********* FAKE STACK TRACE *********" );
    
    new Exception( msg ).printStackTrace();
  }


  /***************
   *  VARIABLES  *
   ***************/

  static public boolean FAST_LOGGING = false;
  
  // if true, always print log messages regardless of level.
  static public boolean FORCE_LOGGING = false;
  
  // report anything equal to or above this level  
  int defaultLogLevel = INFO;
  Hashtable idLevels;

  static int static_level = DEBUG;
}
    
    

