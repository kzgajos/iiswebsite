/*
 * Created on May 14, 2004
 */
package edu.harvard.seas.iis.util.collections;
import java.util.ArrayList;
import java.util.List;


/**
 * @author kgajos
 * 
 * Some common utilities for manipulating lists
 */
public class ListUtils {
	
	/**
	 * Shuffles the elements of the list; it shuffles them in place. The
	 * returned list is actually the same object as the argument -- it is
	 * returned just for convenience.
	 * 
	 * @param list
	 *            a list whose elements are to be shuffled
	 * @return the same list with its elements in random order
	 */
	public static List shuffle(List list) {
		ArrayList temp = new ArrayList();
		// move all the elements from the input list to a temporary location
		while(!list.isEmpty())
			temp.add(list.remove(0));
		
		// rebuild the original list in random order
		while(!temp.isEmpty())
			list.add(temp.remove((int)(Math.random() * temp.size())));
		
		return list;
	}
	
	public static void main(String[] args) {
		ArrayList test = new ArrayList();
		test.add("a");
		test.add("b");
		test.add("c");
		shuffle(test);
	}
}