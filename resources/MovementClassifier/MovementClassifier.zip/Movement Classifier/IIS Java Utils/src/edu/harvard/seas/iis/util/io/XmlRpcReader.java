/*
 * Created on Jul 20, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package edu.harvard.seas.iis.util.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringBufferInputStream;

import javax.swing.JFileChooser;

import redstone.xmlrpc.XmlRpcParser;

public class XmlRpcReader {

    protected InputStream in;

    protected XmlRpcParser parser;

    public XmlRpcReader(InputStream in) {
        super();
        this.in = in;
        init();
    }

    public XmlRpcReader(File file) throws FileNotFoundException {
        in = new FileInputStream(file);
        init();
    }

    public XmlRpcReader(String str) {
        in = new StringBufferInputStream(str);
        init();
    }

    public static XmlRpcReader createReaderFromUserSpecifiedFile() {
        JFileChooser chooser = new JFileChooser();

        int retVal = chooser.showOpenDialog(null);
        if (retVal == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                return new XmlRpcReader(file);
            } catch (FileNotFoundException e) {
                return null;
            }
        }
        return null;
    }

    protected Object parsedObject;

    protected void init() {
        parser = new XmlRpcParser() {
            protected void handleParsedValue(Object obj) {
                parsedObject = obj;
            }
        };
    }

    public synchronized Object readObject() {
        parser.parse(in);
        return parsedObject;
    }
    
    public static void main(String[] args) {
        XmlRpcReader r = createReaderFromUserSpecifiedFile();
        Object res = r.readObject();
        System.out.println("Read object of type " + res.getClass() + ": " + res);
    }
}
